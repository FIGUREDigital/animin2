﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;

namespace AudioClipExplorer
{
    public static class Globals
    {
        #region ProductVersionNumber
        /// <summary>
        /// The product version number, eg "24".
        /// </summary>
        public static int ProductVersionNumber
        {
            get
            {
                return 26;
            }
        }
        #endregion

        #region ProductTitle
        /// <summary>
        /// The title of the product, eg "AudioClip Explorer 2.4"
        /// </summary>
        public static string ProductTitle
        {
            get;
            private set;
        }
        #endregion

        #region ProductName
        /// <summary>
        /// The name of the product, without version information.
        /// </summary>
        public static string ProductName
        {
            get
            {
                return "AudioClip Explorer";
            }
        }
        #endregion

        #region ProductId
        /// <summary>
        /// A code-friendly name of the product. Used as key to store settings to EditorPrefs for example.
        /// </summary>
        public static string ProductId
        {
            get
            {
                return "AudioClipExplorer";
            }
        }
        #endregion

        #region ProductAssetStoreUrl
        /// <summary>
        /// The link to the product in the Unity asset store.
        /// </summary>
        public static string ProductAssetStoreUrl
        {
            get
            {
                return "https://www.assetstore.unity3d.com/#/content/9679";
            }
        }
        #endregion

        #region ProductFeedbackUrl
        /// <summary>
        /// The URL to the texture overview forum thread.
        /// </summary>
        public static string ProductFeedbackUrl
        {
            get
            {
                return "http://forum.unity3d.com/threads/186018-Plugin-AudioClip-Explorer-%28edit-multiple-clips-simultaneously%29";
            }
        }
        #endregion

        #region cctor
        static Globals()
        {
            ProductTitle = string.Format("{0} {1:F1}", ProductName, ProductVersionNumber/10.0f);
        }
        #endregion
    }
}
