﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------
using EditorFramework;

namespace AudioClipExplorer
{
    public class MainWindow : EditorFramework.InstallerWindow
    {
        void OnEnable()
        {
            base.ProductTitle = Globals.ProductTitle;
            base.AssetStoreUrl = Globals.ProductAssetStoreUrl;
            base.FeedbackUrl = Globals.ProductFeedbackUrl;

            base.MinimumMajorVersion = 4;
            base.MinimumMinorVersion = 1;
            if (EditorApplication2.MajorVersion == 5)
            {
                base.MinimumMajorVersion = 5;
                base.MinimumMinorVersion = 1;
            }
        }
    }
}
