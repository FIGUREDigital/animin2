﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace AudioClipExplorer
{
    /// <summary>
    /// Listbox represents the control that displays audio clip settings.
    /// </summary>
    public class Listbox : GUIListView, IDisposable
    {
        #region class Column
        /// <summary>
        /// The Column class represents one column in the list header.
        /// </summary>
        class Column : GUIListViewColumn
        {
            public delegate void DrawDelegate(Model model, GUIListViewDrawItemArgs args);
            public delegate int CompareDelegate2(Model x, Model y);
            public delegate string ExportDelegate(Model model);

            /// <summary>
            /// Occurs when the model should get drawn.
            /// </summary>
            public DrawDelegate Drawer;

            /// <summary>
            /// Occurs when the column gets sorted.
            /// </summary>
            public CompareDelegate2 Comparer;

            /// <summary>
            /// Occurs when the column gets a request to get the item value as text.
            /// </summary>
            public ExportDelegate Exporter;

            /// <summary>
            /// Initializes a new instance of the Column class.
            /// </summary>
            public Column(string serializeName, string text, string tooltip, float width, DrawDelegate drawer, CompareDelegate2 comparer, ExportDelegate exporter)
                : base(text, tooltip, null, width, null)
            {
                base.SerializeName = serializeName;
                this.Drawer = drawer;
                this.Comparer = comparer;
                this.Exporter = exporter;

                // detour the base comparer callback to our CompareFuncImpl method
                if (null != comparer)
                    this.CompareFunc = CompareFuncImpl;
            }

            int CompareFuncImpl(object x, object y)
            {
                var a = x as Model;
                var b = y as Model;

                // make sure non of the both point to null
                var aisnull = ReferenceEquals(a, null);
                var bisnull = ReferenceEquals(b, null);
                if (aisnull && bisnull) return 0;
                if (!aisnull && bisnull) return 1;
                if (aisnull && !bisnull) return -1;

                // all validation checks passed, now compare the actual values
                return this.Comparer(a, b);
            }
        }
        #endregion

        #region class Model
        /// <summary>
        /// The Model class represents the item-type displayed in the list.
        /// </summary>
        /// <remarks>
        /// To display a certain value, we usually need its string representation. To avoid garbage generation while the plugin is running
        /// due to converting a value to a string every now and then, we make this conversion during initialization only.
        /// </remarks>
        class Model : ICacheFileEntry
        {
            AudioImporter Importer; // the importer of the audio clip
            public bool LoadError; // whether loading clip failed

            public string AssetGuid; // assetdatabase guid
            public ulong AssetTimestamp; // timestamp when the asset/meta file changed

            #region AssetPath
            string _assetPath;
            public string AssetPath
            {
                get
                {
                    if (null == _assetPath)
                        _assetPath = AssetDatabase.GUIDToAssetPath(AssetGuid) ?? "";
                    return _assetPath;
                }
            }
            #endregion

            #region AssetName
            string _assetName;
            public string AssetName // asset filename without file extension
            {
                get
                {
                    if (null == _assetName)
                        _assetName = FileUtil2.GetFileNameWithoutExtension(AssetPath);
                    return _assetName;
                }
            }
            #endregion

            #region Extension
            string _extension;
            public string Extension // file extension
            {
                get
                {
                    if (null == _extension)
                        _extension = FileUtil2.GetFileExtension(AssetPath);
                    return _extension;
                }
            }
            #endregion

            #region StorageSize
            public long StorageSize; // how many bytes the asset consumes on disk inside the unity editor cache
            string _storageSizeString;
            public string StorageSizeString
            {
                get
                {
                    if (null == _storageSizeString)
                        _storageSizeString = EditorUtility2.FormatBytes(StorageSize);
                    return _storageSizeString;
                }
            }
            #endregion

            #region OrgStorageSize
            public long OrgStorageSize; // how many bytes the original asset consumes on disk
            string _orgStorageSizeString;
            public string OrgStorageSizeString
            {
                get
                {
                    if (null == _orgStorageSizeString)
                        _orgStorageSizeString = EditorUtility2.FormatBytes(OrgStorageSize);
                    return _orgStorageSizeString;
                }
            }
            #endregion

            #region Compression
            public int Compression;
            string _compressionString;
            public string CompressionString
            {
                get
                {
                    if (null == _compressionString)
                        _compressionString = AudioStringUtil.Compression(Compression);
                    return _compressionString;
                }
            }
            #endregion

            #region Duration
            /// <summary>
            /// The duration in milliseconds of the clip.
            /// </summary>
            public int Duration;

            string _durationString;
            public string DurationString
            {
                get
                {
                    if (null == _durationString)
                        _durationString = AudioStringUtil.Duration(Duration);
                    return _durationString;
                }
            }
            #endregion

            #region Frequency
            /// <summary>
            /// The frequency in hertz (hz) of the clip.
            /// </summary>
            public int Frequency;

            string _frequencyString;
            public string FrequencyString
            {
                get
                {
                    if (null == _frequencyString)
                        _frequencyString = AudioStringUtil.Frequency(Frequency);
                    return _frequencyString;
                }
            }
            #endregion

            #region BitsPerSample
            public int BitsPerSample;

            string _bitsPerSampleString;
            public string BitsPerSampleString
            {
                get
                {
                    if (null == _bitsPerSampleString)
                        _bitsPerSampleString = AudioStringUtil.BitsPerSample(BitsPerSample);
                    return _bitsPerSampleString;
                }
            }
            #endregion

            #region RuntimeSize
            /// <summary>
            /// How much memory, in bytes, the clip consumes in memory.
            /// </summary>
            public int RuntimeSize;

            string _runtimeSizeString;
            public string RuntimeSizeString
            {
                get
                {
                    if (null == _runtimeSizeString)
                        _runtimeSizeString = AudioStringUtil.Size(RuntimeSize);
                    return _runtimeSizeString;
                }
            }
            #endregion

            #region Channels
            public int Channels;

            public string _channelsString;
            public string ChannelsString
            {
                get
                {
                    if (null == _channelsString)
                        _channelsString = AudioStringUtil.Channels(Channels);
                    return _channelsString;
                }
            }
            #endregion

            public AudioType OrigType;
            public AudioType OrigCompressedType;
            public int OrigChannels;
            public bool OrigIsMonoForcable;
            public bool OrigIsCompressible;
            public int MinBitrate;
            public int MaxBitrate;
            public AudioType ClipType;
            public AudioImporterFormat ImporterFormat;
            public bool Importer3D;
            public bool ImporterForceMono;
            public AudioImporterLoadType ImporterLoadType;
            public bool ImporterHardwareDecoding;
            public bool ImporterGaplessLooping;

            // if the user makes modifications to clip settings, these
            // modifications are set in these Modified... variables and
            // have to be Apply()'ed to actually commit them to Unity.
            public AudioImporterFormat ModifiedFormat;
            public bool Modified3D;
            public bool ModifiedForceMono;
            public int ModifiedCompression;
            public AudioImporterLoadType ModifiedLoadType;
            public bool ModifiedHardwareDecoding;
            public bool ModifiedGaplessLooping;

            /// <summary>
            /// Gets whether the 'Force Mono' option is available.
            /// </summary>
            public bool CanChangeForceMono
            {
                get
                {
                    var result = OrigChannels > 1 && ((OrigIsMonoForcable) || (ModifiedFormat == AudioImporterFormat.Compressed && OrigIsCompressible));
                    return result;
                }
            }

            /// <summary>
            /// Gets whether the audio importer has modifications inside AudioClip Explorer.
            /// </summary>
            public bool IsModified
            {
                get
                {
                    var value = ModifiedFormat != ImporterFormat;
                    value |= (Modified3D != Importer3D);
                    value |= (ModifiedForceMono != ImporterForceMono);
                    value |= (ModifiedCompression != Compression);
                    value |= (ModifiedLoadType != ImporterLoadType);
                    value |= (ModifiedHardwareDecoding != ImporterHardwareDecoding);
                    value |= (ModifiedGaplessLooping != ImporterGaplessLooping);

                    return value;
                }
            }

            #region ICacheFileEntry Implementation
            public string GetAssetGuid()
            {
                return AssetGuid;
            }

            public ulong GetAssetTimestamp()
            {
                return AssetTimestamp;
            }

            public void Serialize(BinarySerializer data)
            {
                if (data.IsReader)
                    ResetVariables();

                data.Serialize(ref AssetGuid);
                data.Serialize(ref AssetTimestamp);
                bool detailsLoaded = false; data.Serialize(ref detailsLoaded); // only present for backwards compatibility
                data.Serialize(ref LoadError);
                data.Serialize(ref StorageSize);
                data.Serialize(ref OrgStorageSize);
                data.Serialize(ref Compression);
                data.Serialize(ref Duration);
                data.Serialize(ref Frequency);
                data.Serialize(ref BitsPerSample);
                data.Serialize(ref RuntimeSize);
                data.Serialize(ref Channels);

                data.SerializeEnum(ref OrigType);
                data.SerializeEnum(ref OrigCompressedType);
                data.Serialize(ref OrigChannels);
                data.Serialize(ref OrigIsMonoForcable);
                data.Serialize(ref OrigIsCompressible);
                data.Serialize(ref MinBitrate);
                data.Serialize(ref MaxBitrate);
                data.SerializeEnum(ref ClipType);

                data.SerializeEnum(ref ImporterFormat);
                data.Serialize(ref Importer3D);
                data.Serialize(ref ImporterForceMono);
                data.SerializeEnum(ref ImporterLoadType);
                data.Serialize(ref ImporterHardwareDecoding);
                data.Serialize(ref ImporterGaplessLooping);
            }
            #endregion

            #region ResetVariables
            /// <summary>
            /// Sets variables to default values.
            /// </summary>
            void ResetVariables()
            {
                Frequency = -1;
                Compression = -1;
                Duration = -1;
                LoadError = false;
                RuntimeSize = -1;
                Channels = -1;

                _assetPath = null;
                _assetName = null;
                _extension = null;
                _storageSizeString = null;
                _orgStorageSizeString = null;
                _compressionString = null;
                _durationString = null;
                _frequencyString = null;
                _bitsPerSampleString = null;
                _runtimeSizeString = null;
                _channelsString = null;
                AssetTimestamp = 0;
                AssetGuid = "";
            }
            #endregion

            #region Init
            /// <summary>
            /// Initializes the Model instance with the specified path.
            /// </summary>
            public void Init(string path)
            {
                ResetVariables();

                AudioImporter importer = AudioImporter.GetAtPath(path) as AudioImporter;
                if (importer == null)
                {
                    Debug.LogError(string.Format("AudioClip Explorer: Could not get AudioImporter for '{0}'.", path??"<null>"));
                    _assetPath = path;
                    LoadError = true;
                    RevertChanges();
                    return;
                }

                // TODO: Unity Case 542844
                // Unity 4.x has that bug that prevents us from getting the correct MinBitrate and MaxBitrate.
                // A workaround is to call 'UpdateOrigData' prior getting these bitrates. However, it's actually
                // a quite slow operation and I should remove this line whenever Unity fixed the issue.
                AudioImporter2.UpdateOrigData(importer);

                Importer = importer;
                AssetGuid = AssetDatabase.AssetPathToGUID(importer.assetPath);
                AssetTimestamp = importer.assetTimeStamp;

                StorageSize = AssetDatabase2.GetStorageSize(importer.assetPath);
                OrgStorageSize = FileUtil2.GetFileSize(importer.assetPath);
                Compression = importer.compressionBitrate < 0 ? AudioImporter2.GetDefaultBitrate(importer) : importer.compressionBitrate; // negative bitrate in importer indicates to use the default bitrate.
                OrigType = AudioImporter2.GetOrigType(Importer);
                OrigCompressedType = AudioUtil2.GetPlatformConversionType(OrigType, BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget), AudioImporterFormat.Compressed);
                AudioImporter2.GetMinMaxBitrate(importer, OrigType, out MinBitrate, out MaxBitrate);
                OrigChannels = AudioImporter2.GetOrigChannelCount(importer);
                OrigIsCompressible = AudioImporter2.GetOrigIsCompressible(importer);
                OrigIsMonoForcable = AudioImporter2.GetOrigIsMonoForcable(importer);

                var clip = AssetDatabase.LoadAssetAtPath(AssetPath, typeof(AudioClip)) as AudioClip;
                if (null != clip)
                {
                    Duration = (int)(clip.length * 1000); // convert seconds to milliseconds
                    BitsPerSample = AudioUtil2.GetBitsPerSample(clip);
                    Frequency = clip.frequency;
                    RuntimeSize = AudioUtil2.GetSize(clip);
                    Channels = clip.channels;
                    ClipType = AudioUtil2.GetClipType(clip);
                }
                else
                {
                    LoadError = true;
                    Debug.LogError(string.Format("AudioClip Explorer: Could not load AudioClip '{0}'. Is the sound file broken?", AssetPath ?? "<null>"));
                }

                ImporterFormat = Importer.format;
                Importer3D = Importer.threeD;
                ImporterForceMono = Importer.forceToMono;
                ImporterLoadType = Importer.loadType;
                ImporterHardwareDecoding = Importer.hardware;
                ImporterGaplessLooping = Importer.loopable;

                // All changes the user makes in AudioClip Explorer
                // operate on the 'Modified...' variables. The initial values
                // must be the current importer values obviously.
                RevertChanges();
            }
            #endregion

            #region RevertChanges
            /// <summary>
            /// Reverts audio importer modifications.
            /// </summary>
            public void RevertChanges()
            {
                ModifiedFormat = ImporterFormat;
                Modified3D = Importer3D;
                ModifiedForceMono = ImporterForceMono;
                ModifiedCompression = Compression;
                ModifiedLoadType = ImporterLoadType;
                ModifiedHardwareDecoding = ImporterHardwareDecoding;
                ModifiedGaplessLooping = ImporterGaplessLooping;
            }
            #endregion

            #region ApplyChanges
            /// <summary>
            /// Applies audio importer modifications to Unity.
            /// </summary>
            public void ApplyChanges()
            {
                if (!IsModified)
                    return;

                if (Importer == null)
                    Importer = AudioImporter.GetAtPath(AssetPath) as AudioImporter;

                Importer.format = ModifiedFormat;
                Importer.threeD = Modified3D;
                Importer.forceToMono = ModifiedForceMono;
                Importer.loadType = ModifiedLoadType;
                Importer.hardware = ModifiedHardwareDecoding;
                Importer.loopable = ModifiedGaplessLooping;

                if (ModifiedCompression != Compression && ModifiedFormat == AudioImporterFormat.Compressed)
                    Importer.compressionBitrate = ModifiedCompression;

                EditorUtility.SetDirty(Importer);
                AssetDatabase.WriteImportSettingsIfDirty(Importer.assetPath);
            }
            #endregion
        }
        #endregion

        #region Private Fields
        // the color used to highlight modified values
        static Color ModifiedValueColor
        {
            get
            {
                return GUIColors.TintIfPlaying(new Color(1.0f, 0.65f, 0.65f));
            }
        }

        List<Model> _items = new List<Model>();
        List<Model> _allitems = new List<Model>();
        SearchTextParser.Result _filterResult = new SearchTextParser.Result();
        bool _disposed;
        FilterMode _filterMode;
        Column _columnCompression;
        CacheFile<Model> _cache = new CacheFile<Model>(1, Globals.ProductName, Globals.ProductId);
        #endregion

        /// <summary>
        /// The FilterMode indicates which property the search function
        /// considers for text matching.
        /// </summary>
        public enum FilterMode
        {
            Name = 0, // Search in name
            Path = 1, // Search in path
            Guid = 2 // Search in guid
        }

        /// <summary>
        /// Occurs whenever the listbox content changed.
        /// </summary>
        public Action<Listbox> Changed;

        /// <summary>
        /// Gets the number of items in the list.
        /// </summary>
        public int ItemCount
        {
            get
            {
                return _items.Count;
            }
        }

        /// <summary>
        /// Gets a pretty string how many items are in the list.
        /// </summary>
        public string ItemCountString
        {
            get
            {
                if (_items.Count != _allitems.Count)
                    return string.Format("{0}/{1} AudioClips", _items.Count, _allitems.Count);
                return string.Format("{0} AudioClips", _items.Count);
            }
        }

        /// <summary>
        /// Gets a string describing the selected items in the list.
        /// </summary>
        public string SelectionString
        {
            get
            {
                if (SelectedItemsCount == 0)
                    return "";

                var models = GetSelectedModels();
                if (SelectedItemsCount == 1)
                    return models[0].AssetPath;

                long storagesize;
                long runtimesize;
                GetSummedSize(models, out storagesize, out runtimesize);

                return string.Format("{0} selected | Storage: {1} | Runtime: {2}",
                    models.Count,
                    EditorUtility2.FormatBytes(storagesize),
                    runtimesize < 0 ? "???" : EditorUtility2.FormatBytes(runtimesize));
            }
        }

        /// <summary>
        /// Gets whether any settings have been modified and not applied yet.
        /// </summary>
        public bool IsModified
        {
            get
            {
                var list = GetModifiedModels();
                return list.Count > 0;
            }
        }

        /// <summary>
        /// A value indication at which time the UnityEditor.Selection has been assigned.
        /// </summary>
        /// <remarks>
        /// If the user double-clicks an item in AudioClip Explorer, we assign it to UnityEditor.Selection.
        /// But on the same hand, AudioClip Explorer can listen to selection changes in Unity to automatically
        /// display the selected items. To avoid that 'feedback loop', we assign the time to this variable
        /// when the user double-clicks an item in the list and the selection change listening code can check
        /// if the selection change came from this list.
        /// </remarks>
        public double ChangeUnitySelectionTime
        {
            get;
            private set;
        }

        /// <summary>
        /// The active build target platform group.
        /// </summary>
        public BuildTargetGroup PlatformGroup
        {
            get;
            private set;
        }

        #region ctor
        /// <summary>
        /// Initializes a new instance of the Listbox class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public Listbox(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
            MultiSelect = true;
            DragDropEnabled = true;
            RightClickSelect = true;
            Mode = GUIListViewMode.Details;
            ItemSize = new Vector2(0, 22);
            FullRowSelect = true;
//            PlatformGroup = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);

            // Add the columns
            Columns.Add(new Column("Name", "Name", "Asset name", 220, OnDrawAssetName, OnCompareAssetName, OnExportAssetName));
            Columns.Add(new Column("Path", "Path", "Full asset path, including file extension.", 360, OnDrawAssetPath, OnCompareAssetPath, OnExportAssetPath) { Visible = false });
            Columns.Add(new Column("GUID", "GUID", "Asset GUID (Global Unique Identifier).", 300, OnDrawAssetGuid, OnCompareAssetGuid, OnExportAssetGuid) { Visible = false });
            Columns.Add(new Column("Format", "Format", "The format that will be used for the sound at runtime.", 110, OnDrawFormat, OnCompareFormat, OnExportFormat));
            Columns.Add(new Column("3D", "3D", "Whether the AudioClip will play back in 3D space. Both, Mono and Stereo sounds can be played in 3D.", 30, OnDraw3D, OnCompare3D, OnExport3D));
            Columns.Add(new Column("Force Mono", "Force Mono", "Whether the AudioClip will be down-mixed to a single channel sound.", 75, OnDrawForceMono, OnCompareForceMono, OnExportForceMono));
            Columns.Add(_columnCompression = new Column("Compression", null, null, 230, OnDrawCompression, OnCompareCompression, OnExportCompression));
            Columns.Add(new Column("Load Type", "Load Type", "The method Unity uses to load audio assets at runtime.", 150, OnDrawLoadType, OnCompareLoadType, OnExportLoadType));
            Columns.Add(new Column("Hardware Decoding", "Hardware Decoding", "(iOS only) On iOS devices, Apple's hardware decoder can be used resulting in lower CPU overhead during decompression.", 120, OnDrawHardwareDecoding, OnCompareHardwareDecoding, OnExportHardwareDecoding) { Visible = false });
            Columns.Add(new Column("Gapless Looping", "Gapless Looping", "(Android/iOS only) Use this when compressing a seamless looping audio source file (in a non-compressed PCM format) to ensure perfect continuity is preserved at the seam.", 100, OnDrawGaplessLooping, OnCompareGaplessLooping, OnExportGaplessLooping) { Visible = false });
            Columns.Add(new Column("Frequency", "Frequency", "Sample frequency of the AudioClip in Hz.", 80, OnDrawFrequency, OnCompareFrequency, OnExportFrequency));
            Columns.Add(new Column("Channels", "Channels", "The number of channels in the AudioClip, such as Mono, Stereo or multiple channels like 5.1.", 60, OnDrawChannels, OnCompareChannels, OnExportChannels));
            Columns.Add(new Column("Bits per Sample", "Bits per Sample", "Bits per Sample", 100, OnDrawBitsPerSample, OnCompareBitsPerSample, OnExportBitsPerSample));
            Columns.Add(new Column("Duration", "Duration", "The duration of the AudioClip.", 80, OnDrawDuration, OnCompareDuration, OnExportDuration));
            Columns.Add(new Column("Runtime Size", "Runtime Size", "The size the AudioClip consumes in memory.", 85, OnDrawRuntimeSize, OnCompareRuntimeSize, OnExportRuntimeSize));
            Columns.Add(new Column("Storage Size", "Storage Size", "The size of  the AudioClip on disk, after it went through the import-process, as stored in Unity's editor cache.\n\nThis a good estimate of the actual file size used on the storage device.", 80, OnDrawStorageSize, OnCompareStorageSize, OnExportStorageSize));
            Columns.Add(new Column("Original Storage Size", "Original Storage Size", "The size of the source asset on disk, before it went through the Unity import-process. Basically the file-size of the wav, ogg, mp3, etc.", 130, OnDrawOrgStorageSize, OnCompareOrgStorageSize, OnExportOrgStorageSize) { Visible = false });
            Columns.Add(new Column("Extension", "Extension", "The file extension.", 70, OnDrawFileExtesion, OnCompareFileExtesion, OnExportFileExtesion) { Visible = false });

            UpdateColumnTexts();

            // Hook into the asset pipeline, since we need to update the list in case the user deletes,
            // moves or imports assets while AudioClip Explorer is running.
            AssetFileWatcher.Imported += AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted += AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved += AssetFileWatcher_Moved;
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            if (_disposed)
                return;

            // check if cache is empty to avoid overwriting a cache file with no data.
            // in case the plugin crashed and wasn't able to fill the cache.
            if (!_cache.IsEmpty)
                _cache.Write();

            AssetFileWatcher.Imported -= AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted -= AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved -= AssetFileWatcher_Moved;

            _cache = null;
            _items = null;
            _allitems = null;
            _disposed = true;
            GC.SuppressFinalize(this);
        }
        #endregion

        #region ReadCacheFile
        /// <summary>
        /// Reads the cache file to speed up the SetItems() method.
        /// </summary>
        public void ReadCacheFile()
        {
            _cache.Read();
        }
        #endregion

        #region GetSummedSize
        /// <summary>
        /// Gets the summed size of all clips specified by models.
        /// </summary>
        void GetSummedSize(List<Model> models, out long storagesize, out long runtimesize)
        {
            storagesize = 0;
            runtimesize = 0;
            foreach (var model in models)
            {
                storagesize += model.StorageSize;
                if (runtimesize > -1) // -1 means value not set
                {
                    runtimesize += model.RuntimeSize;
                    if (model.RuntimeSize < 0)
                        runtimesize = -1;
                }
            }
        }
        #endregion

        #region UpdateColumnTexts
        /// <summary>
        /// Updates the column texts.
        /// Xbox uses a different compression title, so we call this method every OnGUI
        /// and set the corresponding title for the active build target.
        /// </summary>
        void UpdateColumnTexts()
        {
            // TODO: set title only when platform changed
            var isxbox360 = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget) == BuildTargetGroup.XBOX360;
            if (isxbox360)
            {
                _columnCompression.Text = "XMA Quality";
                _columnCompression.Tooltip = "Compression quality applied to a compressed AudioClip.";
            }
            else
            {
                _columnCompression.Text = "Compression (kbps)";
                _columnCompression.Tooltip = "Amount of compression in kbps, to be applied to a compressed AudioClip.";
            }
        }
        #endregion

        #region TryShowApplyRevertSettings
        /// <summary>
        /// Must be called when the editor is going to switch into play mode
        /// and when the window is about to close.
        /// </summary>
        public void TryShowApplyRevertSettings(bool showcancel, Action oncancel)
        {
            var builder = new StringBuilder(128);

            builder.AppendLine("Unapplied import settings for");

            // build a string containing the path of the first three modified clips.
            var modified = new List<Model>();
            foreach (var model in _allitems)
            {
                if (model.IsModified)
                {
                    modified.Add(model);
                    if (modified.Count < 3)
                        builder.AppendLine("'" + model.AssetPath + "'");
                    else if (modified.Count == 3)
                        builder.AppendLine("...");
                }
            }

            if (modified.Count == 0)
                return; // no modifications, nothing to do

            var title = string.Format("{0} unapplied import settings", modified.Count);
            var applytext = "Apply";
            var reverttext = "Revert";
            if (showcancel)
            {
                var result = EditorUtility.DisplayDialogComplex(title, builder.ToString(), applytext, reverttext, "Cancel");
                switch (result)
                {
                    case 0: // Apply
                        ApplyRevertChanges(modified, true, false);
                        break;
                    case 1: // Revert
                        ApplyRevertChanges(modified, false, false);
                        break;
                    case 2: // Cancel
                        if (null != oncancel)
                            oncancel();
                        break;
                }
            }
            else
            {
                if (EditorUtility.DisplayDialog(title, builder.ToString(), applytext, reverttext))
                    ApplyRevertChanges(modified, true, false);
                else
                    ApplyRevertChanges(modified, false, false);
            }
        }
        #endregion

        #region DoChanged
        /// <summary>
        /// Raises the Changed event.
        /// Call this method to notify subscribers about list content or state changes.
        /// </summary>
        void DoChanged()
        {
            if (null != Changed)
            {
                var cb = Changed;
                cb.Invoke(this);
            }
        }
        #endregion

        #region IsSupportedFile
        /// <summary>
        /// Gets whether the asset of the specified path is supported to be displayed in AudioClip Explorer.
        /// </summary>
        /// <param name="path">The relative asset path</param>
        bool IsSupportedFile(string path)
        {
            if (!AssetDatabase2.IsAssetType(path, typeof(AudioClip)))
                return false;
            return true;
        }
        #endregion

        #region CheckUnloadUnused
        /// <summary>
        /// Call this method after every LoadDetails(). It sums the sizes of the loaded
        /// clips and makes sure to unload those when a certail memory consumtion threshold
        /// has been reached. This feature makes AudioClip Explorer able to display settings of audio clips of any number.
        /// </summary>
        void CheckUnloadUnused(Model model, ref long loadedsize)
        {
            if (null == model)
                return;

            loadedsize += model.StorageSize;
            if (loadedsize > 256 * 1024 * 1024)
            {
                _cache.Write();
                EditorUtility2.UnloadUnusedAssetsImmediate();
                loadedsize = 0;
            }
        }
        #endregion

        #region SetItems
        /// <summary>
        /// Sets the audio clips that should be shown in AudioClip Explorer.
        /// </summary>
        /// <param name="paths">The asset paths of assets to add to the list.</param>
        public void SetItems(List<string> paths)
        {
            UnityEngine.Profiler.BeginSample("Listbox.SetItems");
            Reset();

            PlatformGroup = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget);
            _allitems = new List<Model>(paths.Count);

            // build a list with compatible assets
            var clippaths = new List<string>(paths.Count);
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue;
                clippaths.Add(path);
            }

            _cache.BeginGetEntry();
            try
            {
                UnityEngine.Profiler.BeginSample("Listbox.SetItems");

                // now add each item to the list
                using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
                {
                    // indicates how many bytes are loaded during initialization
                    // and is used to release memory at some threshold to prevent the
                    // editor to crash with an out-of-mem exception.
                    long loadedsize = 0;

                    for (var n = 0; n < clippaths.Count; ++n)
                    {
                        var path = clippaths[n];

                        // report the progress to the user, since it can be a time consuming operation to read many clips.
                        if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                        {
                            var progress = n / (float)clippaths.Count;
                            var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(path), clippaths.Count - n - 1);
                            if (progressbar.Update(text, progress))
                                break;
                        }

                        // initialize the model-representation
                        Model item = null;
                        if (!InitModel(ref item, path))
                        {
                            // we are here when the model wasn't fetched from the cache.
                            // this means we actually needed to read the texture into memory to get its settings. 
                            // we need to release unused memory eventually, otherwise Unity will crash.
                            CheckUnloadUnused(item, ref loadedsize);
                        }

                        _allitems.Add(item);
                    }

                    // if it actually loaded new clip settings make
                    // sure to save the cache file
                    if (loadedsize > 0)
                        _cache.Write();
                }

                UnityEngine.Profiler.EndSample();
            }
            finally
            {
                _cache.EndGetEntry();
            }

            _items = new List<Model>(_allitems);
            Sort();
            DoChanged();

            UnityEngine.Profiler.EndSample();
        }
        #endregion

        #region Search/Filter the list
        /// <summary>
        /// Filters the list using the specified text and mode.
        /// </summary>
        /// <param name="text">The text a item must contain to match.</param>
        /// <param name="mode">The mode, in which property of the model, the search should check.</param>
        public void SetFilter(string text, FilterMode mode)
        {
            var parserresult = SearchTextParser.Parse(text);
            SetFilter(parserresult, mode);
        }

        void SetFilter(SearchTextParser.Result parserresult, FilterMode mode)
        {
            _filterResult = parserresult;
            _filterMode = mode;

            // if the filter is empty, all items are visible.
            _items = new List<Model>(_allitems.Count);
            if (_filterResult.Names.Count == 0)
            {
                _items.AddRange(_allitems);
                DoChanged();
                return;
            }

            // check each item if it's visible.
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var item = _allitems[n];
                if (IsIncludedInFilter(item))
                    _items.Add(item);
            }

            DoChanged();
        }

        public void SetPlatform(BuildTargetGroup platform)
        {
            PlatformGroup = platform;
        }

        /// <summary>
        /// Gets whether the specified model matchs the filter criteria.
        /// </summary>
        /// <returns>true when the filter is matching and the item has to be included in the list, false otherwise.</returns>
        bool IsIncludedInFilter(Model model)
        {
            if (_filterResult.NamesExpr.Count == 0)
                return true;

            var modelname = model.AssetName;
            switch (_filterMode)
            {
                case FilterMode.Path: modelname = model.AssetPath; break;
                case FilterMode.Guid: modelname = model.AssetGuid; break;
            }

            return _filterResult.IsNameMatch(modelname);
        }
        #endregion

        #region InitModel
        /// <summary>
        /// Initializes the specified model with the specified importer.
        /// </summary>
        bool InitModel(ref Model model, string path)
        {
            if (null == model)
            {
                // try to get it from the cache
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (_cache.TryGetEntry(guid, PlatformGroup, out model, true))
                {
                    model.RevertChanges(); // just to set the initial variables where we work on for changes
                    return true;
                }

                model = new Model();
            }

            // it's not located in cache, initialize it the expensive way
            model.Init(path);
            _cache.UpdateEntry(model, PlatformGroup);
            return false;
        }
        #endregion

        #region Helper methods to get selected paths/models/clips
        /// <summary>
        /// Gets all models that are currently selected.
        /// </summary>
        /// <returns></returns>
        List<Model> GetSelectedModels()
        {
            var selection = SelectedItems;
            var models = new List<Model>();
            foreach (var item in selection)
            {
                var model = item as Model;
                if (null != model)
                    models.Add(model);
            }
            return models;
        }

        /// <summary>
        /// Gets all modified models of the current selection.
        /// </summary>
        List<Model> GetSelectedModifiedModels()
        {
            var models = GetSelectedModels();
            var modified = new List<Model>();
            for (var n = 0; n < models.Count; ++n)
            {
                var model = models[n];
                if (model.IsModified)
                    modified.Add(model);
            }
            return modified;
        }

        /// <summary>
        /// Gets all modified models.
        /// </summary>
        List<Model> GetModifiedModels()
        {
            var modified = new List<Model>();
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var model = _allitems[n];
                if (model.IsModified)
                    modified.Add(model);
            }
            return modified;
        }

        /// <summary>
        /// Gets all audio clips that are currently selected in AudioClip Explorer.
        /// </summary>
        /// <remarks>
        /// To return the AudioClip, the asset actually needs to be loaded into memory.
        /// This can be an expensive operation and since Unity is 32bit only, it might even
        /// crash the editor when you try to get/load more audio clips into memory than there
        /// is available due to the 32bit limit.
        /// Unlike the Unity editor, we display a progressbar during this time, so it won't look like
        /// the editor freezed when a large amount of clips are selected.
        /// </remarks>
        /// <param name="maxcount">Maximum count of audio clips that are allowed  to be returned.</param>
        List<AudioClip> GetSelectedClips(int maxcount)
        {
            var clips = new List<AudioClip>(64);
            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
            {
                var selection = SelectedItems;
                for (var n = 0; n < Mathf.Min(maxcount, selection.Length); ++n)
                {
                    var model = selection[n] as Model;

                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)selection.Length;
                        var text = string.Format("[{1} remaining] {0}", model.AssetName, selection.Length - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    var clip = AssetDatabase.LoadAssetAtPath(model.AssetPath, typeof(AudioClip)) as AudioClip;
                    if (null != clip)
                        clips.Add(clip);
                }
            }
            return clips;
        }

        /// <summary>
        /// Gets asset paths of the currently selected models.
        /// </summary>
        List<string> GetSelectedPaths()
        {
            var selection = SelectedItems;
            var paths = new List<string>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                if (model != null && !string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }

        /// <summary>
        /// Gets asset paths of all models.
        /// </summary>
        List<string> GetAllPaths()
        {
            var paths = new List<string>(_allitems.Count);
            foreach (var item in _allitems)
            {
                var model = item as Model;
                if (model != null && !string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }
        #endregion

        #region DoGUI
        protected override void DoGUI()
        {
            UpdateColumnTexts();

            base.DoGUI();
            
            DragColumn = FirstVisibleColumn; // we only allow drag&drop from items in the fist column
        }
        #endregion

        #region OnItemContextMenu
        /// <summary>
        /// Occurs when the user requests the context menu
        /// </summary>
        protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
        {
            base.OnItemContextMenu(args);

            if (SelectedItemsCount < 1)
                return; // no item selected, do not open a context menu

            GUIUtility.hotControl = 0;
            var model = args.Model as Model;

            var selection = GetSelectedModels();
            var hasmodifications = HasModifications(selection);
            var menu = new GenericMenu();

            menu.AddItem(new GUIContent("Apply"), false, hasmodifications ? OnContextMenuApply : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Revert"), false, hasmodifications ? OnContextMenuRevert : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, SelectedItemsCount <= 10 ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Open %enter"), false, OnContextMenuOpenWithDefaultApp);
            menu.AddItem(new GUIContent("Delete... _delete"), false, OnContextMenuDelete);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Select in Project _enter"), false, OnContextMenuSelect);
            menu.AddItem(new GUIContent("Find References in Scene"), false, SelectedItemsCount == 1 ? OnContextMenuFindReferencesInScene : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Find Prefabs in Project"), false, OnContextMenuFindPrefabsInProject);
            menu.AddItem(new GUIContent("Find Prefabs and Scenes in Project"), false, OnContextMenuFindPrefabsAndScenesInProject);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Reimport"), false, OnContextMenuReimport);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Copy Full Path"), false, OnContextMenuCopyFullPath);

            
            // display the context menu. make sure to use the provided args.MenuLocation position
            // rather than 'Event.current.mousePosition', because the user could have been pressed
            // the context menu button as well, thus mousePosition is most likely wrong.
            menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
            Event.current.Use();
            Editor.Repaint();
        }

        void OnContextMenuApply()
        {
            ApplyRevertChanges(GetSelectedModifiedModels(), true, true);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuRevert()
        {
            ApplyRevertChanges(GetSelectedModifiedModels(), false, true);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuShowInExplorer()
        {
            var objects = GetSelectedClips(int.MaxValue);
            EditorApplication2.ShowInExplorer(objects.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuOpenWithDefaultApp()
        {
            var paths = GetSelectedPaths();
            EditorApplication2.OpenAssets(paths.ToArray());
            Editor.Repaint();
            EditorGUIUtility.ExitGUI(); // without this line an exception occurs (but it still opens the default app)
        }

        void OnContextMenuDelete()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Delete(paths);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuFindReferencesInScene()
        {
            var objects = GetSelectedClips(1); // Unity 'Find References In Scene' can only find one asset
            if (objects.Count > 0)
            {
                EditorApplication2.FindReferencesInScene(objects[0]);
                EditorUtility2.UnloadUnusedAssetsImmediate();
            }
        }

        void OnContextMenuFindPrefabsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject) });
        }

        void OnContextMenuFindPrefabsAndScenesInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject), typeof(AssetDatabase2.UnityScene) });
        }

        void OnContextMenuReimport()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Reimport(GetSelectedPaths(), 3, ImportAssetOptions.ForceUpdate);
        }

        void OnContextMenuCopyFullPath()
        {
            var paths = GetSelectedPaths();
            ClipboardUtil.CopyPaths(paths);
        }

        void OnContextMenuSelect()
        {
            var clips = GetSelectedClips(int.MaxValue);
            Selection.objects = clips.ToArray();
        }
        #endregion

        #region OnItemKeyDown
        /// <summary>
        /// Occurs when the user presses a key.
        /// </summary>
        protected override void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
        {
            switch (Event.current.keyCode)
            {
                case KeyCode.Delete:
                    OnContextMenuDelete();
                    args.Handled = true;
                    break;

                case KeyCode.Return:
                    if (Event.current.control)
                    {
                        OnContextMenuOpenWithDefaultApp();
                        args.Handled = true;
                    }
                    else
                    {
                        OnContextMenuSelect();
                        args.Handled = true;
                    }
                    break;
            }
        }
        #endregion

        #region OnBeginDrag
        /// <summary>
        /// Occurs at the beginning of a Drag&Drop operation.
        /// </summary>
        protected override void OnBeginDrag(int index, out UnityEngine.Object[] objects, out string[] paths)
        {
            paths = GetSelectedPaths().ToArray();

            // this will actually load the clips into memory, which is a bad idea if many clips are selected.
            // however, we display a progressbar during this time, so the editor won't just freeze like when you
            // select many assets in the unity project window.
            objects = GetSelectedClips(int.MaxValue).ToArray();
        }
        #endregion

        #region OnSorting
        /// <summary>
        /// Occurs when the user requests to sort the list.
        /// </summary>
        /// <returns>Returns the array of items to sort.</returns>
        protected override object[] OnBeforeSortItems()
        {
            return _allitems.ToArray();
        }

        /// <summary>
        /// Occurs after sorting completed.
        /// </summary>
        /// <param name="models">The sorted data. This is the data returned by OnBeforeSortItems(), but sorted.</param>
        protected override void OnAfterSortItems(object[] models)
        {
            base.OnAfterSortItems(models);

            _allitems = new List<Model>((Model[])models); // write the sorted data back to our data model
            SetFilter(_filterResult, _filterMode); // make sure any existing filter will still have impact on the list
        }
        #endregion

        #region OnItemDoubleClick
        /// <summary>
        /// Occurs when the user double clicks on an item.
        /// </summary>
        /// <param name="index">The index of the item.</param>
        protected override void OnItemDoubleClick(int index)
        {
            base.OnItemDoubleClick(index);

            // a double-click actually forces the list to have only 1 item selected,
            // so we also just get one clip here.
            var objs = GetSelectedClips(1);
            if (objs.Count > 0)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds; // store at which time the user involked the selected, in order to avoid a feedback loop if the plugin is listening to selection changes.
                Selection.activeObject = objs[0];
                EditorGUIUtility.PingObject(objs[0]);
            }
        }
        #endregion

        #region OnGetItemKeyword
        /// <summary>
        /// Gets the item keyword for the specified args.
        /// </summary>
        /// <remarks>
        /// The item-keyword is used to jump to a particular item in the list
        /// when the user pressed a key. When a model begins with the keyword(sequence)
        /// the list jumps to it.
        /// </remarks>
        protected override string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
        {
            var model = args.Model as Model;
            if (model != null)
                return model.AssetName;

            return null;
        }
        #endregion

        #region OnGetItem
        /// <summary>
        /// Gets the item at the specified index.
        /// </summary>
        protected override object OnGetItem(int index)
        {
            if (index < 0 || index >= _items.Count)
                return null;

            return _items[index];
        }
        #endregion

        #region OnGetItemCount
        /// <summary>
        /// Gets the count of items in the list.
        /// </summary>
        protected override int OnGetItemCount()
        {
            return _items.Count;
        }
        #endregion

        #region OnGetItemText
        /// <summary>
        /// Gets the item text of the specified column.
        /// </summary>
        protected override string OnGetItemText(GUIListViewGetItemTextArgs args)
        {
            var column = args.Column as Column;
            return column.Exporter(args.Model as Model);
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Occurs when the selection changed.
        /// </summary>
        protected override void OnSelectionChange()
        {
            base.OnSelectionChange();
            DoChanged();
        }
        #endregion

        #region OnDrawItemBackground
        /// <summary>
        /// Occurs when a list background for a row is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the row.</param>
        protected override void OnDrawItemBackground(ref GUIListViewDrawItemBackgroundArgs args)
        {
            base.OnDrawItemBackground(ref args);

            var model = args.Model as Model;
            if (null == model)
                return;

            // if the clip is broken, make the row red
            if (model.LoadError && args.Column.IsPrimaryColumn)
            {
                var oldcolor = GUI.color;
                GUI.color = GUIColors.TintIfPlaying(new Color(0.85f, 0.2f,0.2f,1));
                GUI.Box(args.Rect, "", GUIStyles.White);
                GUI.color = oldcolor;
            }
        }
        #endregion

        #region OnDrawItem
        /// <summary>
        /// Occurs when a list item is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the item.</param>
        protected override void OnDrawItem(GUIListViewDrawItemArgs args)
        {
            var model = args.Model as Model;
            if (null == model) return;

            // if this is the first column in the list, display an icon there
            if (args.Column.IsPrimaryColumn)
            {
                Texture image = null;
                switch (model.ModifiedFormat)
                {
                    case AudioImporterFormat.Native:     image = Images.AudioFile16x16;           break;
                    case AudioImporterFormat.Compressed: image = Images.CompressedAudioFile16x16; break;
                }
                
                if (null != image)
                    DrawItemImageHelper(ref args.ItemRect, image, new Vector2(16, 16));
            }

            // make the text appear vertically centered in the row
            args.ItemRect.width -= 5;
            args.ItemRect.y += 3; args.ItemRect.height -= 3;

            // draw the models value using the specified custom drawer method
            var column = args.Column as Column;
            if (null != column && null != column.Drawer)
                column.Drawer(model, args);

            // if this is the first column in the list and the model
            // has modifications, draw the Apply and Revert buttons.
            if (args.Column.IsPrimaryColumn && model.IsModified)
            {
                var oldcolor = GUI.color;
                GUI.color = GUIColors.TintIfPlaying(Color.white);
                
                // draw the apply and revert buttons at the right side of the first (primary) column
                var revertrect = args.ItemRect;
                revertrect.x += revertrect.width;
                revertrect.width = 16;
                revertrect.x -= revertrect.width + 2;
                if (GUI.Button(revertrect, GUIContent2.Temp("", null, "Revert changes from selected AudioClip(s)"), GUIStyles.RevertImageButton))
                    ApplyRevertChanges(GetSelectedModifiedModels(), false, true);

                var applyrect = revertrect;
                applyrect.x -= revertrect.width + 2;
                if (GUI.Button(applyrect, GUIContent2.Temp("", null, "Apply changes to selected AudioClip(s)"), GUIStyles.AcceptImageButton))
                {
                    ApplyRevertChanges(GetSelectedModifiedModels(), true, true);
                    AssetDatabase.Refresh();
                }

                args.ItemRect.width -= revertrect.width * 2 + 4;
                GUI.color = oldcolor;
            }
            else
            {
                // draw invisible buttons to avoid gui layout mismatch errors if from one
                // gui event to the users the modified state of a model changed.
                GUI.Button(new Rect(0, 0, 0, 0), "", GUIStyles.Clear);
                GUI.Button(new Rect(0, 0, 0, 0), "", GUIStyles.Clear);
            }
        }
        #endregion

        #region Draw/Compare Name
        void OnDrawAssetName(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetName, args.Selected);
        }

        int OnCompareAssetName(Model x, Model y)
        {
            return string.Compare(x.AssetName, y.AssetName, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetName(Model model)
        {
            return model.AssetName;
        }
        #endregion

        #region Draw/Compare Format
        void OnDrawFormat(Model model, GUIListViewDrawItemArgs args)
        {
            var oldenabled = GUI.enabled;
            GUI.enabled = model.OrigIsCompressible;

            var oldcolor = GUI.color;
            if (model.ImporterFormat != model.ModifiedFormat)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = (AudioImporterFormat)EditorGUI.EnumPopup(args.ItemRect, model.ModifiedFormat);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedFormat)
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.OrigIsCompressible)
                            model2.ModifiedFormat = newvalue;
                    });
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareFormat(Model x, Model y)
        {
            // rather than comparing the enumerated value, we compare its text.
            // it's done this way, because otherwise sorting doesn't appear in alphabetical order and looks just wrong.
            return string.Compare(x.ModifiedFormat.ToString(), y.ModifiedFormat.ToString(), StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportFormat(Model model)
        {
            return model.ImporterFormat.ToString();
        }
        #endregion

        #region Draw/Compare 3D
        void OnDraw3D(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;

            var oldcolor = GUI.color;
            if (model.Modified3D != model.Importer3D)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.Modified3D);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.Modified3D)
                    ModifySelectedItems(delegate(Model model2) { model2.Modified3D = newvalue; });
            }

            GUI.color = oldcolor;
        }

        int OnCompare3D(Model x, Model y)
        {
            return x.Modified3D.CompareTo(y.Modified3D);
        }

        string OnExport3D(Model model)
        {
            return model.Importer3D.ToString();
        }
        #endregion

        #region Draw/Compare Force Mono
        void OnDrawForceMono(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeForceMono;

            var oldcolor = GUI.color;
            if (model.ModifiedForceMono != model.ImporterForceMono)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedForceMono);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedForceMono)
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeForceMono)
                            model2.ModifiedForceMono = newvalue;
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareForceMono(Model x, Model y)
        {
            return x.ModifiedForceMono.CompareTo(y.ModifiedForceMono);
        }

        string OnExportForceMono(Model model)
        {
            return model.ImporterForceMono.ToString();
        }
        #endregion

        #region Draw/Compare Compression
        void OnDrawCompression(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.height -= 2;

            if (model.MinBitrate <= 0 || model.ModifiedCompression <= 0)
            {
                EditorGUI2.Label(args.ItemRect, "ERROR", args.Selected, Color.red);
                return;
            }

            var oldenabled = GUI.enabled;
            GUI.enabled = model.ModifiedFormat == AudioImporterFormat.Compressed;

            // EditorGUI.IntSlider has a bug, that it will display the <-> icon even
            // when the control is disabled. So to overcome this problem, we add a cursor rect our own
            if (!GUI.enabled)
                EditorGUIUtility.AddCursorRect(args.ItemRect, MouseCursor.Arrow);

            var oldcolor = GUI.color;
            if (model.ModifiedCompression != model.Compression)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            int newvalue;

            var isxbox360 = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget) == BuildTargetGroup.XBOX360;
            if (isxbox360)
            {
                var xmaquality = Mathf.RoundToInt((model.ModifiedCompression >= 0) ? ((((model.ModifiedCompression) / 1000f) - 56f) / 2f) : 50f);
                newvalue =  (56 + (2 * EditorGUI.IntSlider(args.ItemRect, xmaquality, 1, 100))) * 1000;
            }
            else
            {
                // Unity bug case 538517
                // EditorGUI.IntSlider disppears when column width is smaller than 110 pixels
                newvalue = EditorGUI.IntSlider(args.ItemRect, model.ModifiedCompression / 1000, model.MinBitrate / 1000, model.MaxBitrate / 1000) * 1000;
            }

            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedCompression)
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.ModifiedFormat == AudioImporterFormat.Compressed)
                            model2.ModifiedCompression = Mathf.Clamp(newvalue, model2.MinBitrate, model2.MaxBitrate);
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareCompression(Model x, Model y)
        {
            var result = Mathf.Clamp(x.ModifiedCompression - y.ModifiedCompression, -1, 1);
            return result;
        }

        string OnExportCompression(Model model)
        {
            return (model.Compression/1000).ToString();
        }
        #endregion

        #region Draw/Compare Duration
        void OnDrawDuration(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.DurationString, args.Selected);
        }

        int OnCompareDuration(Model x, Model y)
        {
            return x.Duration.CompareTo(y.Duration);
        }

        string OnExportDuration(Model model)
        {
            return model.DurationString;
        }
        #endregion

        #region Draw/Compare Frequency
        void OnDrawFrequency(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.FrequencyString, args.Selected);
        }

        int OnCompareFrequency(Model x, Model y)
        {
            return x.Frequency.CompareTo(y.Frequency);
        }

        string OnExportFrequency(Model model)
        {
            return model.FrequencyString;
        }
        #endregion

        #region Draw/Compare Channels
        void OnDrawChannels(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.ChannelsString, args.Selected);
        }

        int OnCompareChannels(Model x, Model y)
        {
            return string.Compare(x.ChannelsString, y.ChannelsString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportChannels(Model model)
        {
            return model.ChannelsString;
        }
        #endregion

        #region Draw/Compare Bits per Sample
        void OnDrawBitsPerSample(Model model, GUIListViewDrawItemArgs args)
        {
            if (model.ClipType != AudioType.MPEG)
                EditorGUI2.Label(args.ItemRect, model.BitsPerSampleString, args.Selected);
            else
                EditorGUI2.Label(args.ItemRect, "", args.Selected); // Unity doesn't display anything for MPEG encoded clips, so we do the same
        }

        int OnCompareBitsPerSample(Model x, Model y)
        {
            // MPEG clips don't display bits per second, thus it's a special case we have to handle
            if (x.ClipType == AudioType.MPEG && y.ClipType == AudioType.MPEG)
                return 0;
            if (x.ClipType == AudioType.MPEG && y.ClipType != AudioType.MPEG)
                return 1;
            if (x.ClipType != AudioType.MPEG && y.ClipType == AudioType.MPEG)
                return -1;

            return x.BitsPerSample.CompareTo(y.BitsPerSample);
        }

        string OnExportBitsPerSample(Model model)
        {
            if (model.ClipType != AudioType.MPEG)
                return model.BitsPerSampleString;

            return ""; // Unity doesn't display anything for MPEG encoded clips, so we do the same
        }
        #endregion

        #region Draw/Compare Runtime size
        void OnDrawRuntimeSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.RuntimeSizeString, args.Selected);
        }

        int OnCompareRuntimeSize(Model x, Model y)
        {
            return x.RuntimeSize.CompareTo(y.RuntimeSize);
        }

        string OnExportRuntimeSize(Model model)
        {
            return model.RuntimeSizeString;
        }
        #endregion

        #region Draw/Compare Storage Size
        void OnDrawStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.StorageSizeString, args.Selected);
        }

        int OnCompareStorageSize(Model x, Model y)
        {
            return x.StorageSize.CompareTo(y.StorageSize);
        }


        string OnExportStorageSize(Model model)
        {
            return model.StorageSizeString;
        }
        #endregion

        #region Draw/Compare Original Storage Size
        void OnDrawOrgStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgStorageSizeString, args.Selected);
        }

        int OnCompareOrgStorageSize(Model x, Model y)
        {
            return x.OrgStorageSize.CompareTo(y.OrgStorageSize);
        }

        string OnExportOrgStorageSize(Model model)
        {
            return model.OrgStorageSizeString;
        }
        #endregion

        #region Draw/Compare Path
        void OnDrawAssetPath(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.PathLabel(args.ItemRect, model.AssetPath, args.Selected);
        }

        int OnCompareAssetPath(Model x, Model y)
        {
            return string.Compare(x.AssetPath, y.AssetPath, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetPath(Model model)
        {
            return model.AssetPath;
        }
        #endregion

        #region Draw/Compare GUID
        void OnDrawAssetGuid(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetGuid, args.Selected);
        }

        int OnCompareAssetGuid(Model x, Model y)
        {
            return string.Compare(x.AssetGuid, y.AssetGuid, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetGuid(Model model)
        {
            return model.AssetGuid;
        }
        #endregion

        #region Draw/Compare File extension
        void OnDrawFileExtesion(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.Extension, args.Selected);
        }

        int OnCompareFileExtesion(Model x, Model y)
        {
            return string.Compare(x.Extension, y.Extension, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportFileExtesion(Model model)
        {
            return model.Extension;
        }
        #endregion

        #region Draw/Compare Load type

        static readonly string[] _nativeLoadTypeStrings = new[] { "Load into memory", "Stream from disc" };
        static readonly string[] _compressedLoadTypeStrings = new[] { "Decompress on load", "Compressed in memory", "Stream from disc" };

        void OnDrawLoadType(Model model, GUIListViewDrawItemArgs args)
        {

            var oldcolor = GUI.color;
            if (model.ModifiedLoadType != model.ImporterLoadType)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();

            var newvalue = (int)model.ModifiedLoadType;
            switch (model.ModifiedFormat)
            {
                case AudioImporterFormat.Native:
                    var index = Mathf.Clamp((int)model.ModifiedLoadType-1, 0, 1);
                    newvalue = 1+EditorGUI.Popup(args.ItemRect, index, _nativeLoadTypeStrings);
                    break;
                case AudioImporterFormat.Compressed:
                    newvalue = EditorGUI.Popup(args.ItemRect, (int)model.ModifiedLoadType, _compressedLoadTypeStrings);
                    break;
            }

            if (EditorGUI.EndChangeCheck())
                ModifySelectedItems(delegate(Model model2) { model2.ModifiedLoadType = (AudioImporterLoadType)(newvalue); });

            GUI.color = oldcolor;
        }

        string GetLoadTypeName(AudioImporterFormat format, AudioImporterLoadType loadType)
        {
            switch (format)
            {
                case AudioImporterFormat.Native:
                    var index = Mathf.Clamp((int)loadType - 1, 0, 1);
                    return _nativeLoadTypeStrings[index];

                case AudioImporterFormat.Compressed:
                    return _compressedLoadTypeStrings[(int)loadType];
            }

            return "???";
        }

        int OnCompareLoadType(Model x, Model y)
        {
            string xx = GetLoadTypeName(x.ModifiedFormat, x.ModifiedLoadType);
            string yy = GetLoadTypeName(y.ModifiedFormat, y.ModifiedLoadType);

            return string.Compare(xx, yy, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportLoadType(Model model)
        {
            return GetLoadTypeName(model.ImporterFormat, model.ImporterLoadType);
        }
        #endregion

        #region Draw/Compare Hardware Decoding
        void OnDrawHardwareDecoding(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;

            var isiphone = BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget) == BuildTargetGroup.iPhone;
            var iscompressed = model.ModifiedFormat == AudioImporterFormat.Compressed;
            var oldenabled = GUI.enabled;
            GUI.enabled = isiphone && iscompressed;

            var oldcolor = GUI.color;
            if (model.ModifiedHardwareDecoding != model.ImporterHardwareDecoding)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedHardwareDecoding);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedHardwareDecoding)
                    ModifySelectedItems(delegate(Model model2) { model2.ModifiedHardwareDecoding = newvalue; });
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareHardwareDecoding(Model x, Model y)
        {
            return x.ModifiedHardwareDecoding.CompareTo(y.ModifiedHardwareDecoding);
        }

        string OnExportHardwareDecoding(Model model)
        {
            return model.ImporterHardwareDecoding.ToString();
        }
        #endregion

        #region Draw/Compare Gapless Looping
        void OnDrawGaplessLooping(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;

            var oldenabled = GUI.enabled;
            var iscompressed = model.ModifiedFormat == AudioImporterFormat.Compressed;
            GUI.enabled = iscompressed && model.OrigIsCompressible && (model.OrigCompressedType == AudioType.MPEG || model.OrigCompressedType == AudioType.XMA);
            
            var oldcolor = GUI.color;
            if (model.ModifiedGaplessLooping != model.ImporterGaplessLooping)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedGaplessLooping);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedGaplessLooping)
                    ModifySelectedItems(delegate(Model model2) { model2.ModifiedGaplessLooping = newvalue; });
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareGaplessLooping(Model x, Model y)
        {
            return x.ModifiedGaplessLooping.CompareTo(y.ModifiedGaplessLooping);
        }

        string OnExportGaplessLooping(Model model)
        {
            return model.ImporterGaplessLooping.ToString();
        }
        #endregion

        #region ReimportAll
        /// <summary>
        /// Reimports all audio clips.
        /// </summary>
        public void ReimportAll()
        {
            var allpaths = GetAllPaths();
            AssetDatabase2.Reimport(allpaths, 1, ImportAssetOptions.ForceUpdate);
        }
        #endregion

        #region Apply and revert changes
        /// <summary>
        /// Applies or reverts all modifications.
        /// </summary>
        /// <param name="apply">true to apply, false to revert.</param>
        public void ApplyRevertAll(bool apply)
        {
            var list = GetModifiedModels();
            ApplyRevertChanges(list, apply, true);
        }

        /// <summary>
        /// Applies or reverts modifications of the specified models.
        /// </summary>
        /// <param name="models">The models to apply or revert.</param>
        /// <param name="apply">true to apply, false to revert changes.</param>
        /// <param name="warnmany">Whether to display a confirmation dialog when many models are in the list.</param>
        void ApplyRevertChanges(List<Model> models, bool apply, bool warnmany)
        {
            if (warnmany && models.Count > 10)
            {
                var builder = new StringBuilder(128);
                var count = 0;
                var verb = apply ? "Apply" : "Revert";

                foreach (var model in models)
                {
                    if (count < 3)
                        builder.AppendLine("'" + model.AssetPath + "'");
                    else if (count == 3)
                    {
                        builder.AppendLine("...");
                        break;
                    }
                    count++;
                }

                if (!EditorUtility.DisplayDialog(string.Format("{0} {1} import settings", verb, models.Count), builder.ToString(), verb, "Cancel"))
                    return;
            }

            // remove the activeObject from the selection, so the unity inspector
            // will hopefully not be forced to respond on changes. I noticed the
            // inspector sometimes display a guilayout mismatch error when clip properties
            // get changed in the middle while the inspector is drawing itself.
            var activeobj = Selection.activeObject;
            if (apply)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds;
                Selection.activeObject = null;
            }

            for (var n = 0; n < models.Count; ++n)
            {
                var model = models[n];
                if (apply)
                    model.ApplyChanges();
                else
                    model.RevertChanges();
            }

            if (apply)
            {
                // restore the previously active selection and force a repaint
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds;
                Selection.activeObject = activeobj;
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();

                // make sure changes get properly imported
                AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);
            }
        }
        #endregion

        #region HasModifications
        /// <summary>
        /// Gets whether any model in the specified list is modified.
        /// </summary>
        bool HasModifications(List<Model> list)
        {
            for (var n = 0; n < list.Count; ++n)
            {
                var model = list[n];
                if (model.IsModified)
                    return true;
            }
            return false;
        }
        #endregion

        #region ModifySelectedItems
        /// <summary>
        /// Iterates over every selected model and calls the specified callback for every mode.
        /// </summary>
        /// <param name="callback">The method to call for every model.</param>
        void ModifySelectedItems(Action<Model> callback)
        {
            if (null == callback)
                return;

            var items = GetSelectedModels();
            for (var n = 0; n < items.Count; ++n)
            {
                var item = items[n];
                callback(item);
            }

            DoChanged();
        }
        #endregion

        #region FindModel
        /// <summary>
        /// Finds the model with the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path.</param>
        /// <returns>Returns the model on success, null otherwise.</returns>
        Model FindModel(string assetPath)
        {
            foreach (var item in _allitems)
            {
                if (string.Equals(assetPath, item.AssetPath, StringComparison.OrdinalIgnoreCase))
                    return item;
            }
            return null;
        }
        #endregion

        #region AssetFileWatcher
        /// <summary>
        /// Occurs when an asset has been moved in the project.
        /// </summary>
        void AssetFileWatcher_Moved(string[] oldPaths, string[] newPaths)
        {
            long loadedsize = 0;
            for (var n = 0; n < oldPaths.Length; ++n)
            {
                if (!IsSupportedFile(oldPaths[n]))
                    continue; // not the type of asset we're interested in

                var model = FindModel(oldPaths[n]);
                if (null == model)
                    continue; // it's not in our list

                _allitems.Remove(model);
                _items.Remove(model);

                // this is a new asset, add it to our list
                InitModel(ref model, newPaths[n]);
                _allitems.Add(model);

                // if the asset is visible to the current filter, add it to the filtered list as well
                if (IsIncludedInFilter(model))
                    _items.Add(model);

                CheckUnloadUnused(model, ref loadedsize);
            }

            EditorUtility2.UnloadUnusedAssetsImmediate();
            Sort();

            DoChanged();
            Editor.Repaint();
        }

        /// <summary>
        /// Occurs when an asset has been deleted from the project.
        /// </summary>
        void AssetFileWatcher_Deleted(string[] paths)
        {
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in

                var model = FindModel(path);
                if (null == model)
                    continue; // it's not in our list

                _allitems.Remove(model);
                _items.Remove(model);
            }

            DoChanged();
            Editor.Repaint();
        }

        /// <summary>
        /// Occurs when an asset has been imported into the project.
        /// </summary>
        void AssetFileWatcher_Imported(string[] paths)
        {
            var addeditem = false;
            long loadedsize = 0;

            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in

                // try to find the model
                var model = FindModel(path);
                if (null != model)
                {
                    InitModel(ref model, path);
                    CheckUnloadUnused(model, ref loadedsize);
                    continue;
                }

                // this is a new asset, add it to our list
                InitModel(ref model, path);
                _allitems.Add(model);

                // if the asset is visible to the current filter, add it to the filtered list as well
                if (IsIncludedInFilter(model))
                    _items.Add(model);

                addeditem = true;
                CheckUnloadUnused(model, ref loadedsize);
            }

            EditorUtility2.UnloadUnusedAssetsImmediate();
            if (addeditem)
                Sort();

            DoChanged();
            Editor.Repaint();
        }
        #endregion
    }
}
