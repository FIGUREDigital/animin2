﻿//#define SHOW_RUNTIMESIZE
//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace AudioClipExplorer
{
    /// <summary>
    /// Listbox represents the control that displays audio clip settings.
    /// </summary>
    public class Listbox : GUIListView, IDisposable
    {
        #region class Column
        /// <summary>
        /// The Column class represents one column in the list header.
        /// </summary>
        class Column : GUIListViewColumn
        {
            public enum ColumnMode
            {
                None,
                PlatformSpecific,
                NonPlatformSpecific
            }

            public delegate void DrawDelegate(Model model, GUIListViewDrawItemArgs args);
            public delegate int CompareDelegate2(Model x, Model y);
            public delegate string ExportDelegate(Model model);

            /// <summary>
            /// Occurs when the model should get drawn.
            /// </summary>
            public DrawDelegate Drawer;

            /// <summary>
            /// Occurs when the column gets sorted.
            /// </summary>
            public CompareDelegate2 Comparer;

            /// <summary>
            /// Occurs when the column gets a request to get the item value as text.
            /// </summary>
            public ExportDelegate Exporter;

            /// <summary>
            /// The Mode is used to colorize a column.
            /// </summary>
            public ColumnMode Mode = ColumnMode.None;

            /// <summary>
            /// Initializes a new instance of the Column class.
            /// </summary>
            public Column(string serializeName, string text, string tooltip, float width, DrawDelegate drawer, CompareDelegate2 comparer, ExportDelegate exporter)
                : base(text, tooltip, null, width, null)
            {
                base.SerializeName = serializeName;
                this.Drawer = drawer;
                this.Comparer = comparer;
                this.Exporter = exporter;

                // detour the base comparer callback to our CompareFuncImpl method
                if (null != comparer)
                    this.CompareFunc = CompareFuncImpl;
            }

            int CompareFuncImpl(object x, object y)
            {
                var a = x as Model;
                var b = y as Model;

                // make sure non of the both point to null
                var aisnull = ReferenceEquals(a, null);
                var bisnull = ReferenceEquals(b, null);
                if (aisnull && bisnull) return 0;
                if (!aisnull && bisnull) return 1;
                if (aisnull && !bisnull) return -1;

                // all validation checks passed, now compare the actual values
                return this.Comparer(a, b);
            }
        }
        #endregion

        #region class Model
        /// <summary>
        /// The Model class represents the item-type displayed in the list.
        /// </summary>
        /// <remarks>
        /// To display a certain value, we usually need its string representation. To avoid garbage generation while the plugin is running
        /// due to converting a value to a string every now and then, we make this conversion during initialization only.
        /// </remarks>
        class Model : ICacheFileEntry
        {
            AudioImporter Importer; // the importer of the audio clip
            public bool LoadError; // whether loading the audio clip failed

            public string AssetGuid; // assetdatabase guid
            public ulong AssetTimestamp; // timestamp when the asset/meta file changed

            #region AssetPath
            string _assetPath;
            public string AssetPath
            {
                get
                {
                    if (null == _assetPath)
                        _assetPath = AssetDatabase.GUIDToAssetPath(AssetGuid) ?? "";
                    return _assetPath;
                }
            }
            #endregion

            #region AssetName
            string _assetName;
            public string AssetName // asset filename without file extension
            {
                get
                {
                    if (null == _assetName)
                        _assetName = FileUtil2.GetFileNameWithoutExtension(AssetPath);
                    return _assetName;
                }
            }
            #endregion

            #region Extension
            string _extension;
            public string Extension // file extension
            {
                get
                {
                    if (null == _extension)
                        _extension = FileUtil2.GetFileExtension(AssetPath);
                    return _extension;
                }
            }
            #endregion

            #region StorageSize
            public long StorageSize; // how many bytes the asset consumes on disk inside the unity editor cache
            string _storageSizeString;
            public string StorageSizeString
            {
                get
                {
                    if (null == _storageSizeString)
                        _storageSizeString = EditorUtility2.FormatBytes(StorageSize);
                    return _storageSizeString;
                }
            }
            #endregion

            #region OrgStorageSize
            public long OrgStorageSize; // how many bytes the original asset consumes on disk
            string _orgStorageSizeString;
            public string OrgStorageSizeString
            {
                get
                {
                    if (null == _orgStorageSizeString)
                        _orgStorageSizeString = EditorUtility2.FormatBytes(OrgStorageSize);
                    return _orgStorageSizeString;
                }
            }
            #endregion

            #region UserString0
            /// <summary>
            /// This is a string where the user can assign any text to.
            /// It exists inside AudioClip Explorer only.
            /// It is based on the following feature request:
            ///   ## Could you add tags to clips or make some groups in a manner to order them by specific tag or something?
            ///   ## I had some clips compressed that i needed to decompress in order to make some test about quality.
            ///   ## Then i had to recompress them and i thought it was faster to have clips marked in some way,
            ///   ## in order to know which one should be compressed and which not.
            /// </summary>
            public string UserString0="";
            #endregion

            #region Duration
            /// <summary>
            /// The duration in milliseconds of the clip.
            /// </summary>
            public int Duration;

            string _durationString;
            public string DurationString
            {
                get
                {
                    if (null == _durationString)
                        _durationString = AudioStringUtil.Duration(Duration);
                    return _durationString;
                }
            }
            #endregion

            #region Frequency
            /// <summary>
            /// The frequency in hertz (hz) of the clip.
            /// </summary>
            public int Frequency;

            string _frequencyString;
            public string FrequencyString
            {
                get
                {
                    if (null == _frequencyString)
                        _frequencyString = AudioStringUtil.Frequency(Frequency);
                    return _frequencyString;
                }
            }
            #endregion

            #region BitsPerSample
            public int BitsPerSample;

            string _bitsPerSampleString;
            public string BitsPerSampleString
            {
                get
                {
                    if (null == _bitsPerSampleString)
                        _bitsPerSampleString = AudioStringUtil.BitsPerSample(BitsPerSample);
                    return _bitsPerSampleString;
                }
            }
            #endregion

            #region RuntimeSize
            /// <summary>
            /// How much memory, in bytes, the clip consumes in memory.
            /// </summary>
            public int RuntimeSize;

            string _runtimeSizeString;
            public string RuntimeSizeString
            {
                get
                {
                    if (null == _runtimeSizeString)
                        _runtimeSizeString = AudioStringUtil.Size(RuntimeSize);
                    return _runtimeSizeString;
                }
            }
            #endregion

            #region Channels
            public int Channels;

            public string _channelsString;
            public string ChannelsString
            {
                get
                {
                    if (null == _channelsString)
                        _channelsString = AudioStringUtil.Channels(Channels);
                    return _channelsString;
                }
            }
            #endregion

            public bool ImporterForceMono;
            public bool ImporterLoadInBackground;
            public bool ImporterPreloadAudioData;

            #region ImporterFormat
            public AudioCompressionFormat GetImporterFormat(BuildTargetGroup platform)
            {
                return GetImporterFormat(platform, ImporterSampleSettings);
            }

            public AudioCompressionFormat GetModifiedImporterFormat(BuildTargetGroup platform)
            {
                return GetImporterFormat(platform, ModifiedImporterSampleSettings);
            }

            AudioCompressionFormat GetImporterFormat(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                return settings[(int)platform].SampleSettings.compressionFormat;
            }

            public void SetModifiedImporterFormat(BuildTargetGroup platform, AudioCompressionFormat value)
            {
                ModifiedImporterSampleSettings[(int)platform].SampleSettings.compressionFormat = value;
            }
            #endregion

            #region ImporterLoadType
            public AudioClipLoadType GetImporterLoadType(BuildTargetGroup platform)
            {
                return GetImporterLoadType(platform, ImporterSampleSettings);
            }

            public AudioClipLoadType GetModifiedImporterLoadType(BuildTargetGroup platform)
            {
                return GetImporterLoadType(platform, ModifiedImporterSampleSettings);
            }

            AudioClipLoadType GetImporterLoadType(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                return settings[(int)platform].SampleSettings.loadType;
            }

            public void SetModifiedImporterLoadType(BuildTargetGroup platform, AudioClipLoadType value)
            {
                ModifiedImporterSampleSettings[(int)platform].SampleSettings.loadType = value;
            }
            #endregion

            #region ImporterQuality
            public int GetImporterQuality(BuildTargetGroup platform)
            {
                return GetImporterQuality(platform, ImporterSampleSettings);
            }

            public int GetModifiedImporterQuality(BuildTargetGroup platform)
            {
                return GetImporterQuality(platform, ModifiedImporterSampleSettings);
            }

            int GetImporterQuality(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                return (int)Mathf.Clamp(100 * settings[(int)platform].SampleSettings.quality, 1, 100);
            }

            public void SetModifiedImporterQuality(BuildTargetGroup platform, int value)
            {
                ModifiedImporterSampleSettings[(int)platform].SampleSettings.quality = value * 0.01f;
            }
            #endregion

            #region ImporterOverridden
            public bool GetImporterOverridden(BuildTargetGroup platform)
            {
                return GetImporterOverridden(platform, ImporterSampleSettings);
            }

            public bool GetModifiedImporterOverridden(BuildTargetGroup platform)
            {
                return GetImporterOverridden(platform, ModifiedImporterSampleSettings);
            }

            bool GetImporterOverridden(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                if (platform == BuildTargetGroup.Unknown)
                    return true;

                return settings[(int)platform].Overridden;
            }

            public void SetModifiedImporterOverridden(BuildTargetGroup platform, bool value)
            {
                if (platform == BuildTargetGroup.Unknown)
                    return;

                ModifiedImporterSampleSettings[(int)platform].Overridden = value;
            }
            #endregion

            #region ImporterSampleRateSetting
            public AudioSampleRateSetting GetImporterSampleRateSetting(BuildTargetGroup platform)
            {
                return GetImporterSampleRateSetting(platform, ImporterSampleSettings);
            }

            AudioSampleRateSetting GetImporterSampleRateSetting(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                return settings[(int)platform].SampleSettings.sampleRateSetting;
            }

            public AudioSampleRateSetting GetModifiedImporterSampleRateSetting(BuildTargetGroup platform)
            {
                return GetImporterSampleRateSetting(platform, ModifiedImporterSampleSettings);
            }

            public void SetModifiedImporterSampleRateSetting(BuildTargetGroup platform, AudioSampleRateSetting value)
            {
                ModifiedImporterSampleSettings[(int)platform].SampleSettings.sampleRateSetting = value;
            }
            #endregion

            #region ImporterSampleRate
            public uint GetImporterSampleRate(BuildTargetGroup platform)
            {
                return GetImporterSampleRate(platform, ImporterSampleSettings);
            }

            public uint GetModifiedImporterSampleRate(BuildTargetGroup platform)
            {
                return GetImporterSampleRate(platform, ModifiedImporterSampleSettings);

            }

            uint GetImporterSampleRate(BuildTargetGroup platform, AudioImporterPlatformSettings[] settings)
            {
                return settings[(int)platform].SampleSettings.sampleRateOverride;
            }

            public void SetModifiedImporterSampleRate(BuildTargetGroup platform, uint value)
            {
                ModifiedImporterSampleSettings[(int)platform].SampleSettings.sampleRateOverride = value;
            }
            #endregion

            public bool IsTrackerFile;

            // if the user makes modifications to clip settings, these
            // modifications are set in these Modified... variables and
            // have to be Apply()'ed to actually commit them to Unity.
            public string ModifiedUserString0;
            public bool ModifiedForceMono;
            public bool ModifiedLoadInBackground;
            public bool ModifiedPreloadAudioData;

            public struct AudioImporterPlatformSettings
            {
                // Specifies whether to override settings for the platform.
                public bool Overridden;

                // Unitys platform specific sample settings.
                public AudioImporterSampleSettings SampleSettings;
            }

            // Unity currently supports 22 platforms. Make this array a bit larger,
            // to allow audio clip explorer to start without an out-of-bounds error
            // in case unity adds a new platform and i wasn't fast enough to update the plugin.
            const int ImporterSampleSettingsLength = 32;

            // The original platform specific importer settings.
            // Index into this array using values of BuildTargetGroup.
            public AudioImporterPlatformSettings[] ImporterSampleSettings;

            // The modified platform specific importer settings (does not get serialized).
            // Index into this array using values of BuildTargetGroup.
            public AudioImporterPlatformSettings[] ModifiedImporterSampleSettings;

            /// <summary>
            /// Gets whether the 'Force to Mono' setting can be changed.
            /// </summary>
            public bool CanChangeForceMono()
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile;
            }

            /// <summary>
            /// Gets whether the 'Load in Background' setting can be changed.
            /// </summary>
            public bool CanChangeLoadInBackground()
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile;
            }

            /// <summary>
            /// Gets whether the 'Preload Audio Data' setting can be changed.
            /// </summary>
            public bool CanChangePreloadAudioData()
            {
                if (LoadError)
                    return false;

                return true;// !IsTrackerFile;
            }

            /// <summary>
            /// Gets whether the platform specific 'Override for [Platform]' setting can be changed.
            /// </summary>
            public bool CanChangeOverride(BuildTargetGroup platform)
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile && platform != BuildTargetGroup.Unknown;
            }

            /// <summary>
            /// Gets whether the platform specific 'Load Type' setting can be changed.
            /// </summary>
            public bool CanChangeLoadType(BuildTargetGroup platform)
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile && GetModifiedImporterOverridden(platform);
            }

            /// <summary>
            /// Gets whether the platform specific 'Compression Format' setting can be changed.
            /// </summary>
            public bool CanChangeFormat(BuildTargetGroup platform)
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile && GetModifiedImporterOverridden(platform);
            }

            /// <summary>
            /// Gets whether the 'Quality' setting can be changed.
            /// </summary>
            public bool CanChangeQuality(BuildTargetGroup platform)
            {
                if (LoadError)
                    return false;

                var iscompressed = IsCompressed(platform);
                if (IsTrackerFile || !iscompressed)
                    return false;

                return iscompressed && GetModifiedImporterOverridden(platform);
            }

            /// <summary>
            /// Gets whether the 'Sample Rate' setting can be changed.
            /// </summary>
            public bool CanChangeSampleRate(BuildTargetGroup platform)
            {
                if (LoadError)
                    return false;

                return !IsTrackerFile && GetModifiedImporterOverridden(platform);
            }

            /// <summary>
            /// Gets whether the 'Temp String' setting can be changed.
            /// </summary>
            public bool CanChangeUserString()
            {
                if (LoadError)
                    return false;

                return true;
            }

            /// <summary>
            /// Gets whether the clip is compressed for the specified platform.
            /// </summary>
            public bool IsCompressed(BuildTargetGroup platform)
            {
                switch (GetModifiedImporterFormat(platform))
                {
                    case AudioCompressionFormat.MP3:
                    case AudioCompressionFormat.Vorbis:
                        return true;
                }

                return false;
            }

            #region IsModified
            /// <summary>
            /// Gets whether any property of the clip has modifications.
            /// </summary>
            public bool IsModified()
            {
                for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                {
                    var platform = (BuildTargetGroup)n;
                    if (IsModified(platform, false))
                        return true;
                }

                return false;
            }

            /// <summary>
            /// Gets whether an AudioClipImporter related property has modifications.
            /// </summary>
            public bool IsImporterModified()
            {
                for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                {
                    var platform = (BuildTargetGroup)n;
                    if (IsModified(platform, true))
                        return true;
                }

                return false;
            }

            /// <summary>
            /// Gets whether the audio importer has modifications inside AudioClip Explorer.
            /// </summary>
            bool IsModified(BuildTargetGroup platform, bool importerOnly)
            {
                if (ModifiedForceMono != ImporterForceMono)
                    return true;

                if (ModifiedLoadInBackground != ImporterLoadInBackground)
                    return true;

                if (ModifiedPreloadAudioData != ImporterPreloadAudioData)
                    return true;

                if (GetModifiedImporterFormat(platform) != GetImporterFormat(platform))
                    return true;

                if (GetModifiedImporterOverridden(platform) != GetImporterOverridden(platform))
                    return true;

                if (GetModifiedImporterQuality(platform) != GetImporterQuality(platform))
                    return true;

                if (GetModifiedImporterLoadType(platform) != GetImporterLoadType(platform))
                    return true;

                if (GetModifiedImporterSampleRate(platform) != GetImporterSampleRate(platform))
                    return true;

                if (GetModifiedImporterSampleRateSetting(platform) != GetImporterSampleRateSetting(platform))
                    return true;

                if (!importerOnly)
                {
                    if (!string.Equals(UserString0, ModifiedUserString0))
                        return true;
                }

                return false;
            }
            #endregion

            #region ICacheFileEntry Implementation
            public string GetAssetGuid()
            {
                return AssetGuid;
            }

            public ulong GetAssetTimestamp()
            {
                return AssetTimestamp;
            }

            public void Serialize(BinarySerializer data)
            {
                if (data.IsReader)
                    ResetVariables();

                data.Serialize(ref AssetGuid);
                data.Serialize(ref AssetTimestamp);
                data.Serialize(ref LoadError);
                data.Serialize(ref StorageSize);
                data.Serialize(ref OrgStorageSize);
                data.Serialize(ref Duration);
                data.Serialize(ref Frequency);
                data.Serialize(ref BitsPerSample);
                data.Serialize(ref RuntimeSize);
                data.Serialize(ref Channels);
                data.Serialize(ref UserString0);
                data.Serialize(ref ImporterForceMono);
                data.Serialize(ref ImporterLoadInBackground);
                data.Serialize(ref ImporterPreloadAudioData);
                data.Serialize(ref IsTrackerFile);

                #region (De)Serialize platform specific importer settings
                if (data.IsReader)
                {
                    ImporterSampleSettings = new AudioImporterPlatformSettings[ImporterSampleSettingsLength];
                    ModifiedImporterSampleSettings = new AudioImporterPlatformSettings[ImporterSampleSettingsLength];
                }

                for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                {
                    var settings = ImporterSampleSettings[n];
                    data.Serialize(ref settings.Overridden);

                    data.SerializeEnum(ref settings.SampleSettings.compressionFormat);
                    data.Serialize(ref settings.SampleSettings.conversionMode);
                    data.SerializeEnum(ref settings.SampleSettings.loadType);
                    data.Serialize(ref settings.SampleSettings.quality);
                    data.Serialize(ref settings.SampleSettings.sampleRateOverride);
                    data.SerializeEnum(ref settings.SampleSettings.sampleRateSetting);

                    ImporterSampleSettings[n] = settings;
                }
                
                if (data.IsReader)
                {
                    for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                        ModifiedImporterSampleSettings[n] = ImporterSampleSettings[n];
                }
                #endregion
            }
            #endregion

            #region ResetVariables
            /// <summary>
            /// Sets variables to default values.
            /// </summary>
            void ResetVariables()
            {
                Frequency = -1;
                Duration = -1;
                LoadError = false;
                RuntimeSize = -1;
                Channels = -1;

                _assetPath = null;
                _assetName = null;
                _extension = null;
                _storageSizeString = null;
                _orgStorageSizeString = null;
                _durationString = null;
                _frequencyString = null;
                _bitsPerSampleString = null;
                _runtimeSizeString = null;
                _channelsString = null;
                _orgStorageSizeString = null;
                AssetTimestamp = 0;
                AssetGuid = "";
                //UserString0 = "";
            }
            #endregion

            #region Init
            /// <summary>
            /// Initializes the Model instance with the specified path.
            /// </summary>
            public void Init(string path)
            {
                ResetVariables();

                var importer = AudioImporter.GetAtPath(path) as AudioImporter;
                if (importer == null)
                {
                    Debug.LogError(string.Format("AudioClip Explorer: Could not get AudioImporter for '{0}'.", path??"<null>"));
                    _assetPath = path;
                    LoadError = true;
                    RevertChanges();
                    return;
                }

                Importer = importer;
                AssetGuid = AssetDatabase.AssetPathToGUID(importer.assetPath);
                AssetTimestamp = importer.assetTimeStamp;


                // Allocate memory for platform sample settings.
                ImporterSampleSettings = new AudioImporterPlatformSettings[ImporterSampleSettingsLength];

                // Get default sample settings. Note we abuse the 'Unknown' platform as the default.
                ImporterSampleSettings[(int)BuildTargetGroup.Unknown].SampleSettings = Importer.defaultSampleSettings;

                // get importer settings for each platform override.
                var platforms = BuildPlayerWindow2.GetValidPlatforms();
                for (var n = 0; n < platforms.Count; ++n)
                {
                    var platform = platforms[n];
                    var platformId = (int)platform.TargetGroup;
                    ImporterSampleSettings[platformId].SampleSettings = Importer.defaultSampleSettings;

                    // In case the default compression format is not supported on this platform,
                    // make sure to use the default compression format for this particular platform (eg WebGL supports MP3 only, but default is usually Vorbis)
                    if (!AudioUtil2.IsPlatformCompressionFormatSupported(platform.TargetGroup, ImporterSampleSettings[platformId].SampleSettings.compressionFormat))
                        ImporterSampleSettings[platformId].SampleSettings.compressionFormat = AudioUtil2.GetPlatformDefaultCompressionFormat(platform.TargetGroup);

                    ImporterSampleSettings[platformId].Overridden = Importer.ContainsSampleSettingsOverride(platform.Name);
                    if (!ImporterSampleSettings[platformId].Overridden)
                        continue;

                    ImporterSampleSettings[platformId].SampleSettings = Importer.GetOverrideSampleSettings(platform.Name);
                }

                // Set modified settings to the current importer settings
                ModifiedImporterSampleSettings = new AudioImporterPlatformSettings[ImporterSampleSettingsLength];
                for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                    ModifiedImporterSampleSettings[n] = ImporterSampleSettings[n];

                // Read importer settings
                StorageSize = AudioImporter2.GetImportedSize(importer);
                OrgStorageSize = FileUtil2.GetFileSize(importer.assetPath);

                var clip = AssetDatabase.LoadAssetAtPath(AssetPath, typeof(AudioClip)) as AudioClip;
                if (null != clip)
                {
                    Duration = (int)(clip.length * 1000); // convert seconds to milliseconds
                    BitsPerSample = AudioUtil2.GetBitsPerSample(clip);
                    Frequency = clip.frequency;
                    RuntimeSize = AudioUtil2.GetSize(clip);
                    Channels = clip.channels;
                    IsTrackerFile = AudioUtil2.IsTrackerFile(clip);
                }
                else
                {
                    LoadError = true;
                    Debug.LogError(string.Format("AudioClip Explorer: Could not load AudioClip '{0}'. Is the sound file broken?", AssetPath ?? "<null>"));
                }

                ImporterForceMono = Importer.forceToMono;
                ImporterLoadInBackground = Importer.loadInBackground;
                ImporterPreloadAudioData = Importer.preloadAudioData;
                
                // All changes the user makes in AudioClip Explorer
                // operate on the 'Modified...' variables. The initial values
                // must be the current importer values obviously.
                RevertChanges();
            }
            #endregion

            #region RevertChanges
            /// <summary>
            /// Reverts audio importer modifications.
            /// </summary>
            public void RevertChanges()
            {
                // Settings inside AudioClip Explorer only
                ModifiedUserString0 = UserString0;

                // Importer settings
                ModifiedForceMono = ImporterForceMono;
                ModifiedLoadInBackground = ImporterLoadInBackground;
                ModifiedPreloadAudioData = ImporterPreloadAudioData;

                for (var n = 0; n < ImporterSampleSettings.Length; ++n)
                {
                    ModifiedImporterSampleSettings[n].Overridden = ImporterSampleSettings[n].Overridden;
                    ModifiedImporterSampleSettings[n].SampleSettings = ImporterSampleSettings[n].SampleSettings;
                }
            }
            #endregion

            #region ApplyChanges
            /// <summary>
            /// Applies audio importer modifications to Unity.
            /// </summary>
            public void ApplyChanges()
            {
                // Update settings that exist inside this plugin only
                UserString0 = ModifiedUserString0;


                // Update importer settings
                if (!IsImporterModified())
                    return;

                if (Importer == null)
                    Importer = AudioImporter.GetAtPath(AssetPath) as AudioImporter;

                // Apply platform independend changes.
                Importer.forceToMono = ModifiedForceMono;
                Importer.loadInBackground = ModifiedLoadInBackground;
                Importer.preloadAudioData = ModifiedPreloadAudioData;

                // Unknown represents default settings.
                if (IsModified(BuildTargetGroup.Unknown, true))
                {
                    Importer.defaultSampleSettings = ModifiedImporterSampleSettings[(int)BuildTargetGroup.Unknown].SampleSettings;
                }

                // Apply platform specific changes.
                var platforms = BuildPlayerWindow2.GetValidPlatforms();
                for (var n=0; n<platforms.Count; ++n)
                {
                    var platformName = platforms[n].Name;
                    var platform = platforms[n].TargetGroup;

                    if (!IsModified(platform, true))
                        continue;

                    // Unknown represents default settings.
                    if (platform == BuildTargetGroup.Unknown)
                        continue;
 
                    // Do we want to override sample settings for this platform?
                    if (GetModifiedImporterOverridden(platform))
                    {
                        if (GetModifiedImporterSampleRateSetting(platform) != AudioSampleRateSetting.OverrideSampleRate)
                            SetModifiedImporterSampleRate(platform, GetImporterSampleRate(platform));

                        Importer.SetOverrideSampleSettings(
                            platformName,
                            ModifiedImporterSampleSettings[(int)platform].SampleSettings);
                    }
                    else
                    {
                        // No override, clear with default settings.
                        Importer.ClearSampleSettingOverride(platformName);
                    }
                }

                EditorUtility.SetDirty(Importer);
                Importer.SaveAndReimport();
            }
            #endregion
        }
        #endregion

        #region Private Fields
        // the color used to highlight modified values
        static Color ModifiedValueColor
        {
            get
            {
                return GUIColors.TintIfPlaying(new Color(1.0f, 0.65f, 0.65f));
            }
        }

        List<Model> _items = new List<Model>();
        List<Model> _allitems = new List<Model>();
        List<Model> _loadeditems = new List<Model>();
        SearchTextParser.Result _filterResult = new SearchTextParser.Result();
        bool _disposed;
        FilterMode _filterMode;
        CacheFile<Model> _cache = new CacheFile<Model>(500, Globals.ProductName, Globals.ProductId);
        #endregion

        /// <summary>
        /// The FilterMode indicates which property the search function
        /// considers for text matching.
        /// </summary>
        public enum FilterMode
        {
            Name = 0, // Search in name
            Path = 1, // Search in path
            Guid // Search in guid
        }

        /// <summary>
        /// Occurs whenever the listbox content changed.
        /// </summary>
        public Action<Listbox> Changed;

        /// <summary>
        /// Gets the number of items in the list.
        /// </summary>
        public int ItemCount
        {
            get
            {
                return _items.Count;
            }
        }

        /// <summary>
        /// Gets a pretty string how many items are in the list.
        /// </summary>
        public string ItemCountString
        {
            get
            {
                var filtered = _items.Count / _platforms.Count;
                var all = _allitems.Count / _platforms.Count;

                if (filtered != all)
                    return string.Format("{0}/{1} AudioClips", filtered, all);
                return string.Format("{0} AudioClips", filtered);
            }
        }

        /// <summary>
        /// Gets a string describing the selected items in the list.
        /// </summary>
        public string SelectionString
        {
            get
            {
                if (SelectedItemsCount == 0)
                    return "";

                var models = GetSelectedModels();
                if (SelectedItemsCount == 1)
                    return models[0].AssetPath;

                long storagesize;
                long runtimesize;
                GetSummedSize(models, out storagesize, out runtimesize);
#if SHOW_RUNTIMESIZE
                return string.Format("{0} selected | Storage: {1} | Runtime: {2}",
                    models.Count,
                    EditorUtility2.FormatBytes(storagesize),
                    runtimesize < 0 ? "???" : EditorUtility2.FormatBytes(runtimesize));
#else
                return string.Format("{0} selected | Storage: {1}",
                    models.Count,
                    EditorUtility2.FormatBytes(storagesize));
#endif
            }
        }

        /// <summary>
        /// Gets whether any settings have been modified and not applied yet.
        /// </summary>
        public bool IsModified
        {
            get
            {
                var list = GetModifiedModels();
                return list.Count > 0;
            }
        }

        /// <summary>
        /// A value indication at which time the UnityEditor.Selection has been assigned.
        /// </summary>
        /// <remarks>
        /// If the user double-clicks an item in AudioClip Explorer, we assign it to UnityEditor.Selection.
        /// But on the same hand, AudioClip Explorer can listen to selection changes in Unity to automatically
        /// display the selected items. To avoid that 'feedback loop', we assign the time to this variable
        /// when the user double-clicks an item in the list and the selection change listening code can check
        /// if the selection change came from this list.
        /// </remarks>
        public double ChangeUnitySelectionTime
        {
            get;
            private set;
        }

        /// <summary>
        /// The active build target platform group.
        /// </summary>
        public BuildTargetGroup PlatformGroup
        {
            get;
            private set;
        }

        /// <summary>
        /// Gets platforms settings of the currently selected platform for the specified model.
        /// </summary>
        /// <param name="modelindex">The model index.</param>
        /// <returns>The platform.</returns>
        BuildTargetGroup GetPlatform(int modelindex)
        {
            if (_platforms.Count > 1)
                return _platforms[(modelindex % _platforms.Count)];

            return PlatformGroup;
        }

        #region ctor
        /// <summary>
        /// Initializes a new instance of the Listbox class.
        /// </summary>
        /// <param name="editor">The EditorWindow where this control resides in.</param>
        /// <param name="parent">The parent container of the control or null when it's a top-level control.</param>
        public Listbox(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            HeaderStyle = GUIListViewHeaderStyle.ClickablePopup;
            MultiSelect = true;
            DragDropEnabled = true;
            RightClickSelect = true;
            Mode = GUIListViewMode.Details;
            ItemSize = new Vector2(0, 22);
            FullRowSelect = true;

            // Add the columns
            Columns.Add(new Column("Name", "Name", "Asset name", 220, OnDrawAssetName, OnCompareAssetName, OnExportAssetName));
            Columns.Add(new Column("Path", "Path", "Full asset path, including file extension.", 360, OnDrawAssetPath, OnCompareAssetPath, OnExportAssetPath) { Visible = false });
            Columns.Add(new Column("GUID", "GUID", "Asset GUID (Global Unique Identifier).", 300, OnDrawAssetGuid, OnCompareAssetGuid, OnExportAssetGuid) { Visible = false });

            Columns.Add(new Column("ForceMono", "Force Mono", "Force this clip to mono?", 75, OnDrawForceMono, OnCompareForceMono, OnExportForceMono) { Mode = Column.ColumnMode.NonPlatformSpecific });
            Columns.Add(new Column("LoadInBackground", "Load in BG", "Corresponding to the 'Load In Background' flag in the AudioClip inspector, when this flag is set, the loading of the clip will happen delayed without blocking the main thread.", 75, OnDrawLoadInBackground, OnCompareLoadInBackground, OnExportLoadInBackground) { Mode = Column.ColumnMode.NonPlatformSpecific });
            Columns.Add(new Column("PreloadAudioData", "Preload", "Preloads audio data of the clip when the clip asset is loaded. When this flag is off, scripts have to call AudioClip.LoadAudioData() to load the data before the clip can be played. Properties like length, channels and format are available before the audio data has been loaded.", 75, OnDrawPreloadAudioData, OnComparePreloadAudioData, OnExportPreloadAudioData) { Mode = Column.ColumnMode.NonPlatformSpecific });

            Columns.Add(new Column("Override", "Override", "Override sample settings for selected platform.", 75, OnDrawOverride, OnCompareOverride, OnExportOverride) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("LoadType", "Load Type", "LoadType defines how the imported AudioClip data should be loaded.", 150, OnDrawLoadType, OnCompareLoadType, OnExportLoadType) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("Format", "Format", "Format defines the compression type that the audio file is encoded to. Different compression types have different performance and audio artifact characteristics.", 110, OnDrawFormat, OnCompareFormat, OnExportFormat) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("Quality", "Quality", "Audio compression quality amount of compression. The value roughly corresponds to the ratio between the resulting and the source file sizes.", 230, OnDrawQuality, OnCompareQuality, OnExportQuality) { Mode = Column.ColumnMode.PlatformSpecific });
            Columns.Add(new Column("SampleRate", "Sample Rate", "Defines how the sample rate is modified (if at all) of the importer audio file. The 'Sample Rate' column combines the 'Sample Rate Setting' and 'Sample Rate' properties in Unity's AudioClip inspector.", 100, OnDrawSampleRate, OnCompareSampleRate, OnExportSampleRate) { Mode = Column.ColumnMode.PlatformSpecific });

            Columns.Add(new Column("Frequency", "Frequency", "Sample frequency of the AudioClip in Hz.", 80, OnDrawFrequency, OnCompareFrequency, OnExportFrequency));
            Columns.Add(new Column("Channels", "Channels", "The number of channels in the AudioClip, such as Mono, Stereo or multiple channels like 5.1.", 60, OnDrawChannels, OnCompareChannels, OnExportChannels));
            Columns.Add(new Column("Bits per Sample", "Bits per Sample", "Bits per Sample", 100, OnDrawBitsPerSample, OnCompareBitsPerSample, OnExportBitsPerSample));
            Columns.Add(new Column("Duration", "Duration", "The duration of the AudioClip.", 80, OnDrawDuration, OnCompareDuration, OnExportDuration));
#if SHOW_RUNTIMESIZE
            Columns.Add(new Column("Runtime Size", "Runtime Size", "The size the AudioClip consumes in memory.", 85, OnDrawRuntimeSize, OnCompareRuntimeSize, OnExportRuntimeSize));
#endif
            Columns.Add(new Column("Storage Size", "Storage Size", "The size of  the AudioClip on disk, after it went through the import-process, as stored in Unity's editor cache.\n\nThis a good estimate of the actual file size used on the storage device.", 80, OnDrawStorageSize, OnCompareStorageSize, OnExportStorageSize));
            Columns.Add(new Column("Original Storage Size", "Original Storage Size", "The size of the source asset on disk, before it went through the Unity import-process. Basically the file-size of the wav, ogg, mp3, etc.", 130, OnDrawOrgStorageSize, OnCompareOrgStorageSize, OnExportOrgStorageSize) { Visible = false });
            Columns.Add(new Column("Extension", "Extension", "The file extension.", 70, OnDrawFileExtesion, OnCompareFileExtesion, OnExportFileExtesion) { Visible = false });
            //Columns.Add(new Column("CustomString0", "Temp String", "This is a text you can assign to each item, which exists inside AudioClip Explorer only and should be treated as a temporary text only. This text is most likely to get cleared if you upgrade to a new plugin version. You can use this, for example, to temporarily mark certain items.", 130, OnDrawUserString0, OnCompareUserString0, OnExportUserString0) { Visible = false });

            // Colorize columns that contain platform settings
            for (var n = 0; n < Columns.Count; ++n)
            {
                var column = Columns[n] as Column;
                if (column.Mode == Column.ColumnMode.PlatformSpecific)
                {
                    var tint = new Color(0.3f, 0.3f, 1, 0.06f);
                    if (EditorGUIUtility.isProSkin)
                        tint = new Color(0.7f, 0.7f, 1, 0.06f);

                    column.Color = GUIColors.TintIfPlaying(tint);
                }
            }

            #region Build a list with all compression formats supported by all platforms
            var platforms = new List<BuildTargetGroup>(BuildPlayerWindow2.GetValidPlatformGroups());
            platforms.Add(BuildTargetGroup.Unknown); // default

            _PlatformCompressionFormatValues = new int[32][];
            _PlatformCompressionFormatStrings = new string[32][];
            foreach (var group in platforms)
            {
                var pindex = (int)group;
                var formats = AudioUtil2.GetPlatformCompressionFormats(group);
                formats.Sort(delegate(AudioCompressionFormat x, AudioCompressionFormat y)
                {
                    return string.Compare(x.ToString(), y.ToString(), StringComparison.OrdinalIgnoreCase);
                });

                _PlatformCompressionFormatValues[pindex] = new int[formats.Count];
                _PlatformCompressionFormatStrings[pindex] = new string[formats.Count];
                for (var n = 0; n < formats.Count; ++n)
                {
                    _PlatformCompressionFormatValues[pindex][n] = (int)formats[n];
                    _PlatformCompressionFormatStrings[pindex][n] = formats[n].ToString();
                }
            }
            #endregion

            // Hook into the asset pipeline, since we need to update the list in case the user deletes,
            // moves or imports assets while AudioClip Explorer is running.
            AssetFileWatcher.Imported += AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted += AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved += AssetFileWatcher_Moved;
        }
        #endregion

        #region Dispose
        public void Dispose()
        {
            if (_disposed)
                return;

            // check if cache is empty to avoid overwriting a cache file with no data.
            // in case the plugin crashed and wasn't able to fill the cache.
            if (!_cache.IsEmpty)
                _cache.Write();

            AssetFileWatcher.Imported -= AssetFileWatcher_Imported;
            AssetFileWatcher.Deleted -= AssetFileWatcher_Deleted;
            AssetFileWatcher.Moved -= AssetFileWatcher_Moved;

            _cache = null;
            _items = null;
            _allitems = null;
            _disposed = true;
            GC.SuppressFinalize(this);
        }
        #endregion

        #region OnLoadPrefs
        /// <summary>
        /// Called when the list reads its preferences from EditorPrefs.
        /// </summary>
        protected override void OnLoadPrefs()
        {
            base.OnLoadPrefs();

            _platforms.Clear();
            PlatformGroup = BuildTargetGroup.Unknown;
            var platforms = EditorPrefs2.GetIntArray(string.Format("{0}.platforms", EditorPrefsPath), new[]{0});
            for (var n = 0; n < platforms.Length; ++n)
                AddPlatform((BuildTargetGroup)platforms[n]);

            if (_platforms.Count > 0)
                PlatformGroup = _platforms[0];
        }
        #endregion

        #region OnSavePrefs
        /// <summary>
        /// Called when the list writes its preferences to EditorPrefs.
        /// </summary>
        protected override void OnSavePrefs()
        {
            base.OnSavePrefs();

            var platforms = new int[_platforms.Count];
            for (var n = 0; n < _platforms.Count; ++n)
                platforms[n] = (int)_platforms[n];

            EditorPrefs2.SetIntArray(string.Format("{0}.platforms", EditorPrefsPath), platforms);
        }
        #endregion

        #region ReadCacheFile
        /// <summary>
        /// Reads the cache file to speed up the SetItems() method.
        /// </summary>
        public void ReadCacheFile()
        {
            _cache.Read();
        }
        #endregion

        #region GetSummedSize
        /// <summary>
        /// Gets the summed size of all clips specified by models.
        /// </summary>
        void GetSummedSize(List<Model> models, out long storagesize, out long runtimesize)
        {
            storagesize = 0;
            runtimesize = 0;
            foreach (var model in models)
            {
                storagesize += model.StorageSize;
                if (runtimesize > -1) // -1 means value not set
                {
                    runtimesize += model.RuntimeSize;
                    if (model.RuntimeSize < 0)
                        runtimesize = -1;
                }
            }
        }
        #endregion

        #region TryShowApplyRevertSettings
        /// <summary>
        /// Must be called when the editor is going to switch into play mode
        /// and when the window is about to close.
        /// </summary>
        public void TryShowApplyRevertSettings(bool showcancel, Action oncancel)
        {
            var builder = new StringBuilder(128);

            builder.AppendLine("Unapplied import settings for");

            // build a string containing the path of the first three modified clips.
            var modified = new List<Model>();
            foreach (var model in _allitems)
            {
                if (model.IsModified())
                {
                    modified.Add(model);
                    if (modified.Count < 3)
                        builder.AppendLine("'" + model.AssetPath + "'");
                    else if (modified.Count == 3)
                        builder.AppendLine("...");
                }
            }

            if (modified.Count == 0)
                return; // no modifications, nothing to do

            var title = string.Format("{0} unapplied import settings", modified.Count);
            var applytext = "Apply";
            var reverttext = "Revert";
            if (showcancel)
            {
                var result = EditorUtility.DisplayDialogComplex(title, builder.ToString(), applytext, reverttext, "Cancel");
                switch (result)
                {
                    case 0: // Apply
                        ApplyRevertChanges(modified, true, false);
                        break;
                    case 1: // Revert
                        ApplyRevertChanges(modified, false, false);
                        break;
                    case 2: // Cancel
                        if (null != oncancel)
                            oncancel();
                        break;
                }
            }
            else
            {
                if (EditorUtility.DisplayDialog(title, builder.ToString(), applytext, reverttext))
                    ApplyRevertChanges(modified, true, false);
                else
                    ApplyRevertChanges(modified, false, false);
            }
        }
        #endregion

        #region DoChanged
        /// <summary>
        /// Raises the Changed event.
        /// Call this method to notify subscribers about list content or state changes.
        /// </summary>
        void DoChanged()
        {
            if (null != Changed)
            {
                var cb = Changed;
                cb.Invoke(this);
            }
        }
        #endregion

        #region IsSupportedFile
        /// <summary>
        /// Gets whether the asset of the specified path is supported to be displayed in AudioClip Explorer.
        /// </summary>
        /// <param name="path">The relative asset path</param>
        bool IsSupportedFile(string path)
        {
            if (!AssetDatabase2.IsAssetType(path, typeof(AudioClip)))
                return false;
            return true;
        }
        #endregion

        #region CheckUnloadUnused
        /// <summary>
        /// Call this method after every AudioClip that has been loaded. It sums the sizes of the loaded
        /// clips and makes sure to unload those when a certail memory consumtion threshold
        /// has been reached. This makes AudioClip Explorer able to display settings of audio clips of any number.
        /// </summary>
        void CheckUnloadUnused(Model model, ref long loadedsize)
        {
            if (null == model)
                return;

            loadedsize += model.StorageSize;
            if (loadedsize > 256 * 1024 * 1024)
            {
                _cache.Write();
                EditorUtility2.UnloadUnusedAssetsImmediate();
                loadedsize = 0;
            }
        }
        #endregion

        #region SetItems
        /// <summary>
        /// Sets the audio clips that should be shown in AudioClip Explorer.
        /// </summary>
        /// <param name="paths">The asset paths of assets to add to the list.</param>
        public void SetItems(List<string> paths)
        {
            UnityEngine.Profiler.BeginSample("Listbox.SetItems");
            Reset();

            if (_platforms.Count == 0)
                _platforms.Add(PlatformGroup);

            _loadeditems = new List<Model>(paths.Count);
            _allitems = new List<Model>(paths.Count);

            // build a list with compatible assets
            var clippaths = new List<string>(paths.Count);
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue;
                clippaths.Add(path);
            }

            _cache.BeginGetEntry();
            try
            {
                UnityEngine.Profiler.BeginSample("Listbox.SetItems");

                // now add each item to the list
                using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
                {
                    // indicates how many bytes are loaded during initialization
                    // and is used to release memory at some threshold to prevent the
                    // editor to crash with an out-of-mem exception.
                    long loadedsize = 0;

                    for (var n = 0; n < clippaths.Count; ++n)
                    {
                        var path = clippaths[n];

                        // report the progress to the user, since it can be a time consuming operation to read many clips.
                        if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                        {
                            var progress = n / (float)clippaths.Count;
                            var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(path), clippaths.Count - n - 1);
                            if (progressbar.Update(text, progress))
                                break;
                        }

                        // initialize the model-representation
                        Model item = null;
                        if (!InitModel(ref item, path))
                        {
                            // we are here when the model wasn't fetched from the cache.
                            // this means we actually needed to read the texture into memory to get its settings. 
                            // we need to release unused memory eventually, otherwise Unity will crash.
                            CheckUnloadUnused(item, ref loadedsize);
                        }

                        _loadeditems.Add(item);
                    }

                    // if it actually loaded new clip settings make
                    // sure to save the cache file
                    if (loadedsize > 0)
                        _cache.Write();
                }

                UnityEngine.Profiler.EndSample();
            }
            finally
            {
                _cache.EndGetEntry();
            }

            UpdateItemLists();

            UnityEngine.Profiler.EndSample();
        }
        #endregion

        void UpdateItemLists()
        {
            _allitems = new List<Model>();
            for (var j = 0; j < _platforms.Count; ++j)
                _allitems.AddRange(_loadeditems);

            _items = new List<Model>(_allitems);
            Sort();
            DoChanged();
        }

        #region Search/Filter the list
        /// <summary>
        /// Filters the list using the specified text and mode.
        /// </summary>
        /// <param name="text">The text a item must contain to match.</param>
        /// <param name="mode">The mode, in which property of the model, the search should check.</param>
        public void SetFilter(string text, FilterMode mode)
        {
            var parserresult = SearchTextParser.Parse(text);
            SetFilter(parserresult, mode);
        }

        void SetFilter(SearchTextParser.Result parserresult, FilterMode mode)
        {
            _filterResult = parserresult;
            _filterMode = mode;

            // if the filter is empty, all items are visible.
            _items = new List<Model>(_allitems.Count);
            if (_filterResult.Names.Count == 0)
            {
                _items.AddRange(_allitems);
                DoChanged();
                return;
            }

            // check each item if it's visible.
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var item = _allitems[n];
                if (IsIncludedInFilter(item))
                    _items.Add(item);
            }

            DoChanged();
        }

        /// <summary>
        /// Gets whether the specified model matchs the filter criteria.
        /// </summary>
        /// <returns>true when the filter is matching and the item has to be included in the list, false otherwise.</returns>
        bool IsIncludedInFilter(Model model)
        {
            if (_filterResult.NamesExpr.Count == 0)
                return true;

            var modelname = model.AssetName;
            switch (_filterMode)
            {
                case FilterMode.Path: modelname = model.AssetPath; break;
                case FilterMode.Guid: modelname = model.AssetGuid; break;
            }

            return _filterResult.IsNameMatch(modelname);
        }
        #endregion

        #region InitModel
        /// <summary>
        /// Initializes the specified model with the specified importer.
        /// </summary>
        bool InitModel(ref Model model, string path)
        {
            if (null == model)
            {
                // try to get it from the cache
                var guid = AssetDatabase.AssetPathToGUID(path);
                if (_cache.TryGetEntry(guid, PlatformGroup, out model, true))
                {
                    model.RevertChanges(); // just to set the initial variables where we work on for changes
                    return true;
                }

                model = new Model();
            }

            // it's not located in cache, initialize it the expensive way
            model.Init(path);
            _cache.UpdateEntry(model, PlatformGroup);
            return false;
        }
        #endregion

        #region Helper methods to get selected paths/models/clips
        /// <summary>
        /// Gets all models that are currently selected.
        /// </summary>
        /// <returns></returns>
        List<Model> GetSelectedModels()
        {
            var selection = SelectedItems;
            var models = new List<Model>();
            foreach (var item in selection)
            {
                var model = item as Model;
                if (null != model)
                    models.Add(model);
            }
            return models;
        }

        /// <summary>
        /// Gets all modified models of the current selection.
        /// </summary>
        List<Model> GetSelectedModifiedModels()
        {
            var models = GetSelectedModels();
            var modified = new List<Model>();
            for (var n = 0; n < models.Count; ++n)
            {
                var model = models[n];
                if (model.IsModified())
                    modified.Add(model);
            }
            return modified;
        }

        /// <summary>
        /// Gets all modified models.
        /// </summary>
        List<Model> GetModifiedModels()
        {
            var modified = new List<Model>();
            for (var n = 0; n < _allitems.Count; ++n)
            {
                var model = _allitems[n];
                if (model.IsModified())
                    modified.Add(model);
            }
            return modified;
        }

        /// <summary>
        /// Gets all audio clips that are currently selected in AudioClip Explorer.
        /// </summary>
        /// <remarks>
        /// To return the AudioClip, the asset actually needs to be loaded into memory.
        /// This can be an expensive operation and since Unity is 32bit only, it might even
        /// crash the editor when you try to get/load more audio clips into memory than there
        /// is available due to the 32bit limit.
        /// Unlike the Unity editor, we display a progressbar during this time, so it won't look like
        /// the editor freezed when a large amount of clips are selected.
        /// </remarks>
        /// <param name="maxcount">Maximum count of audio clips that are allowed  to be returned.</param>
        List<AudioClip> GetSelectedClips(int maxcount)
        {
            var clips = new List<AudioClip>(64);
            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: Loading", Globals.ProductTitle), true))
            {
                var selection = SelectedItems;
                for (var n = 0; n < Mathf.Min(maxcount, selection.Length); ++n)
                {
                    var model = selection[n] as Model;

                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)selection.Length;
                        var text = string.Format("[{1} remaining] {0}", model.AssetName, selection.Length - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }

                    var clip = AssetDatabase.LoadAssetAtPath(model.AssetPath, typeof(AudioClip)) as AudioClip;
                    if (null != clip)
                        clips.Add(clip);
                }
            }
            return clips;
        }

        /// <summary>
        /// Gets asset paths of the currently selected models.
        /// </summary>
        List<string> GetSelectedPaths()
        {
            var selection = SelectedItems;
            var paths = new List<string>(selection.Length);
            foreach (var item in selection)
            {
                var model = item as Model;
                if (model != null && !string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }

        /// <summary>
        /// Gets asset paths of all models.
        /// </summary>
        List<string> GetAllPaths()
        {
            var paths = new List<string>(_allitems.Count);
            foreach (var item in _allitems)
            {
                var model = item as Model;
                if (model != null && !string.IsNullOrEmpty(model.AssetPath))
                    paths.Add(model.AssetPath);
            }
            return paths;
        }
        #endregion

        #region DoGUI
        protected override void DoGUI()
        {
            base.DoGUI();
            
            DragColumn = FirstVisibleColumn; // we only allow drag&drop from items in the fist column
        }
        #endregion

        #region OnItemContextMenu
        /// <summary>
        /// Occurs when the user requests the context menu
        /// </summary>
        protected override void OnItemContextMenu(GUIListViewContextMenuArgs args)
        {
            base.OnItemContextMenu(args);

            if (SelectedItemsCount < 1)
                return; // no item selected, do not open a context menu

            GUIUtility.hotControl = 0;
            var model = args.Model as Model;

            var selection = GetSelectedModels();
            var hasmodifications = HasModifications(selection);
            var menu = new GenericMenu();

            menu.AddItem(new GUIContent("Apply"), false, hasmodifications ? OnContextMenuApply : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Revert"), false, hasmodifications ? OnContextMenuRevert : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent(Application.platform == RuntimePlatform.OSXEditor ? "Reveal in Finder" : "Show in Explorer"), false, SelectedItemsCount <= 10 ? OnContextMenuShowInExplorer : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Open %enter"), false, OnContextMenuOpenWithDefaultApp);
            menu.AddItem(new GUIContent("Delete... _delete"), false, OnContextMenuDelete);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Select in Project _enter"), false, OnContextMenuSelect);
            menu.AddItem(new GUIContent("Find References in Scene"), false, SelectedItemsCount == 1 ? OnContextMenuFindReferencesInScene : (GenericMenu.MenuFunction)null);
            menu.AddItem(new GUIContent("Find Prefabs in Project"), false, OnContextMenuFindPrefabsInProject);
            menu.AddItem(new GUIContent("Find Prefabs and Scenes in Project"), false, OnContextMenuFindPrefabsAndScenesInProject);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Reimport"), false, OnContextMenuReimport);
            menu.AddItem(new GUIContent(string.Empty), false, null);
            menu.AddItem(new GUIContent("Copy Full Path"), false, OnContextMenuCopyFullPath);

            // display the context menu. make sure to use the provided args.MenuLocation position
            // rather than 'Event.current.mousePosition', because the user could have been pressed
            // the context menu button as well, thus mousePosition is most likely wrong.
            menu.DropDown(new Rect(args.MenuLocation.x, args.MenuLocation.y, 0, 0));
            Event.current.Use();
            Editor.Repaint();
        }

        void OnContextMenuApply()
        {
            ApplyRevertChanges(GetSelectedModifiedModels(), true, true);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuRevert()
        {
            ApplyRevertChanges(GetSelectedModifiedModels(), false, true);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuShowInExplorer()
        {
            var objects = GetSelectedClips(int.MaxValue);
            EditorApplication2.ShowInExplorer(objects.ToArray());
            Editor.Repaint();
        }

        void OnContextMenuOpenWithDefaultApp()
        {
            var paths = GetSelectedPaths();
            EditorApplication2.OpenAssets(paths.ToArray());
            Editor.Repaint();
            EditorGUIUtility.ExitGUI(); // without this line an exception occurs (but it still opens the default app)
        }

        void OnContextMenuDelete()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Delete(paths);
            Editor.Focus(); // make sure to focus our plugin window again after the user confirmed the messagebox
            Editor.Repaint();
        }

        void OnContextMenuFindReferencesInScene()
        {
            var objects = GetSelectedClips(1); // Unity 'Find References In Scene' can only find one asset
            if (objects.Count > 0)
            {
                EditorApplication2.FindReferencesInScene(objects[0]);
                EditorUtility2.UnloadUnusedAssetsImmediate();
            }
        }

        void OnContextMenuFindPrefabsInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject) });
        }

        void OnContextMenuFindPrefabsAndScenesInProject()
        {
            FindAssetUsageWindow.FindUsageInProject(Globals.ProductId, Globals.ProductTitle, GetSelectedPaths(), new[] { typeof(GameObject), typeof(AssetDatabase2.UnityScene) });
        }

        void OnContextMenuReimport()
        {
            var paths = GetSelectedPaths();
            AssetDatabase2.Reimport(GetSelectedPaths(), 3, ImportAssetOptions.ForceUpdate);
        }

        void OnContextMenuCopyFullPath()
        {
            var paths = GetSelectedPaths();
            ClipboardUtil.CopyPaths(paths);
        }

        void OnContextMenuSelect()
        {
            var clips = GetSelectedClips(int.MaxValue);
            Selection.objects = clips.ToArray();
        }
        #endregion

        #region OnItemKeyDown
        /// <summary>
        /// Occurs when the user presses a key.
        /// </summary>
        protected override void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
        {
            switch (Event.current.keyCode)
            {
                case KeyCode.Delete:
                    OnContextMenuDelete();
                    args.Handled = true;
                    break;

                case KeyCode.Return:
                    if (Event.current.control)
                    {
                        OnContextMenuOpenWithDefaultApp();
                        args.Handled = true;
                    }
                    else
                    {
                        OnContextMenuSelect();
                        args.Handled = true;
                    }
                    break;
            }
        }
        #endregion

        #region OnBeginDrag
        /// <summary>
        /// Occurs at the beginning of a Drag&Drop operation.
        /// </summary>
        protected override void OnBeginDrag(int index, out UnityEngine.Object[] objects, out string[] paths)
        {
            paths = GetSelectedPaths().ToArray();

            // this will actually load the clips into memory, which is a bad idea if many clips are selected.
            // however, we display a progressbar during this time, so the editor won't just freeze like when you
            // select many assets in the unity project window.
            objects = GetSelectedClips(int.MaxValue).ToArray();
        }
        #endregion

        #region OnSorting
        /// <summary>
        /// Occurs when the user requests to sort the list.
        /// </summary>
        /// <returns>Returns the array of items to sort.</returns>
        protected override object[] OnBeforeSortItems()
        {
            return _allitems.ToArray();
        }

        /// <summary>
        /// Occurs after sorting completed.
        /// </summary>
        /// <param name="models">The sorted data. This is the data returned by OnBeforeSortItems(), but sorted.</param>
        protected override void OnAfterSortItems(object[] models)
        {
            base.OnAfterSortItems(models);

            _allitems = new List<Model>((Model[])models); // write the sorted data back to our data model
            SetFilter(_filterResult, _filterMode); // make sure any existing filter will still have impact on the list
        }
        #endregion

        #region OnItemDoubleClick
        /// <summary>
        /// Occurs when the user double clicks on an item.
        /// </summary>
        /// <param name="index">The index of the item.</param>
        protected override void OnItemDoubleClick(int index)
        {
            base.OnItemDoubleClick(index);

            // a double-click actually forces the list to have only 1 item selected,
            // so we also just get one clip here.
            var objs = GetSelectedClips(1);
            if (objs.Count > 0)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds; // store at which time the user involked the selected, in order to avoid a feedback loop if the plugin is listening to selection changes.
                Selection.activeObject = objs[0];
                EditorGUIUtility.PingObject(objs[0]);
            }
        }
        #endregion

        #region OnGetItemKeyword
        /// <summary>
        /// Gets the item keyword for the specified args.
        /// </summary>
        /// <remarks>
        /// The item-keyword is used to jump to a particular item in the list
        /// when the user pressed a key. When a model begins with the keyword(sequence)
        /// the list jumps to it.
        /// </remarks>
        protected override string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
        {
            var model = args.Model as Model;
            if (model != null)
                return model.AssetName;

            return null;
        }
        #endregion

        #region OnGetItem
        /// <summary>
        /// Gets the item at the specified index.
        /// </summary>
        protected override object OnGetItem(int index)
        {
            if (index < 0 || index >= _items.Count)
                return null;

            return _items[index];
        }
        #endregion

        #region OnGetItemCount
        /// <summary>
        /// Gets the count of items in the list.
        /// </summary>
        protected override int OnGetItemCount()
        {
            return _items.Count;
        }
        #endregion

        #region OnGetItemText
        /// <summary>
        /// Gets the item text of the specified column.
        /// </summary>
        protected override string OnGetItemText(GUIListViewGetItemTextArgs args)
        {
            var column = args.Column as Column;
            return column.Exporter(args.Model as Model);
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Occurs when the selection changed.
        /// </summary>
        protected override void OnSelectionChange()
        {
            base.OnSelectionChange();
            DoChanged();
        }
        #endregion

        #region OnDrawItemBackground
        /// <summary>
        /// Occurs when a list background for a row is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the row.</param>
        protected override void OnDrawItemBackground(ref GUIListViewDrawItemBackgroundArgs args)
        {
            base.OnDrawItemBackground(ref args);

            var model = args.Model as Model;
            if (null == model)
                return;
#if false
            if (_platforms.Count > 1)
            {
                var group = args.ModelIndex / _platforms.Count;
                if ((group & 1) == 0)
                {
                    var color = EditorGUIUtility.isProSkin ? new Color(1, 1, 1, 0.03f) : new Color(1, 1, 1, 0.08f);
                    var oldcolor = GUI.color;
                    GUI.color = GUIColors.TintIfPlaying(color);
                    GUI.Box(args.Rect, "", GUIStyles.White);
                    GUI.color = oldcolor;
                }
            }
#endif
            // if the clip is broken, make the row red
            if (model.LoadError && args.Column.IsPrimaryColumn)
            {
                var oldcolor = GUI.color;
                GUI.color = GUIColors.TintIfPlaying(new Color(0.85f, 0.2f,0.2f,1));
                GUI.Box(args.Rect, "", GUIStyles.White);
                GUI.color = oldcolor;
            }
        }
        #endregion

        #region OnDrawItem
        /// <summary>
        /// Occurs when a list item is requested to draw.
        /// </summary>
        /// <param name="args">The data containing all the information needed to draw the item.</param>
        protected override void OnDrawItem(GUIListViewDrawItemArgs args)
        {
            var model = args.Model as Model;
            if (null == model) return;

            // if this is the first column in the list, display an icon there
            if (args.Column.IsPrimaryColumn)
            {
                var image = Images.AudioFile16x16;
                if (model.IsCompressed(GetPlatform(args.ModelIndex)))
                    image = Images.CompressedAudioFile16x16;

                DrawItemImageHelper(ref args.ItemRect, image, new Vector2(16, 16));
            }

            // make the text appear vertically centered in the row
            args.ItemRect.width -= 5;
            args.ItemRect.y += 3; args.ItemRect.height -= 3;

            // draw the models value using the specified custom drawer method
            var column = args.Column as Column;
            if (null != column && null != column.Drawer)
                column.Drawer(model, args);

            // if this is the first column in the list and the model
            // has modifications, draw the Apply and Revert buttons.
            if (args.Column.IsPrimaryColumn && model.IsModified())
            {
                var oldcolor = GUI.color;
                GUI.color = GUIColors.TintIfPlaying(Color.white);
                
                // draw the apply and revert buttons at the right side of the first (primary) column
                var revertrect = args.ItemRect;
                revertrect.x += revertrect.width;
                revertrect.width = 16;
                revertrect.x -= revertrect.width + 2;
                if (GUI.Button(revertrect, GUIContent2.Temp("", null, "Revert changes from selected AudioClip(s)"), GUIStyles.RevertImageButton))
                    ApplyRevertChanges(GetSelectedModifiedModels(), false, true);

                var applyrect = revertrect;
                applyrect.x -= revertrect.width + 2;
                if (GUI.Button(applyrect, GUIContent2.Temp("", null, "Apply changes to selected AudioClip(s)"), GUIStyles.AcceptImageButton))
                    ApplyRevertChanges(GetSelectedModifiedModels(), true, true);

                args.ItemRect.width -= revertrect.width * 2 + 4;
                GUI.color = oldcolor;
            }
            else
            {
                // draw invisible buttons to avoid gui layout mismatch errors if from one
                // gui event to another the modified state of a model changed.
                GUI.Button(new Rect(0, 0, 0, 0), "", GUIStyles.Clear);
                GUI.Button(new Rect(0, 0, 0, 0), "", GUIStyles.Clear);
            }
        }
        #endregion

        #region Draw/Compare Name
        void OnDrawAssetName(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetName, args.Selected);
        }

        int OnCompareAssetName(Model x, Model y)
        {
            return string.Compare(x.AssetName, y.AssetName, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetName(Model model)
        {
            return model.AssetName;
        }
        #endregion

        List<BuildTargetGroup> _platforms = new List<BuildTargetGroup>();

        #region SetPlatform
        int[][] _PlatformCompressionFormatValues; // [platform][format]
        string[][] _PlatformCompressionFormatStrings; // [platform][format]

        public void AddPlatform(BuildTargetGroup platform)
        {
            _platforms.Add(platform);

            UpdateItemLists();
        }

        public void RemovePlatform(BuildTargetGroup platform)
        {
            _platforms.Remove(platform);

            UpdateItemLists();
        }

        public bool ContainsPlatform(BuildTargetGroup platform)
        {
            for (var n = 0; n < _platforms.Count; ++n)
            {
                if (_platforms[n] == platform)
                    return true;
            }
            return false;
        }

        public void SetPlatform(BuildTargetGroup platform)
        {
            PlatformGroup = platform;
            _platforms.Clear();
            _platforms.Add(PlatformGroup);

            UpdateItemLists();
        }
        #endregion

        #region Draw/Compare Format
        void OnDrawFormat(Model model, GUIListViewDrawItemArgs args)
        {
            var platform = GetPlatform(args.ModelIndex);
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeFormat(platform);

            var oldcolor = GUI.color;
            if (model.GetImporterFormat(platform) != model.GetModifiedImporterFormat(platform))
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = (AudioCompressionFormat)EditorGUI.IntPopup(args.ItemRect, (int)model.GetModifiedImporterFormat(platform), _PlatformCompressionFormatStrings[(int)platform], _PlatformCompressionFormatValues[(int)platform]);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.GetModifiedImporterFormat(platform))
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeFormat(platform))
                            model2.SetModifiedImporterFormat(platform, newvalue);
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareFormat(Model x, Model y)
        {
            var xx = AudioStringUtil.CompressionFormat(x.GetModifiedImporterFormat(PlatformGroup));
            var yy = AudioStringUtil.CompressionFormat(y.GetModifiedImporterFormat(PlatformGroup));

            // rather than comparing the enumerated value, we compare its text.
            // it's done this way, because otherwise sorting doesn't appear in alphabetical order and looks just wrong.
            return string.Compare(xx, yy, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportFormat(Model model)
        {
            return AudioStringUtil.CompressionFormat(model.GetImporterFormat(PlatformGroup));
        }
        #endregion

        #region Draw/Compare Force Mono
        void OnDrawForceMono(Model model, GUIListViewDrawItemArgs args)
        {
            var platform = GetPlatform(args.ModelIndex);
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeForceMono();

            var oldcolor = GUI.color;
            if (model.ModifiedForceMono != model.ImporterForceMono)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedForceMono);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedForceMono)
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeForceMono())
                            model2.ModifiedForceMono = newvalue;
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareForceMono(Model x, Model y)
        {
            return x.ModifiedForceMono.CompareTo(y.ModifiedForceMono);
        }

        string OnExportForceMono(Model model)
        {
            return model.ImporterForceMono.ToString();
        }
        #endregion

        #region Draw/Compare Override Sample Settings
        void OnDrawOverride(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;

            var platform = GetPlatform(args.ModelIndex);
            var oldcolor = GUI.color;
            if (model.GetModifiedImporterOverridden(platform) != model.GetImporterOverridden(platform))
                GUI.color = ModifiedValueColor;

            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeOverride(platform);

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.GetModifiedImporterOverridden(platform));
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.GetModifiedImporterOverridden(platform))
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeOverride(platform))
                            model2.SetModifiedImporterOverridden(platform, newvalue);
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareOverride(Model x, Model y)
        {
            return x.GetModifiedImporterOverridden(PlatformGroup).CompareTo(y.GetModifiedImporterOverridden(PlatformGroup));
        }

        string OnExportOverride(Model model)
        {
            return model.GetImporterOverridden(PlatformGroup).ToString();
        }
        #endregion

        #region Draw/Compare LoadInBackground
        void OnDrawLoadInBackground(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeLoadInBackground();

            var oldcolor = GUI.color;
            if (model.ModifiedLoadInBackground != model.ImporterLoadInBackground)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedLoadInBackground);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedLoadInBackground)
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeLoadInBackground())
                            model2.ModifiedLoadInBackground = newvalue;
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareLoadInBackground(Model x, Model y)
        {
            return x.ModifiedLoadInBackground.CompareTo(y.ModifiedLoadInBackground);
        }

        string OnExportLoadInBackground(Model model)
        {
            return model.ModifiedLoadInBackground.ToString();
        }
        #endregion

        #region Draw/Compare PreloadAudioData
        void OnDrawPreloadAudioData(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.width = GUI.skin.toggle.normal.background.width;
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangePreloadAudioData();

            var oldcolor = GUI.color;
            if (model.ModifiedPreloadAudioData != model.ImporterPreloadAudioData)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.Toggle(args.ItemRect, model.ModifiedPreloadAudioData);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.ModifiedPreloadAudioData)
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangePreloadAudioData())
                            model2.ModifiedPreloadAudioData = newvalue;
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnComparePreloadAudioData(Model x, Model y)
        {
            return x.ModifiedPreloadAudioData.CompareTo(y.ModifiedPreloadAudioData);
        }

        string OnExportPreloadAudioData(Model model)
        {
            return model.ModifiedPreloadAudioData.ToString();
        }
        #endregion

        #region Draw/Compare Quality
        void OnDrawQuality(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.height -= 2;

            var platform = GetPlatform(args.ModelIndex);
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeQuality(platform);

            // EditorGUI.IntSlider has a bug, that it will display the <-> icon even
            // when the control is disabled. So to overcome this problem, we add a cursor rect our own
            if (!GUI.enabled)
                EditorGUIUtility.AddCursorRect(args.ItemRect, MouseCursor.Arrow);

            var oldcolor = GUI.color;
            if (model.GetModifiedImporterQuality(platform) != model.GetImporterQuality(platform))
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.IntSlider(args.ItemRect, model.GetModifiedImporterQuality(platform), 1, 100);
            if (EditorGUI.EndChangeCheck())
            {
                if (newvalue != model.GetModifiedImporterQuality(platform))
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeQuality(platform))
                            model2.SetModifiedImporterQuality(platform, newvalue);
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareQuality(Model x, Model y)
        {
            return x.GetModifiedImporterQuality(PlatformGroup).CompareTo(y.GetModifiedImporterQuality(PlatformGroup));
        }

        string OnExportQuality(Model model)
        {
            return model.GetImporterQuality(PlatformGroup).ToString();
        }
        #endregion

        #region Draw/Compare SampleRate
        int[] _SampleRateValues;
        string[] _SampleRateStrings;

        void OnDrawSampleRate(Model model, GUIListViewDrawItemArgs args)
        {
            int PreserveSampleRate = -3;
            int OptimizeSampleRate = -2;

            #region Initialize sample rate static lookup variables
            if (_SampleRateValues == null)
            {
                _SampleRateValues = new[]
                {
                    PreserveSampleRate,
                    OptimizeSampleRate,
                    -1, // separator
                    8000, 11025, 22050, 44100, 48000, 96000, 192000 // frequencies
                };

                _SampleRateStrings = new string[_SampleRateValues.Length];
                _SampleRateStrings[0] = "Preserve";
                _SampleRateStrings[1] = "Optimize";
                _SampleRateStrings[2] = string.Empty; // separator

                // Builds frequency elements
                for(var n=0; n<_SampleRateValues.Length; ++n)
                {
                    var hz = _SampleRateValues[n];
                    if (hz > 0)
                        _SampleRateStrings[n] = AudioStringUtil.Frequency(_SampleRateValues[n]);
                }
            }
            #endregion

            args.ItemRect.height -= 2;

            var platform = GetPlatform(args.ModelIndex);
            var oldcolor = GUI.color;
            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeSampleRate(platform);

            var selectedValue = 0;
            if (model.GetModifiedImporterSampleRateSetting(platform) != model.GetImporterSampleRateSetting(platform))
                GUI.color = ModifiedValueColor;

            if (model.GetModifiedImporterSampleRateSetting(platform) == AudioSampleRateSetting.PreserveSampleRate)
                selectedValue = PreserveSampleRate;

            if (model.GetModifiedImporterSampleRateSetting(platform) == AudioSampleRateSetting.OptimizeSampleRate)
                selectedValue = OptimizeSampleRate;

            // If overridden, we want to display the sample rate frequency
            if (model.GetModifiedImporterSampleRateSetting(platform) == AudioSampleRateSetting.OverrideSampleRate)
            {
                selectedValue = (int)model.GetModifiedImporterSampleRate(platform);

                if (model.GetModifiedImporterSampleRate(platform) != model.GetImporterSampleRate(platform))
                    GUI.color = ModifiedValueColor;
            }

            EditorGUI.BeginChangeCheck();
            var newvalue = EditorGUI.IntPopup(args.ItemRect, selectedValue, _SampleRateStrings, _SampleRateValues);
            if (EditorGUI.EndChangeCheck())
            {
                //if (newvalue != model.GetModifiedImporterSampleRate(platform))
                {
                    ModifySelectedItems(delegate(Model model2)
                    {
                        if (model2.CanChangeSampleRate(platform))
                        {
                            if (newvalue == PreserveSampleRate)
                            {
                                model2.SetModifiedImporterSampleRateSetting(platform, AudioSampleRateSetting.PreserveSampleRate);
                                model2.SetModifiedImporterSampleRate(platform, model2.GetImporterSampleRate(platform));
                            }

                            if (newvalue == OptimizeSampleRate)
                            {
                                model2.SetModifiedImporterSampleRateSetting(platform, AudioSampleRateSetting.OptimizeSampleRate);
                                model2.SetModifiedImporterSampleRate(platform, model2.GetImporterSampleRate(platform));
                            }

                            if (newvalue > 0)
                            {
                                model2.SetModifiedImporterSampleRateSetting(platform, AudioSampleRateSetting.OverrideSampleRate);
                                model2.SetModifiedImporterSampleRate(platform, (uint)newvalue);
                            }
                        }
                    });
                }
            }

            GUI.color = oldcolor;
            GUI.enabled = oldenabled;
        }

        int OnCompareSampleRate(Model x, Model y)
        {
            // weighten setting over sample rate
            var xx = 100000 * (int)x.GetModifiedImporterSampleRateSetting(PlatformGroup) + x.GetModifiedImporterSampleRate(PlatformGroup);
            var yy = 100000 * (int)y.GetModifiedImporterSampleRateSetting(PlatformGroup) + y.GetModifiedImporterSampleRate(PlatformGroup);

            return xx.CompareTo(yy);
        }

        string OnExportSampleRate(Model model)
        {
            return model.GetImporterSampleRateSetting(PlatformGroup).ToString();
        }
        #endregion

        #region Draw/Compare Duration
        void OnDrawDuration(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.DurationString, args.Selected);
        }

        int OnCompareDuration(Model x, Model y)
        {
            return x.Duration.CompareTo(y.Duration);
        }

        string OnExportDuration(Model model)
        {
            return model.DurationString;
        }
        #endregion

        #region Draw/Compare Frequency
        void OnDrawFrequency(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.FrequencyString, args.Selected);
        }

        int OnCompareFrequency(Model x, Model y)
        {
            return x.Frequency.CompareTo(y.Frequency);
        }

        string OnExportFrequency(Model model)
        {
            return model.FrequencyString;
        }
        #endregion

        #region Draw/Compare Channels
        void OnDrawChannels(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.ChannelsString, args.Selected);
        }

        int OnCompareChannels(Model x, Model y)
        {
            return string.Compare(x.ChannelsString, y.ChannelsString, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportChannels(Model model)
        {
            return model.ChannelsString;
        }
        #endregion

        #region Draw/Compare Bits per Sample
        void OnDrawBitsPerSample(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.BitsPerSampleString, args.Selected);
        }

        int OnCompareBitsPerSample(Model x, Model y)
        {
            return x.BitsPerSample.CompareTo(y.BitsPerSample);
        }

        string OnExportBitsPerSample(Model model)
        {
            return model.BitsPerSampleString;
        }
        #endregion

        #region Draw/Compare Runtime size
        void OnDrawRuntimeSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.RuntimeSizeString, args.Selected);
        }

        int OnCompareRuntimeSize(Model x, Model y)
        {
            return x.RuntimeSize.CompareTo(y.RuntimeSize);
        }

        string OnExportRuntimeSize(Model model)
        {
            return model.RuntimeSizeString;
        }
        #endregion

        #region Draw/Compare Storage Size
        void OnDrawStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.StorageSizeString, args.Selected);
        }

        int OnCompareStorageSize(Model x, Model y)
        {
            return x.StorageSize.CompareTo(y.StorageSize);
        }


        string OnExportStorageSize(Model model)
        {
            return model.StorageSizeString;
        }
        #endregion

        #region Draw/Compare Original Storage Size
        void OnDrawOrgStorageSize(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.OrgStorageSizeString, args.Selected);
        }

        int OnCompareOrgStorageSize(Model x, Model y)
        {
            return x.OrgStorageSize.CompareTo(y.OrgStorageSize);
        }

        string OnExportOrgStorageSize(Model model)
        {
            return model.OrgStorageSizeString;
        }
        #endregion

        #region Draw/Compare Original Last Write Time
        void OnDrawUserString0(Model model, GUIListViewDrawItemArgs args)
        {
            args.ItemRect.y -= 1;

            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeUserString();

            var modified = !string.Equals(model.UserString0, model.ModifiedUserString0);
            var oldcolor = GUI.color;
            if (modified)
                GUI.color = ModifiedValueColor;

            EditorGUI.BeginChangeCheck();
            model.ModifiedUserString0 = EditorGUI.TextField(args.ItemRect, model.ModifiedUserString0);
            if (EditorGUI.EndChangeCheck())
            {
                ModifySelectedItems(delegate(Model model2)
                {
                    model2.ModifiedUserString0 = model.ModifiedUserString0;
                });
            }

            GUI.enabled = oldenabled;
            GUI.color = oldcolor;
        }

        int OnCompareUserString0(Model x, Model y)
        {
            return string.Compare(x.UserString0, y.ModifiedUserString0, StringComparison.CurrentCultureIgnoreCase);
        }

        string OnExportUserString0(Model model)
        {
            return model.UserString0;
        }
        #endregion

        #region Draw/Compare Path
        void OnDrawAssetPath(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.PathLabel(args.ItemRect, model.AssetPath, args.Selected);
        }

        int OnCompareAssetPath(Model x, Model y)
        {
            return string.Compare(x.AssetPath, y.AssetPath, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetPath(Model model)
        {
            return model.AssetPath;
        }
        #endregion

        #region Draw/Compare GUID
        void OnDrawAssetGuid(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.AssetGuid, args.Selected);
        }

        int OnCompareAssetGuid(Model x, Model y)
        {
            return string.Compare(x.AssetGuid, y.AssetGuid, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportAssetGuid(Model model)
        {
            return model.AssetGuid;
        }
        #endregion

        #region Draw/Compare File extension
        void OnDrawFileExtesion(Model model, GUIListViewDrawItemArgs args)
        {
            EditorGUI2.Label(args.ItemRect, model.Extension, args.Selected);
        }

        int OnCompareFileExtesion(Model x, Model y)
        {
            return string.Compare(x.Extension, y.Extension, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportFileExtesion(Model model)
        {
            return model.Extension;
        }
        #endregion

        #region Draw/Compare Load type
        void OnDrawLoadType(Model model, GUIListViewDrawItemArgs args)
        {
            var platform = GetPlatform(args.ModelIndex);
            var oldcolor = GUI.color;
            if (model.GetModifiedImporterLoadType(platform) != model.GetImporterLoadType(platform))
                GUI.color = ModifiedValueColor;


            var oldenabled = GUI.enabled;
            GUI.enabled = model.CanChangeLoadType(platform);

            EditorGUI.BeginChangeCheck();
            var newvalue = (AudioClipLoadType)EditorGUI.EnumPopup(args.ItemRect, model.GetModifiedImporterLoadType(platform));
            if (EditorGUI.EndChangeCheck())
            {
                ModifySelectedItems(delegate(Model model2)
                {
                    if (model2.CanChangeLoadType(platform))
                        model2.SetModifiedImporterLoadType(platform, newvalue);
                });
            }

            GUI.enabled = oldenabled;
            GUI.color = oldcolor;
        }

        int OnCompareLoadType(Model x, Model y)
        {
            var xx = AudioStringUtil.LoadType(x.GetModifiedImporterLoadType(PlatformGroup));
            var yy = AudioStringUtil.LoadType(y.GetModifiedImporterLoadType(PlatformGroup));

            return string.Compare(xx, yy, StringComparison.OrdinalIgnoreCase);
        }

        string OnExportLoadType(Model model)
        {
            return AudioStringUtil.LoadType(model.GetImporterLoadType(PlatformGroup));
        }
        #endregion

        #region ReimportAll
        /// <summary>
        /// Reimports all audio clips.
        /// </summary>
        public void ReimportAll()
        {
            var allpaths = GetAllPaths();
            AssetDatabase2.Reimport(allpaths, 1, ImportAssetOptions.ForceUpdate);
        }
        #endregion

        #region Apply and revert changes
        /// <summary>
        /// Applies or reverts all modifications.
        /// </summary>
        /// <param name="apply">true to apply, false to revert.</param>
        public void ApplyRevertAll(bool apply)
        {
            var list = GetModifiedModels();
            ApplyRevertChanges(list, apply, true);
        }

        /// <summary>
        /// Applies or reverts modifications of the specified models.
        /// </summary>
        /// <param name="models">The models to apply or revert.</param>
        /// <param name="apply">true to apply, false to revert changes.</param>
        /// <param name="warnmany">Whether to display a confirmation dialog when many models are in the list.</param>
        void ApplyRevertChanges(List<Model> models, bool apply, bool warnmany)
        {
            if (warnmany && models.Count > 10)
            {
                var builder = new StringBuilder(128);
                var count = 0;
                var verb = apply ? "Apply" : "Revert";

                foreach (var model in models)
                {
                    if (count < 3)
                        builder.AppendLine("'" + model.AssetPath + "'");
                    else if (count == 3)
                    {
                        builder.AppendLine("...");
                        break;
                    }
                    count++;
                }

                if (!EditorUtility.DisplayDialog(string.Format("{0} {1} import settings", verb, models.Count), builder.ToString(), verb, "Cancel"))
                    return;
            }

            // remove the activeObject from the selection, so the unity inspector
            // will hopefully not be forced to respond on changes. I noticed the
            // inspector sometimes display a guilayout mismatch error when clip properties
            // get changed in the middle while the inspector is drawing itself.
            var activeobj = Selection.activeObject;
            if (apply)
            {
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds;
                Selection.activeObject = null;
            }

            using (var progressbar = new EditorGUI2.ModalProgressBar(string.Format("{0}: {1}", Globals.ProductTitle, apply?"Applying":"Reverting"), true))
            {
                for (var n = 0; n < models.Count; ++n)
                {
                    var model = models[n];
                    if (apply)
                        model.ApplyChanges();
                    else
                        model.RevertChanges();

                    // report the progress to the user, since it can be a time consuming operation to apply many clips.
                    if (progressbar.TotalElapsedTime > 1.0f && progressbar.ElapsedTime > 0.1f)
                    {
                        var progress = n / (float)models.Count;
                        var text = string.Format("[{1} remaining] {0}", FileUtil2.GetFileName(model.AssetPath), models.Count - n - 1);
                        if (progressbar.Update(text, progress))
                            break;
                    }
                }
            }

            if (apply)
            {
                // flush cache file to disk
                _cache.Write(true);

                // restore the previously active selection and force a repaint
                ChangeUnitySelectionTime = DateTime.Now.TimeOfDay.TotalSeconds;
                Selection.activeObject = activeobj;
                UnityEditorInternal.InternalEditorUtility.RepaintAllViews();

                // make sure changes get properly imported
                AssetDatabase.Refresh(ImportAssetOptions.ForceUpdate);
            }
        }
        #endregion

        #region HasModifications
        /// <summary>
        /// Gets whether any model in the specified list is modified.
        /// </summary>
        bool HasModifications(List<Model> list)
        {
            for (var n = 0; n < list.Count; ++n)
            {
                var model = list[n];
                if (model.IsModified())
                    return true;
            }
            return false;
        }
        #endregion

        #region ModifySelectedItems
        /// <summary>
        /// Iterates over every selected model and calls the specified callback for every mode.
        /// </summary>
        /// <param name="callback">The method to call for every model.</param>
        void ModifySelectedItems(Action<Model> callback)
        {
            if (null == callback)
                return;

            var items = GetSelectedModels();
            for (var n = 0; n < items.Count; ++n)
            {
                var item = items[n];
                callback(item);
            }

            DoChanged();
        }
        #endregion

        #region FindModel
        /// <summary>
        /// Finds the model with the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The path.</param>
        /// <returns>Returns the model on success, null otherwise.</returns>
        Model FindModel(string assetPath)
        {
            foreach (var item in _allitems)
            {
                if (string.Equals(assetPath, item.AssetPath, StringComparison.OrdinalIgnoreCase))
                    return item;
            }
            return null;
        }
        #endregion

        #region AssetFileWatcher

        void AddModel(Model model)
        {
            _loadeditems.Add(model);

            var infilter = IsIncludedInFilter(model);
            for (var n = 0; n < _platforms.Count; ++n)
            {
                _allitems.Add(model);

                // if the asset is visible to the current filter, add it to the filtered list as well
                if (infilter)
                    _items.Add(model);
            }
        }

        void RemoveModel(Model model)
        {
            _loadeditems.Remove(model);

            for (var n = _allitems.Count - 1; n >= 0; --n)
            {
                if (ReferenceEquals(_allitems[n], model))
                    _allitems.RemoveAt(n);
            }

            for (var n = _items.Count - 1; n >= 0; --n)
            {
                if (ReferenceEquals(_items[n], model))
                    _items.RemoveAt(n);
            }

            //_allitems.Remove(model);
            //_items.Remove(model);
        }

        /// <summary>
        /// Occurs when an asset has been moved in the project.
        /// </summary>
        void AssetFileWatcher_Moved(string[] oldPaths, string[] newPaths)
        {
            long loadedsize = 0;
            for (var n = 0; n < oldPaths.Length; ++n)
            {
                if (!IsSupportedFile(oldPaths[n]))
                    continue; // not the type of asset we're interested in

                var model = FindModel(oldPaths[n]);
                if (null == model)
                    continue; // it's not in our list

                RemoveModel(model);

                // this is a new asset, add it to our list
                InitModel(ref model, newPaths[n]);
                AddModel(model);

                CheckUnloadUnused(model, ref loadedsize);
            }

            EditorUtility2.UnloadUnusedAssetsImmediate();
            Sort();

            DoChanged();
            Editor.Repaint();
        }

        /// <summary>
        /// Occurs when an asset has been deleted from the project.
        /// </summary>
        void AssetFileWatcher_Deleted(string[] paths)
        {
            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in

                var model = FindModel(path);
                if (null == model)
                    continue; // it's not in our list

                RemoveModel(model);
            }

            DoChanged();
            Editor.Repaint();
        }

        /// <summary>
        /// Occurs when an asset has been imported into the project.
        /// </summary>
        void AssetFileWatcher_Imported(string[] paths)
        {
            var addeditem = false;
            long loadedsize = 0;

            foreach (var path in paths)
            {
                if (!IsSupportedFile(path))
                    continue; // not the type of asset we're interested in

                // try to find the model
                var model = FindModel(path);
                if (null != model)
                {
                    InitModel(ref model, path);
                    CheckUnloadUnused(model, ref loadedsize);
                    continue;
                }

                // this is a new asset, add it to our list
                InitModel(ref model, path);
                AddModel(model);

                addeditem = true;
                CheckUnloadUnused(model, ref loadedsize);
            }

            EditorUtility2.UnloadUnusedAssetsImmediate();
            if (addeditem)
                Sort();

            DoChanged();
            Editor.Repaint();
        }
        #endregion
    }
}
