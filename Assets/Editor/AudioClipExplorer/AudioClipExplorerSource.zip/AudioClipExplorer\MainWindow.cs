﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using EditorFramework;

namespace AudioClipExplorer
{
    /// <summary>
    /// MainWindow represents the main application window of the plugin.
    /// </summary>
    public class MainWindow : EditorWindow2
    {
        #region Private Fields
        enum PickMode
        {
            Project,
            Scene,
            Selection
        }

        GUIToolbar _menu; // top toolbar menu
        GUIToolbar _bottommenu; // bottom toolbar menu
        Listbox _listview; // the actual list where all audio clip settings are displayed
        GUIToolbarSearchField _searchfield; // the control to enter a search text
        GUIToolbarLabel _searchlabel; // displays information about the current search/filter (eg 10 / 1000 clips displayed)
        GUIToolbarLabel _statslabel; // displays info about the current list selection
        GUIToolbarButton _lockbutton; // in PickMode.Selection a buttton to lock the list content
        GUIToolbarButton _refreshbutton;
        GUIToolbarPopup _pickmodepopup;
        PickMode _pickmode = PickMode.Project;
        bool _locked; // whether the list content is locked
        #endregion

        #region OnCreate
        /// <summary>
        /// Called when the window gets created.
        /// This method creates all the controls.
        /// </summary>
        /// <remarks>
        /// Creation must be kept fast, otherwise the window gets displayed entirely white for a short moment.
        /// </remarks>
        protected override void __OnCreate()
        {
#if UNITY_5
            // We need to patch platform names to how the audio API expect platform names.
            // Workaround for bug-report 678452 Audio/TextureImporter: Mixed platform strings
            var platforms = BuildPlayerWindow2.GetValidPlatforms();
            foreach (var entry in platforms)
            {
                // Workaround for bug-report 670354 Unity5: AudioImporter.ClearSampleSettingOverride error
                // Workaround for bug-report 670353 Unity5: AudioImporter.ContainsSampleSettingsOverride error
                if (string.Equals(entry.Name, "BlackBerry", StringComparison.OrdinalIgnoreCase))
                    entry.Name = "blackberry";

                if (string.Equals(entry.Name, "Windows Store Apps", StringComparison.OrdinalIgnoreCase))
                    entry.Name = "WSA";

                if (string.Equals(entry.Name, "Samsung TV", StringComparison.OrdinalIgnoreCase))
                    entry.Name = "SamsungTV";
                //Debug.Log(string.Format("TargetGroup: {0}, Name: {1}, DefaultTarget: {2}", entry.TargetGroup, entry.Name, entry.DefaultTarget));
            }
#endif

            this.title = Globals.ProductTitle;

            // create the listview control
            _listview = new Listbox(this, null);
            _listview.EmptyText = "Loading AudioClip importer settings. Please wait...";
            _listview.EditorPrefsPath = string.Format("{0}.ListView", Globals.ProductId);
            _listview.LoadPrefs();
            _listview.Changed += OnListboxChanged;
            //_listview.SetPlatform(BuildPipeline2.GetBuildTargetGroup(EditorUserBuildSettings.activeBuildTarget));

            // create a toolbar control
            _menu = new GUIToolbar(this, null);

            // add the 'Tools' submenu to the toolbar
            var toolspopup = _menu.AddMenu("Tools", "", null);
            toolspopup.Items = new[] 
            {
                new GUIToolbarMenuItem("Apply all", OnToolsApplyAllExecute, OnToolsApplyRevertAllQueryStatus),
                new GUIToolbarMenuItem("Revert all", OnToolsRevertAllExecute, OnToolsApplyRevertAllQueryStatus),
                new GUIToolbarMenuItem("-"),
                new GUIToolbarMenuItem("Export as CSV...", OnToolsExportCsvExecute),
                new GUIToolbarMenuItem("-"),
                new GUIToolbarMenuItem("Reimport all...", OnToolsReimportAllExecute, OnToolsReimportAllQueryStatus),
            };

            // add the 'Pickmode' popup control to the toolbar
            _pickmodepopup = _menu.AddPopup("Pickmode", "Sets the source from where to list AudioClips.", OnPickModeChange);
            _pickmodepopup.Items = new[]
            {
                new GUIToolbarPopupItem("Project", PickMode.Project),
                new GUIToolbarPopupItem("Scene", PickMode.Scene),
                new GUIToolbarPopupItem("Selection", PickMode.Selection)
            };
            _pickmode = (PickMode)EditorPrefs.GetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            _pickmodepopup.SelectTag(_pickmode);


            // add the lock button which is only visible when pickmode is set to Selection.
            _lockbutton = _menu.AddButton("", "Locks the list content in 'Selection' mode.\n\nWhen locked, selection changes within the Unity Project or Hierachy window have no impact on the list content.", null, OnLockToggle, OnQueryLockToggle);
            _lockbutton.ImageSize = new Vector2(13, 13);
            SetLock(false);

            _refreshbutton = _menu.AddButton("Refresh", "Gets a new snapshot of all AudioClip's used in the Scene at this moment.", Images.Refresh16x16, OnRefreshScene, OnQueryRefreshScene);
            _refreshbutton.ImageSize = new Vector2(13, 13);

            _menu.AddFlexibleSpace();

            // add the search field to the right side of the window
            _searchfield = _menu.AddSearchField("", null, OnSearchChange, null);
            _searchfield.SearchModes = new[] { "Search in Name", "Search in Path", "Search in GUID" };
            _searchfield.SearchMode = EditorPrefs.GetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), 0);
            _searchfield.AcceptDrop = true;

#if UNITY_5
            // unity 5 features per-platform audio settings.
            // therefore we add a platform selection radio button group to the
            // toolbar where the user can pick from which platform he wants to edit the settings.
            var radioGroup = _menu.AddRadioGroup();
            var radioDefaultButton = radioGroup.AddButton("Default", "Default settings", null, OnPlatformChange);
            radioDefaultButton.Tag = BuildTargetGroup.Unknown;
            var radioactivebutton = radioDefaultButton;
            var validplatforms = BuildPlayerWindow2.GetValidPlatforms();

            foreach (var platform in validplatforms)
            {
                var button = radioGroup.AddButton("", platform.DisplayName + " settings", platform.SmallIcon as Texture2D, OnPlatformChange);
                button.Tag = platform.TargetGroup;

                if (platform.TargetGroup == _listview.PlatformGroup)
                    radioactivebutton = button;
            }
            radioGroup.OnCheckedControl(radioactivebutton);
#endif

            // add the button info bar
            _bottommenu = new GUIToolbar(this, null);
            _statslabel = _bottommenu.AddLabel();
            _bottommenu.AddFlexibleSpace();
            _searchlabel = _bottommenu.AddLabel();
            _bottommenu.AddButton("", string.Format("Show 'About {0}' dialog.", this.title), Images.Info16x16, OnAboutExecute);

            // add some space at the right for the buttom menu.
            // this is especially important for OSX, where the window resize grabber is in the lower right corner of the window.
            // in order to prevent it to overlap with the info button, we simply add some space.
            _bottommenu.AddSpace(9);

            EditorUserBuildSettings.activeBuildTargetChanged += OnBuildTargetChanged;
        }
        #endregion

        #region OnResize
        /// <summary>
        /// Called when the window size changed.
        /// </summary>
        protected override void __OnResize()
        {
            base.__OnResize();

            _searchfield.LayoutOptions = new[] { GUILayout.MaxWidth(position.width - 190) };
        }
        #endregion

        #region OnInit
        /// <summary>
        /// Called after OnCreate and intented to initialize the plugin. This function is allowed to take longer.
        /// </summary>
        protected override void __OnInit()
        {
            _listview.ReadCacheFile();
            _listview.EmptyText = "The list is empty.";

            DoPickModeChange(_pickmode);
        }
        #endregion

        #region OnDestroy
        /// <summary>
        /// Called when the window gets destroyed
        /// </summary>
        protected override void __OnDestroy()
        {
            EditorUserBuildSettings.activeBuildTargetChanged -= OnBuildTargetChanged;

            if (null != _listview)
            {
                _listview.TryShowApplyRevertSettings(false, null);
                _listview.Changed -= OnListboxChanged;
                _listview.SavePrefs();
                _listview.Dispose();
                _listview = null;
            }

            Images.OnDestroy();
        }
        #endregion

        #region OnGUI
        /// <summary>
        /// Called periodically to handle and draw the UI.
        /// </summary>
        protected override void __OnGUI()
        {
            _menu.OnGUI();
            _listview.OnGUI();
            _bottommenu.OnGUI();
        }
        #endregion

        #region OnEnterPlayMode
        /// <summary>
        /// Called when Unity is about to switch from edit- to play-mode.
        /// </summary>
        protected override void __OnEnterPlayMode()
        {
            base.__OnEnterPlayMode();
            _listview.TryShowApplyRevertSettings(true,
                delegate()
                {
                    // don't allow to switch to playmode when user pressed cancel
                    EditorApplication.isPlaying = false;
                });
        }
        #endregion

        #region OnFindCommand
        /// <summary>
        /// Called when the user invoked the find command (Ctrl+F).
        /// </summary>
        protected override void __OnFindCommand()
        {
            _searchfield.Focus();
        }
        #endregion

        #region OnBuildTargetChanged
        /// <summary>
        /// Called when the user changed the active platform target.
        /// </summary>
        void OnBuildTargetChanged()
        {
            DoPickModeChange(_pickmode);
        }
        #endregion

        #region OnLockToggle
        /// <summary>
        /// Called when the user clicked the Lock button.
        /// </summary>
        /// <remarks>The Lock button is available in Selection PickMode only.</remarks>
        void OnLockToggle(GUIControl sender)
        {
            SetLock(!_locked);
        }

        /// <summary>
        /// Gets the UI status of the Lock button.
        /// </summary>
        GUIControlStatus OnQueryLockToggle(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Selection)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }

        /// <summary>
        /// Locks/Unlocks the Selection PickMode.
        /// </summary>
        /// <param name="locked">true to lock, false to unlock.</param>
        void SetLock(bool locked)
        {
            if (locked)
            {
                _lockbutton.Image = Images.Lock16x16;
                _lockbutton.Text = "Unlock";
            }
            else
            {
                _lockbutton.Image = Images.Unlock16x16;
                _lockbutton.Text = "Lock";
            }

            _locked = locked;
        }
        #endregion

        #region OnRefreshScene
        /// <summary>
        /// Called when the user pressed the Refresh button.
        /// </summary>
        /// <remarks>The Refresh button is available in Scene PickMode only.</remarks>
        void OnRefreshScene(GUIControl sender)
        {
            DoPickModeChange(PickMode.Scene);
        }

        /// <summary>
        /// Gets the UI status of the Refresh button.
        /// </summary>
        GUIControlStatus OnQueryRefreshScene(GUIControl sender)
        {
            var status = GUIControlStatus.None;
            if (_pickmode == PickMode.Scene)
                status |= GUIControlStatus.Visible | GUIControlStatus.Enable;

            return status;
        }
        #endregion

        #region OnPlatformChange
#if UNITY_5
        /// <summary>
        /// Called when the user switches the platform in the toolbar platform selection menu.
        /// </summary>
        /// <param name="sender"></param>
        void OnPlatformChange(GUIControl sender)
        {
            var platform = (BuildTargetGroup)sender.Tag;

            _listview.SetPlatform(platform);

            //DoPickModeChange(_pickmode);
        }
#endif
        #endregion

        #region OnPickModeChange
        /// <summary>
        /// Called when the pick mode (Project, Scene, Selection) changed.
        /// </summary>
        void OnPickModeChange(GUIControl sender)
        {
            var popup = (GUIToolbarPopup)sender;

            SetLock(false);
            _pickmode = (PickMode)popup.SelectedItem.Tag;
            EditorPrefs.SetInt(string.Format("{0}.PickMode", Globals.ProductId), (int)_pickmode);
            DoPickModeChange(_pickmode);
        }

        void DoPickModeChange(PickMode newpickmode)
        {
            switch (newpickmode)
            {
                case PickMode.Selection:
                    _listview.SetItems(new List<string>());
                    OnSelectionChange();
                    break;
                case PickMode.Project:
                    _listview.SetItems(new List<string>(AssetDatabase.GetAllAssetPaths()));
                    break;
                case PickMode.Scene:
                    {
                        // TODO: figure out how to find inactive objects
                        var deps = EditorUtility.CollectDependencies(GameObject.FindObjectsOfType(typeof(GameObject)));
                        var paths = new List<string>(deps.Length);
                        foreach (var p in deps)
                        {
                            var path = AssetDatabase.GetAssetPath(p);
                            if (!string.IsNullOrEmpty(path))
                                paths.Add(path);
                        }
                        _listview.SetItems(paths);
                    }
                    break;
            }

            Repaint();
        }
        #endregion

        #region OnSelectionChange
        /// <summary>
        /// Called when the listbox selection changed.
        /// </summary>
        void OnSelectionChange()
        {
            if (!IsInited)
                return;

            // get the current selection
            var selection = Selection.objects;

            // I'm not really happy with this line of code, particulary with the 'ChangeUnitySelectionTime'.
            // it makes sure that the OnSelectionChange() call only has an impact when any selection change
            // caused by the list is more than 0.5 seconds ago. without this line of code, the plugin most
            // likely ends up in an infinite loop when being in PickMode.Selection, because if the list assigns
            // the selection unity triggers OnSelectionChange() and without the 0.5sec delay the selection is
            // assigned to the list immediately and OnSelectionChange() is called again etc.
            if (_pickmode != PickMode.Selection || _locked || _listview.ChangeUnitySelectionTime + 0.5f > DateTime.Now.TimeOfDay.TotalSeconds)// || selection.Length == 0)
                return;

            // get all audio clips from selection
            var paths = new List<string>();
            selection = EditorUtility.CollectDependencies(selection);

            var selectionpaths = new List<string>();
            foreach (var obj in selection)
            {
                if (obj is AudioClip)
                {
                    paths.Add(AssetDatabase.GetAssetPath(obj));
                }
            }

            // now paths only contains paths of textures
            _listview.SetItems(paths);
            Repaint();
        }
        #endregion

        #region OnToolsApplyAll
        /// <summary>
        /// Called when the user clicked the 'Apply all' button.
        /// </summary>
        void OnToolsApplyAllExecute(GUIToolbarMenuItem sender)
        {
            _listview.ApplyRevertAll(true);
        }

        /// <summary>
        /// Called when the user clicked the 'Revert all' button.
        /// </summary>
        void OnToolsRevertAllExecute(GUIToolbarMenuItem sender)
        {
            _listview.ApplyRevertAll(false);
        }

        /// <summary>
        /// Gets the UI status of the apply and revert buttons.
        /// </summary>
        GUIControlStatus OnToolsApplyRevertAllQueryStatus(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible;
            if (_listview.IsModified)
                result |= GUIControlStatus.Enable; // enable only when list contains modified items
            return result;
        }
        #endregion

        #region OnToolsExportCsv
        /// <summary>
        /// Exports the listbox content as CSV.
        /// </summary>
        void OnToolsExportCsvExecute(GUIToolbarMenuItem sender)
        {
            _listview.SaveCsv();
        }
        #endregion

        #region OnToolsReimportAll
        /// <summary>
        /// Called when the user clicked the 'Reimport all' button.
        /// </summary>
        void OnToolsReimportAllExecute(GUIToolbarMenuItem sender)
        {
            _listview.ReimportAll();
        }

        /// <summary>
        /// Gets the UI status of the 'Reimport all' button.
        /// </summary>
        GUIControlStatus OnToolsReimportAllQueryStatus(GUIToolbarMenuItem sender)
        {
            var result = GUIControlStatus.Visible;
            if (_listview.ItemCount > 0)
                result |= GUIControlStatus.Enable;
            return result;
        }
        #endregion

        #region OnAbout
        /// <summary>
        /// Called when the user clicked the About button.
        /// </summary>
        void OnAboutExecute(GUIControl sender)
        {
            var wnd = AboutWindow.GetWindow<AboutWindow>(true, "About " + title, true);
            wnd.ProductName = Globals.ProductName;
            wnd.FeedbackUrl = Globals.ProductFeedbackUrl;
            wnd.AssetStoreUrl = Globals.ProductAssetStoreUrl;
            wnd.Show();
        }
        #endregion

        #region OnSearchChange
        /// <summary>
        /// Called when the search text or type changed.
        /// </summary>
        void OnSearchChange(GUIControl sender)
        {
            var searchfield = (GUIToolbarSearchField)sender;
            EditorPrefs.SetInt(string.Format("{0}.TextFilterMode", Globals.ProductId), searchfield.SearchMode);
            _listview.SetFilter(sender.Text, (Listbox.FilterMode)searchfield.SearchMode);

            if (_listview.ItemCount == 0 && !string.IsNullOrEmpty(sender.Text))
                _listview.EmptyText = "No match found. Proper search mode used?\n\nYou can choose the search mode using the magnifying glass next to the search field.\nYou can drop files and folders on the search field.\nYou can use search operators like: && (and) || (or) and ! (not)";
            else
                _listview.EmptyText = "The list is empty.";
        }
        #endregion

        #region OnListboxChanged
        /// <summary>
        /// Called when the listbox changed.
        /// </summary>
        void OnListboxChanged(Listbox sender)
        {
            _searchlabel.Text = _listview.ItemCountString;
            _statslabel.Text = _listview.SelectionString;
        }
        #endregion
    }
}
