﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using UnityEngine;

[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Peter Schraut")]
[assembly: AssemblyProduct("AudioClipExplorer")]
[assembly: AssemblyCopyright("Copyright 2011-2015 Peter Schraut")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.0.*")]

#if UNITY_5
[assembly: AssemblyTitle("AudioClip Explorer for Unity 5")]
[assembly: Guid("bae8ef7c-64f9-4789-9aa1-93a28e70a874")]
[assembly: AssemblyIsEditorAssembly]
#else
[assembly: AssemblyTitle("AudioClip Explorer for Unity 4")]
[assembly: Guid("2d2813b6-d55a-4651-8789-cb5374fb2458")]
#endif