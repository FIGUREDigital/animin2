-------------------------------------------------------------------------------
  Overview
-------------------------------------------------------------------------------

The solution consists of three projects, which is neccessary to support
multiple Unity versions:

AudioClipExplorer
  This is the installation window that checks whether to install Texture Overview
  for Unity 4 or Unity 5. This project is referencing DLL's from an early Unity 4
  version.

AudioClipExplorerUnity4
  This is AudioClip Explorer for Unity 4.
  It adds the conditional compilation directive 'UNITY_4'.
  This project references DLL's from an early Unity 4.x version.

AudioClipExplorerUnity5
  This is AudioClip Explorer for Unity 5.
  It adds the conditional compilation directive 'UNITY_5'.
  This project references DLL's from Unity 5.0.


-------------------------------------------------------------------------------
  Compiling the Solution
-------------------------------------------------------------------------------

In order to compile the solution, you need to adjust the 'References' (see below)
to UnityEditor.dll and UnityEngine.dll in each project.

This is neccessary, because 'References' points to Unity installations
on my computer and I most likely installed Unity to different folders than you.

If you don't need to compile Texture Overview for multiple Unity versions, but
for Unity 5 only, you can remove all projects other than AudioClipExplorerUnity5.
The compiled DLL will be stored in bin\unity5.


-------------------------------------------------------------------------------
  Adjusting References in Microsoft Visual Studio
-------------------------------------------------------------------------------

  Open the "References" folder in the Solution Explorer. You probably see a warning icon for
  UnityEditor.dll and UnityEngine.dll. Remove them both, then right-click on the "References" folder
  and choose "Add Reference". In the following dialog, click browse and navigate to
  the Unity installation directory to add both back to the project.

  On my computer they're located at:
    C:\Program Files (x86)\Unity\Editor\Data\Managed\UnityEditor.dll
    C:\Program Files (x86)\Unity\Editor\Data\Managed\UnityEngine.dll

  Open the properties of both dll's and set "Copy Local" to "False".


-------------------------------------------------------------------------------
  Adjusting References in Mono Develop
-------------------------------------------------------------------------------

  Open the "References" folder in the Solution. You probably see a warning icon for
  UnityEditor.dll and UnityEngine.dll. Remove them both, then right-click on
  the "References" folder and choose "Edit References".
  In the following dialog, switch to ".Net Assembly" tab and navigate to
  the Unity installation directory to add both back to the project.

  On my computer they're located at:
    C:\Program Files (x86)\Unity\Editor\Data\Managed\UnityEditor.dll
    C:\Program Files (x86)\Unity\Editor\Data\Managed\UnityEngine.dll

  Select these dll's in the "Edit References" dialog, click "Add" and then "OK". These files now
  appear in the "References" folder too. Right-click each of these dll's and untick the "Local Copy" option.

