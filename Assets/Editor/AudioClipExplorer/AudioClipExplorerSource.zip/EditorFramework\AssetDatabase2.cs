﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Linq;
using System.Text;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// AssetDatabase2 provides helper methods to work with assets in the project.
    /// </summary>
    public static class AssetDatabase2
    {
        #region Private Fields
        static Dictionary<string, Type> _extensionToAssetType = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase);
        #endregion

        #region class UnityScene
        /// <summary>
        /// The UnityScene is just a dummy class so we can actually
        /// map a type to a file-extension.
        /// </summary>
        public class UnityScene
        {
        }

        /// <summary>
        /// The UnityAsset is just a dummy class so we can actually
        /// map a type to a file-extension.
        /// </summary>
        public class UnityAsset
        {
        }
        #endregion

        #region ctor
        static AssetDatabase2()
        {
#if UNITY_5
            _extensionToAssetType.Add("hdr", typeof(Cubemap));
#endif
            _extensionToAssetType.Add("asset", typeof(UnityAsset));
            _extensionToAssetType.Add("unity", typeof(UnityScene));
            _extensionToAssetType.Add("anim", typeof(AnimationClip));
            _extensionToAssetType.Add("physicmaterial", typeof(PhysicMaterial));
            _extensionToAssetType.Add("shader", typeof(Shader));
            _extensionToAssetType.Add("cubemap", typeof(Cubemap));
            _extensionToAssetType.Add("mat", typeof(Material));
            _extensionToAssetType.Add("material", typeof(Material));
            _extensionToAssetType.Add("wav", typeof(AudioClip));
            _extensionToAssetType.Add("mp3", typeof(AudioClip));
            _extensionToAssetType.Add("ogg", typeof(AudioClip));
            _extensionToAssetType.Add("aif", typeof(AudioClip));
            _extensionToAssetType.Add("aiff", typeof(AudioClip));
            _extensionToAssetType.Add("xm", typeof(AudioClip));
            _extensionToAssetType.Add("mod", typeof(AudioClip));
            _extensionToAssetType.Add("it", typeof(AudioClip));
            _extensionToAssetType.Add("s3m", typeof(AudioClip));
            _extensionToAssetType.Add("exr", typeof(Texture));
            _extensionToAssetType.Add("psd", typeof(Texture2D));
            _extensionToAssetType.Add("tif", typeof(Texture2D));
            _extensionToAssetType.Add("tiff", typeof(Texture2D));
            _extensionToAssetType.Add("jpg", typeof(Texture2D));
            _extensionToAssetType.Add("tga", typeof(Texture2D));
            _extensionToAssetType.Add("png", typeof(Texture2D));
            _extensionToAssetType.Add("gif", typeof(Texture2D));
            _extensionToAssetType.Add("bmp", typeof(Texture2D));
            _extensionToAssetType.Add("iff", typeof(Texture2D));
            _extensionToAssetType.Add("pict", typeof(Texture2D));
            _extensionToAssetType.Add("prefab", typeof(GameObject));
            _extensionToAssetType.Add("fbx", typeof(Mesh));
            _extensionToAssetType.Add("obj", typeof(Mesh));
            _extensionToAssetType.Add("max", typeof(Mesh));
            _extensionToAssetType.Add("blend", typeof(Mesh));
            _extensionToAssetType.Add("txt", typeof(TextAsset));
            _extensionToAssetType.Add("html", typeof(TextAsset));
            _extensionToAssetType.Add("htm", typeof(TextAsset));
            _extensionToAssetType.Add("xml", typeof(TextAsset));
            _extensionToAssetType.Add("bytes", typeof(TextAsset));
            _extensionToAssetType.Add("json", typeof(TextAsset));
            _extensionToAssetType.Add("csv", typeof(TextAsset));
            _extensionToAssetType.Add("yaml", typeof(TextAsset));
            _extensionToAssetType.Add("fnt", typeof(TextAsset));
            _extensionToAssetType.Add("ttf", typeof(Font));
            _extensionToAssetType.Add("otf", typeof(Font));
            _extensionToAssetType.Add("dfont", typeof(Font));
            _extensionToAssetType.Add("mov", typeof(MovieTexture));
            _extensionToAssetType.Add("mpg", typeof(MovieTexture));
            _extensionToAssetType.Add("mpeg", typeof(MovieTexture));
            _extensionToAssetType.Add("mp4", typeof(MovieTexture));
            _extensionToAssetType.Add("avi", typeof(MovieTexture));
            _extensionToAssetType.Add("asf", typeof(MovieTexture));
        }
        #endregion

        #region GetRelativeAssetPath
        /// <summary>
        /// Gets a relative path of the specified full path.
        /// </summary>
        /// <param name="path">The path, eg 'c:/Projects/MyGame/Assets/Textures/Explosion.psd'</param>
        /// <returns>The releative path to the Assets directory, eg 'Assets/Textures/Explosion.psd'</returns>
        public static string GetRelativeAssetPath(string path)
        {
            if (string.IsNullOrEmpty(path))
                return "";

            var assetpath = path.Replace('\\', '/');
            if (assetpath.StartsWith(Application.dataPath))
                return assetpath.Substring(Application.dataPath.Length - "Assets".Length);

            return path;
        }
        #endregion

        #region GUIDToLibraryPath
        /// <summary>
        /// Gets the file path of the specified asset GUID inside the Unity Library folder.
        /// </summary>
        /// <param name="assetGuid">The asset GUID.</param>
        /// <returns>The path on success, an empty string otherwise.</returns>
        public static string GUIDToLibraryPath(string assetGuid)
        {
            if (string.IsNullOrEmpty(assetGuid) || assetGuid.Length < 2)
                return "";

            var twoletter = assetGuid.Substring(0, 2);
            var assetPath = Application.dataPath.Substring(0, Application.dataPath.Length - "/Assets".Length);
            assetPath = assetPath + "/Library/metadata/" + twoletter + "/" + assetGuid;

            return assetPath;
        }
        #endregion

        #region GetStorageSize
        /// <summary>
        /// Gets the storage size of the specified asset path inside the Unity Library folder.
        /// </summary>
        /// <param name="assetPath">The asset path relative to the 'Assets' directory.</param>
        /// <returns>The storage size on success, -1 otherwise.</returns>
        public static long GetStorageSize(string assetPath)
        {
            var id = AssetDatabase.AssetPathToGUID(assetPath);
            if (string.IsNullOrEmpty(id) || id.Length < 2)
                return -1;

            assetPath = GUIDToLibraryPath(id);
            if (System.IO.File.Exists(assetPath))
                return new System.IO.FileInfo(assetPath).Length;

            return -1;
        }
        #endregion

        #region GetTextMetaFilePathFromAssetPath
        /// <summary>
        /// Gets the path to the text .meta file associated with the asset of the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The asset path</param>
        /// <returns>The meta file path on success, an empty string otherwise.</returns>
        public static string GetTextMetaFilePathFromAssetPath(string assetPath)
        {
#if UNITY_5
            return AssetDatabase.GetTextMetaFilePathFromAssetPath(assetPath);
#else
            return AssetDatabase.GetTextMetaDataPathFromAssetPath(assetPath);
#endif
        }
        #endregion

        #region GetAssetLastWriteTime
        /// <summary>
        /// Gets the last write time of the specified asset or its meta file,
        /// depending on which one is newer.
        /// </summary>
        /// <param name="assetPath">The asset path relative to the 'Assets' directory.</param>
        /// <returns>A DateTime structure set to the date and time that the specified file was last written to. This value is expressed in local time.</returns>
        public static DateTime GetAssetLastWriteTime(string assetPath)
        {
            DateTime assettime = DateTime.MinValue;
            try
            {
                assettime = System.IO.File.GetLastWriteTime(assetPath);
            }
            catch
            {
                assettime = DateTime.MinValue;
            }

            var metapath = GetTextMetaFilePathFromAssetPath(assetPath);
            if (!string.IsNullOrEmpty(metapath))
            {
                DateTime metatime;
                try
                {
                    metatime = System.IO.File.GetLastWriteTime(metapath);
                }
                catch
                {
                    metatime = DateTime.MinValue;
                }

                var now = DateTime.Now;
                var assetage = now - assettime;
                var metaage = now - metatime;

                if (assetage < metaage)
                    return assettime;
                else
                    return metatime;
            }

            return DateTime.MinValue;
        }
        #endregion

        #region IsAssetType
        /// <summary>
        /// Gets whether the asset at the specified assetPath is equal to the specified type.
        /// </summary>
        /// <param name="assetPath">The asset path relative to the 'Assets' directory.</param>
        /// <param name="type">The asset type to expect</param>
        /// <returns>True when the asset is of the specified type, false otherwise.</returns>
        public static bool IsAssetType(string assetPath, Type type)
        {
            return GetAssetType(assetPath) ==  type;
        }
        #endregion

        #region GetAssetType
        /// <summary>
        /// Gets the asset type of the asset at the specified assetPath.
        /// </summary>
        /// <param name="assetPath">The asset path relative to the 'Assets' directory.</param>
        /// <returns>The type on success, null otherwise.</returns>
        public static Type GetAssetType(string assetPath)
        {
            var extension = FileUtil2.GetFileExtension(assetPath);
            if (!string.IsNullOrEmpty(extension))
            {
                Type value;
                if (_extensionToAssetType.TryGetValue(extension, out value))
                    return value;
            }
            return null;
        }
        #endregion

        #region GetPathsByType
        /// <summary>
        /// Gets all paths of assets in the project that are of the specified type.
        /// </summary>
        /// <param name="type">The asset type.</param>
        /// <returns>A list containing the asset paths of the specified type.</returns>
        public static List<string> GetPathsByType(Type type)
        {
            return GetPathsByType(new[] { type });
        }

        /// <summary>
        /// Gets all paths of assets in the project that match one of the specified types.
        /// </summary>
        /// <param name="types">One or multiple types.</param>
        /// <returns>A list containing the asset paths of the specified type.</returns>
        public static List<string> GetPathsByType(IEnumerable<Type> types)
        {
            var paths = AssetDatabase.GetAllAssetPaths();
            var result = new List<string>(128);

            foreach (var path in paths)
            {
                foreach (var t in types)
                {
                    if (IsAssetType(path, t))
                    {
                        result.Add(path);
                        break;
                    }
                }
            }
            return result;
        }
        #endregion

        #region Reimport
        /// <summary>
        /// Reimports assets of the specified paths.
        /// </summary>
        /// <param name="paths">Paths of assets to reimport.</param>
        /// <param name="confirmcount">The minimum number of paths to display a confirm dialog.</param>
        /// <returns>true when assets got reimported, false otherwise.</returns>
        public static bool Reimport(List<string> paths, int confirmcount)
        {
            return Reimport(paths, confirmcount, ImportAssetOptions.Default);
        }

        /// <summary>
        /// Reimports assets of the specified paths.
        /// </summary>
        /// <param name="paths">Paths of assets to reimport.</param>
        /// <param name="confirmcount">The minimum number of paths to display a confirm dialog.</param>
        /// <param name="importoptions">The import options.</param>
        /// <returns>true when assets got reimported, false otherwise.</returns>
        public static bool Reimport(List<string> paths, int confirmcount, ImportAssetOptions importoptions)
        {
            if (confirmcount > 0 && paths.Count >= confirmcount)
            {
                var builder = new StringBuilder(128);
                var count = 0;

                foreach (var path in paths)
                {
                    if (count < 3)
                        builder.AppendLine("'" + path + "'");
                    else if (count == 3)
                        builder.AppendLine("...");
                    count++;
                }

                var title = "Reimport asset?";
                if (paths.Count > 1)
                    title = string.Format("Reimport {0} assets?", paths.Count);

                if (!EditorUtility.DisplayDialog(title, builder.ToString(), "Reimport", "Cancel"))
                    return false;
            }

            foreach (var path in paths)
                AssetDatabase.ImportAsset(path, importoptions);

            AssetDatabase.Refresh();
            return true;
        }
        #endregion

        #region Delete
        /// <summary>
        /// Deletes assets of the specified paths.
        /// </summary>
        public static void Delete(List<string> paths)
        {
            if (null == paths || paths.Count == 0)
                return;

            var builder = new StringBuilder(128);
            var count = 0;
            foreach (var path in paths)
            {
                if (count < 3)
                    builder.AppendLine("'" + path + "'");
                else if (count == 3)
                    builder.AppendLine("...");
                count++;
            }
            builder.AppendLine();
            builder.AppendLine("You cannot undo this action.");

            var title = "Delete asset?";
            if (paths.Count > 1)
                title = string.Format("Delete {0} assets?", paths.Count);

            if (!EditorUtility.DisplayDialog(title, builder.ToString(), "Delete", "Cancel"))
                return;

            using (var progressbar = new EditorGUI2.ModalProgressBar("Deleting...", true))
            {
                for (var n = 0; n < paths.Count; ++n)
                {
                    var path = paths[n];
                    if (paths.Count > 10)
                    {
                        var progress = n / (float)paths.Count;
                        if (progressbar.Update(path, progress))
                            break;
                    }

                    AssetDatabase.DeleteAsset(path);
                }
            }

            AssetDatabase.Refresh();
        }
        #endregion

        #region GetPathsInDirectory
        /// <summary>
        /// Gets the paths of assets that match the specified directory, using a value to determine whether to search subdirectories.
        /// </summary>
        /// <param name="directory">The relative path to the directory to search.</param>
        /// <param name="searchOption">One of the enumeration values that specifies whether the search operation should include all subdirectories or only the current directory. </param>
        /// <returns>A list with the asset paths.</returns>
        public static List<string> GetPathsInDirectory(string directory, System.IO.SearchOption searchOption)
        {
            directory = directory.Replace('\\', '/');
            if (directory[directory.Length - 1] != '/')
                directory += '/';

            var result = new List<string>(64);
            var paths = AssetDatabase.GetAllAssetPaths();
            for (var n = 0; n < paths.Length; ++n)
            {
                var path = paths[n];
                if (searchOption == System.IO.SearchOption.AllDirectories)
                {
                    if (path.StartsWith(directory, StringComparison.OrdinalIgnoreCase))
                        result.Add(path);
                }
                else
                {
                    if (string.Equals(directory, FileUtil2.GetDirectoryName(path) + '/', StringComparison.OrdinalIgnoreCase))
                        result.Add(path);
                }
            }
            return result;
        }
    }
        #endregion

    #region AssetFileNameComparer
    /// <summary>
    /// Represents a string comparison operation that is ignoring case and follows ordinal comparison rules.
    /// Only the asset name part of  the specified string is being compared.
    /// </summary>
    sealed public class AssetFileNameComparer : IComparer<string>
    {
        #region Private Fields
        int _greaterResult = +1;
        int _smallerResult = -1;
        #endregion

        #region Public Fields
        /// <summary>
        /// Lowest to Highest (A..Z)
        /// </summary>
        public static readonly AssetFileNameComparer Ascending = new AssetFileNameComparer(+1, -1);

        /// <summary>
        /// Highest to Lowest (Z..A)
        /// </summary>
        public static readonly AssetFileNameComparer Descending = new AssetFileNameComparer(-1, +1);
        #endregion

        public AssetFileNameComparer(int greaterResult, int smallerResult)
        {
            _greaterResult = greaterResult;
            _smallerResult = smallerResult;
        }

        public int Compare(string x, string y)
        {
            x = FileUtil2.GetFileName(x);
            y = FileUtil2.GetFileName(y);

            if (string.Compare(x, y, StringComparison.OrdinalIgnoreCase) > 0)
                return _greaterResult;

            if (string.Compare(x, y, StringComparison.OrdinalIgnoreCase) < 0)
                return _smallerResult;

            return 0;
        }
    }
    #endregion

    #region AssetFilePathComparer
    /// <summary>
    /// Represents a string comparison operation that is ignoring case and follows ordinal comparison rules.
    /// </summary>
    sealed public class AssetFilePathComparer : IComparer<string>
    {
        #region Private Fields
        int _greaterResult = +1;
        int _smallerResult = -1;
        #endregion

        #region Public Fields
        /// <summary>
        /// Lowest to Highest (A..Z)
        /// </summary>
        public static readonly AssetFilePathComparer Ascending = new AssetFilePathComparer(+1, -1);

        /// <summary>
        /// Highest to Lowest (Z..A)
        /// </summary>
        public static readonly AssetFilePathComparer Descending = new AssetFilePathComparer(-1, +1);
        #endregion

        public AssetFilePathComparer(int greaterResult, int smallerResult)
        {
            _greaterResult = greaterResult;
            _smallerResult = smallerResult;
        }

        public int Compare(string x, string y)
        {
            if (string.Compare(x, y, StringComparison.OrdinalIgnoreCase) > 0)
                return _greaterResult;

            if (string.Compare(x, y, StringComparison.OrdinalIgnoreCase) < 0)
                return _smallerResult;

            return 0;
        }
    }
    #endregion
}
