﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// AudioImporter2 provides helper methods to get information about audio files.
    /// </summary>
    /// <remarks>
    /// Most methods AudioImporter2 provides are actually available in UnityEditor.AudioImporter, but
    /// they are not public in there. So AudioImporter2 is basically a wrapper that gets access to those hidden methods.
    /// </remarks>
    public static class AudioImporter2
    {
        #region Private Fields
        static Type _type;
#if UNITY_4
        static PropertyInfo _defaultBitrate;
        static PropertyInfo _origChannelCount;
        static PropertyInfo _origIsMonoForcable;
        static PropertyInfo _origIsCompressible;
        static PropertyInfo _origType;
        static MethodInfo _minBitrate;
        static MethodInfo _maxBitrate;
        static MethodInfo _updateOrigData;
#endif
#if UNITY_5
        static PropertyInfo _compSize;
#endif
        #endregion

        #region ctor
        static AudioImporter2()
        {
            _type = typeof(AudioImporter).Assembly.GetType("UnityEditor.AudioImporter");
            if (_type != null)
            {
                #region Unity 4
#if UNITY_4
                _defaultBitrate = _type.GetProperty("defaultBitrate", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_defaultBitrate == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.defaultBitrate'.");

                _origChannelCount = _type.GetProperty("origChannelCount", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_origChannelCount == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.origChannelCount'.");

                _origIsMonoForcable = _type.GetProperty("origIsMonoForcable", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_origIsMonoForcable == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.origIsMonoForcable'.");

                _origIsCompressible = _type.GetProperty("origIsCompressible", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_origIsCompressible == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.origIsCompressible'.");

                _origType = _type.GetProperty("origType", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_origType == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.origType'.");

                _minBitrate = _type.GetMethod("minBitrate", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_minBitrate == null)
                    Debug.LogWarning("Could not find method 'UnityEditor.AudioImporter.minBitrate'.");

                _maxBitrate = _type.GetMethod("maxBitrate", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_maxBitrate == null)
                    Debug.LogWarning("Could not find method 'UnityEditor.AudioImporter.maxBitrate'.");

                _updateOrigData = _type.GetMethod("updateOrigData", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_updateOrigData == null)
                    Debug.LogWarning("Could not find method 'UnityEditor.AudioImporter.updateOrigData'.");
#endif
                #endregion

                #region Unity 5
#if UNITY_5
                _compSize = _type.GetProperty("compSize", BindingFlags.NonPublic | BindingFlags.Instance);
                if (_compSize == null)
                    Debug.LogWarning("Could not find property 'UnityEditor.AudioImporter.compSize'.");
#endif
                #endregion
            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'UnityEditor.AudioImporter'.");
        }
        #endregion

#if UNITY_4
        #region GetDefaultBitrate
        /// <summary>
        /// Gets the default bitrate for the audio file of the specified importer.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>The default bitrate on success, -1 otherwise.</returns>
        public static int GetDefaultBitrate(AudioImporter importer)
        {
            if (null == _defaultBitrate)
                return -1;

            return (int)_defaultBitrate.GetValue(importer, null);
        }
        #endregion

        #region GetMinMaxBitrate
        /// <summary>
        /// Gets the minimum and maximum bitrate the audio file of  the specified importer can be set to.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <param name="origType">The AudioType of the source file, prio import. See AudioImporter2.GetOrigType.</param>
        /// <param name="min">The minimum bitrate.</param>
        /// <param name="max">The maximum bitrate.</param>
        /// <returns>true when the method succeded, false otherwise. If the method returns false, min/max is set to -1.</returns>
        public static bool GetMinMaxBitrate(AudioImporter importer, AudioType origType, out int min, out int max)
        {
            min = -1;
            max = -1;
            if (null == _minBitrate || null == _maxBitrate || origType == AudioType.UNKNOWN)
                return false;

            var importtype = AudioUtil2.GetPlatformConversionType(origType, BuildTargetGroup.Standalone, AudioImporterFormat.Compressed);
            object[] args = { importtype };
            min = (int)_minBitrate.Invoke(importer, args);
            max = (int)_maxBitrate.Invoke(importer, args);
            return true;
        }
        #endregion

        #region GetOrigType
        /// <summary>
        /// Gets the AudioType of the source audio file of specified importer prio import.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>The AudioType on success, AudioType.UNKNOWN otherwise.</returns>
        public static AudioType GetOrigType(AudioImporter importer)
        {
            if (null == _origType)
                return AudioType.UNKNOWN;

            var result = (AudioType)_origType.GetValue(importer, null);
            if (result < 0)
                return AudioType.UNKNOWN;
            return result;
        }
        #endregion

        #region GetOrigChannelCount
        /// <summary>
        /// Gets the number of channels of the source audio file, prior import.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>The number of channels on success, -1 otherwise.</returns>
        public static int GetOrigChannelCount(AudioImporter importer)
        {
            if (null == _origChannelCount)
                return -1;

            return (int)_origChannelCount.GetValue(importer, null);
        }
        #endregion

        #region GetOrigIsMonoForcable
        /// <summary>
        /// Gets whether the audio file of the specified importer can be configured to be mono.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>true when it can be forced to mono, false otherwise.</returns>
        public static bool GetOrigIsMonoForcable(AudioImporter importer)
        {
            if (null == _origIsMonoForcable)
                return false;

            return (bool)_origIsMonoForcable.GetValue(importer, null);
        }
        #endregion

        #region GetOrigIsCompressible
        /// <summary>
        /// Gets whether the audio file of the specified importer can be compressed.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>true when it can be compressed, false otherwise.</returns>
        public static bool GetOrigIsCompressible(AudioImporter importer)
        {
            if (null == _origIsCompressible)
                return false;

            return (bool)_origIsCompressible.GetValue(importer, null);
        }
        #endregion

        #region UpdateOrigData
        /// <summary>
        /// Updates information about the source audio file of the specified importer?
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <remarks>I noticed AudioImporter2.GetMinMaxBitrate sometimes returns wrong values when AudioImporter2.UpdateOrigData has not been called for an AudioImporter.</remarks>
        public static void UpdateOrigData(AudioImporter importer)
        {
            if (null == _updateOrigData)
                return;

            _updateOrigData.Invoke(importer, null);
        }
        #endregion
#endif // UNITY_4

#if UNITY_5
        #region GetImportedSize
        /// <summary>
        /// Gets the imported file size of the audio lip.
        /// </summary>
        /// <param name="importer">The AudioImporter</param>
        /// <returns>The imported file size on success, -1 otherwise.</returns>
        public static int GetImportedSize(AudioImporter importer)
        {
            if (null == _compSize)
                return -1;

            return (int)_compSize.GetValue(importer, null);
        }
        #endregion
#endif
    }
}
