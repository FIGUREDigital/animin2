﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;

namespace EditorFramework
{
    /// <summary>
    /// Helper class to convert audio properties to a formatted text representation.
    /// </summary>
    public static class AudioStringUtil
    {
        /// <summary>
        /// Gets a formatted text that describes the specified number of channels.
        /// </summary>
        /// <param name="channels">A value indicating the number of channels in an audio file.</param>
        /// <returns>Returns a formatted text that describes the specified number of channels.</returns>
        public static string Channels(int channels)
        {
            if (channels <= 0)
                return "???";

            switch (channels)
            {
                case 1: return "Mono";
                case 2: return "Stereo";
                default:
                    return string.Format("{0}.1", Math.Abs(channels - 1));
            }
        }

        /// <summary>
        /// Gets a formatted text that describes a size, such as 21 Bytes, 197 KB, 19 MB, etc.
        /// </summary>
        /// <param name="bytes">The size in bytes.</param>
        /// <returns>Returns a formatted text that describes a size.</returns>
        public static string Size(long bytes)
        {
            return EditorUtility2.FormatBytes(bytes);
        }

        /// <summary>
        /// Gets a formatted text that describes the specified frequency.
        /// </summary>
        /// <param name="frequency">A value indicating the frequency, in Hertz (hz), of an audio file.</param>
        /// <returns>Returns a formatted text that describes the specified frequency.</returns>
        public static string Frequency(int frequency)
        {
            return string.Format("{0:n0} Hz", frequency);
        }

        /// <summary>
        /// Gets a formatted text that describes the specified bits per sample of an audio file.
        /// </summary>
        /// <param name="bps">A value indicating the bits per sample of an audio file.</param>
        /// <returns>Returns a formatted text that describes the specified bits per sample of an audio file.</returns>
        public static string BitsPerSample(int bps)
        {
            return string.Format("{0} bit", bps);
        }

        /// <summary>
        /// Gets a formatted text that describes the duration of an audio file.
        /// </summary>
        /// <param name="durationMs">A value indicating the duration, in milliseconds, of an audio file.</param>
        /// <returns>Returns a formatted text that describes the duration of an audio file. The format is [Minutes]:[Seconds].[Milliseconds].</returns>
        public static string Duration(int durationMs)
        {
            if (durationMs < 0)
                return "Unlimited";

            var mins = (int)(durationMs / 60 / 1000.0f);
            var secs = (int)((durationMs / 1000.0f) % 60);
            var ms = (int)(durationMs % 1000);
            return string.Format("{0:D2}:{1:D2}.{2:D3}", mins, secs, ms);
        }

        /// <summary>
        /// Gets a formatted text that describes the specified compression of an audio file.
        /// </summary>
        /// <param name="bps">A value indicating the compression, in bits per sample, of an audio file.</param>
        /// <returns>Returns a formatted text that describes the specified compression in, kilo-bits-per-second, of an audio file.</returns>
        public static string Compression(int bps)
        {
            return string.Format("{0} kbps", bps / 1000);
        }

#if UNITY_5
        #region LoadType
        static string[] _AudioLoadTypeStrings;
        /// <summary>
        /// Gets the string representation of the specified value.
        /// </summary>
        /// <param name="value">The AudioClipLoadType.</param>
        /// <returns>The string representing the load type.</returns>
        public static string LoadType(UnityEngine.AudioClipLoadType value)
        {
            if (_AudioLoadTypeStrings == null)
            {
                var values = Enum.GetValues(typeof(UnityEngine.AudioClipLoadType));

                _AudioLoadTypeStrings = new string[values.Length];
                for (var n = 0; n < values.Length; ++n)
                    _AudioLoadTypeStrings[n] = "";

                foreach (var e in values)
                    _AudioLoadTypeStrings[(int)e] = e.ToString();
            }

            return _AudioLoadTypeStrings[(int)value];
        }
        #endregion

        #region CompressionFormat
        static string[] _AudioCompressionFormatStrings;
        /// <summary>
        /// Gets the string representation of the specified value.
        /// </summary>
        /// <param name="value">The AudioCompressionFormat.</param>
        /// <returns>The string representing the format.</returns>
        public static string CompressionFormat(UnityEngine.AudioCompressionFormat value)
        {
            if (_AudioCompressionFormatStrings == null)
            {
                var values = Enum.GetValues(typeof(UnityEngine.AudioCompressionFormat));

                _AudioCompressionFormatStrings = new string[values.Length];
                for (var n = 0; n < values.Length; ++n)
                    _AudioCompressionFormatStrings[n] = "";

                foreach (var e in values)
                    _AudioCompressionFormatStrings[(int)e] = e.ToString();
            }

            return _AudioCompressionFormatStrings[(int)value];
        }
        #endregion
#endif
    }
}
