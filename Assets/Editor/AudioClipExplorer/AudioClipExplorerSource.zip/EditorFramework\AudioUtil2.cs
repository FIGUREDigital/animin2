﻿//---------------------------------------
// Copyright (c) 2011-2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// AudioUtil2 provides helper methods to get information about audio clips.
    /// </summary>
    /// <remarks>
    /// Most methods AudioUtil2 provides are actually available in UnityEditor.AudioUtil, but
    /// they are not public in there. So AudioUtil2 is basically a wrapper to gets access to those hidden methods.
    /// </remarks>
    public static class AudioUtil2
    {
        #region Private Fields
        static Type _type;
        static MethodInfo _getBitsPerSample;
        static MethodInfo _getSize;
#if UNITY_4
        static MethodInfo _getPlatformConversionType;
        static MethodInfo _getcliptype;
#endif
#if UNITY_5
        static MethodInfo _isTrackerFile;
#endif
        #endregion

        #region ctor
        static AudioUtil2()
        {
            _type = typeof(AudioImporter).Assembly.GetType("UnityEditor.AudioUtil");
            if (_type != null)
            {
                _getBitsPerSample = _type.GetMethod("GetBitsPerSample", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioClip) }, null);
                _getSize = _type.GetMethod("GetSize", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioClip) }, null);

                // in Unity 4.5 the method changed from "GetSize" to "GetSoundSize"
                if (_getSize == null)
                    _getSize = _type.GetMethod("GetSoundSize", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioClip) }, null);

#if UNITY_4
                _getPlatformConversionType = _type.GetMethod("GetPlatformConversionType", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioType), typeof(BuildTargetGroup), typeof(AudioImporterFormat) }, null);
                _getcliptype = _type.GetMethod("GetClipType", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioClip) }, null);
#endif

#if UNITY_5
                _isTrackerFile = _type.GetMethod("IsTrackerFile", BindingFlags.Static | BindingFlags.Public, null, new[] { typeof(AudioClip) }, null);
#endif
            }

            if (null == _type)
                Debug.LogWarning("Could not find type 'UnityEditor.AudioUtil'.");

            if (null == _getBitsPerSample)
                Debug.LogWarning("Could not find method 'UnityEditor.AudioUtil.GetBitsPerSample(AudioClip)'.");

            if (null == _getSize)
                Debug.LogWarning("Could not find method 'UnityEditor.AudioUtil.GetSize(AudioClip)'.");

#if UNITY_4
            if (null == _getPlatformConversionType)
                Debug.LogWarning("Could not find method 'UnityEditor.AudioUtil.GetPlatformConversionType(AudioType, BuildTargetGroup, AudioImporterFormat)'.");

            if (null == _getcliptype)
                Debug.LogWarning("Could not find method 'UnityEditor.AudioUtil.GetClipType(AudioClip)'.");
#endif

#if UNITY_5
            if (null == _isTrackerFile)
                Debug.LogWarning("Could not find method 'UnityEditor.AudioUtil.IsTrackerFile(AudioType)'.");
#endif
        }
        #endregion

        #region GetBitsPerSample
        /// <summary>
        /// Gets the bits per sample of the specified clip.
        /// </summary>
        /// <param name="clip">The AudioClip</param>
        /// <returns>Returns the bits per same on success, -1 otherwise.</returns>
        public static int GetBitsPerSample(AudioClip clip)
        {
            if (null == _getBitsPerSample)
                return -1;

            var args = new object[] { clip };
            return (int)_getBitsPerSample.Invoke(null, args);
        }
        #endregion

        #region GetSize
        /// <summary>
        /// Gets the runtime size of the specified clip in bytes.
        /// </summary>
        /// <param name="clip">The AudioClip</param>
        /// <returns>Returns the size, specified in bytes, on success. -1 otherwise.</returns>
        public static int GetSize(AudioClip clip)
        {
            if (null == _getSize)
                return -1;

            var args = new object[] { clip };
            return (int)_getSize.Invoke(null, args);
        }
        #endregion

#if UNITY_5
        #region IsPlatformCompressionFormatSupported
        static bool[,] _PlatformFormatLUT; // _PlatformFormatLUT[platform, format] = true/false

        /// <summary>
        /// Gets whether the specified format is supported on the specified platform.
        /// </summary>
        /// <param name="platform">The BuildTargetGroup.</param>
        /// <param name="format">The AudioCompressionFormat.</param>
        /// <returns>true if supported, false otherwise.</returns>
        public static bool IsPlatformCompressionFormatSupported(BuildTargetGroup platform, AudioCompressionFormat format)
        {
            #region Build lookup table to quickly see if a format is supported on a certain platform
            if (_PlatformFormatLUT == null)
            {
                // find maximum value of BuildTargetGroup enum memmber
                int platformcount = 0;
                foreach(var value in Enum.GetValues(typeof(BuildTargetGroup)))
                    platformcount = Mathf.Max(platformcount, (int)value);

                // find maximum value of AudioCompressionFormat enum memmber
                int formatcount = 0;
                foreach (var value in Enum.GetValues(typeof(AudioCompressionFormat)))
                    formatcount = Mathf.Max(formatcount, (int)value);

                // allocate memory
                _PlatformFormatLUT = new bool[platformcount+1, formatcount+1];

                // fill lookup table
                foreach (var platformvalue in Enum.GetValues(typeof(BuildTargetGroup)))
                {
                    foreach (var formatvalue in GetPlatformCompressionFormats((BuildTargetGroup)platformvalue))
                    {
                        _PlatformFormatLUT[(int)platformvalue, (int)formatvalue] = true;
                    }
                }
            }
            #endregion

            return _PlatformFormatLUT[(int)platform, (int)format];
        }
        #endregion

        #region GetPlatformDefaultCompressionFormat
        /// <summary>
        /// Gets the default compression format for the specified platform.
        /// </summary>
        /// <param name="platform">The BuildTargetGroup.</param>
        /// <returns>The default compression format for the specified platform.</returns>
        public static AudioCompressionFormat GetPlatformDefaultCompressionFormat(BuildTargetGroup platform)
        {
            var formats = GetPlatformCompressionFormats(platform);
            return formats[0];
        }
        #endregion

        #region GetPlatformCompressionFormats
        /// <summary>
        /// Gets a list of supported compression formats for the specified platform.
        /// The element at index 0 represents the default compression format for the platform.
        /// </summary>
        /// <param name="platform">The target platform.</param>
        /// <returns>The list of supported compression formats.</returns>
        public static System.Collections.Generic.List<AudioCompressionFormat> GetPlatformCompressionFormats(BuildTargetGroup platform)
        {
            var result = new System.Collections.Generic.List<AudioCompressionFormat>();
            switch (platform)
            {
                case BuildTargetGroup.Unknown:
                case BuildTargetGroup.WSA:
                case BuildTargetGroup.WebPlayer:
                case BuildTargetGroup.Standalone:
                    result.Add(AudioCompressionFormat.Vorbis);
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    break;

                case BuildTargetGroup.iOS:
                case BuildTargetGroup.Android:
                case BuildTargetGroup.BlackBerry:
                //case BuildTargetGroup.WSA:
                case BuildTargetGroup.WP8:
                case BuildTargetGroup.PS4:
                case BuildTargetGroup.XBOX360:
                case BuildTargetGroup.SamsungTV:
                case BuildTargetGroup.Tizen:
                case BuildTargetGroup.GLESEmu:
                    result.Add(AudioCompressionFormat.Vorbis);
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    result.Add(AudioCompressionFormat.MP3);
                    break;

                case BuildTargetGroup.XboxOne:
                    result.Add(AudioCompressionFormat.XMA); // Unity 5.1
                    result.Add(AudioCompressionFormat.Vorbis);
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    result.Add(AudioCompressionFormat.MP3);
                    break;

                case BuildTargetGroup.WebGL:
                    result.Add(AudioCompressionFormat.AAC); // Unity 5.1
                    //result.Add(AudioCompressionFormat.MP3); // Unity 5.0
                    break;

                case BuildTargetGroup.PS3:
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    result.Add(AudioCompressionFormat.MP3);
                    break;

                case BuildTargetGroup.PSM:
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    result.Add(AudioCompressionFormat.MP3);
                    result.Add(AudioCompressionFormat.VAG);
                    break;

                case BuildTargetGroup.PSP2:
                    result.Add(AudioCompressionFormat.PCM);
                    result.Add(AudioCompressionFormat.ADPCM);
                    result.Add(AudioCompressionFormat.MP3);
                    result.Add(AudioCompressionFormat.HEVAG);
                    break;

                default:
                    throw new Exception(string.Format("Unsupported platform specified '{0}'.", platform));
            }

            return result;
        }
        #endregion

        #region IsTrackerFile
        /// <summary>
        /// Gets whether the specified clip is a tracker file (mod, sm3, it, ...)
        /// </summary>
        /// <param name="clip">The AudioClip</param>
        /// <returns>Returns true when it is a tracker file, false otherwise.</returns>
        public static bool IsTrackerFile(AudioClip clip)
        {
            if (_isTrackerFile == null)
                return false;

            var args = new object[] { clip };
            return (bool)_isTrackerFile.Invoke(null, args);
        }
        #endregion
#endif

#if UNITY_4
        #region GetClipType
        /// <summary>
        /// Gets the type (WAV, MPEG, XMA, etc) of the specified clip.
        /// </summary>
        /// <param name="clip">The AudioClip</param>
        /// <returns>Returns the AudioType on success, AudioType.UNKNOWN otherwise.</returns>
        public static AudioType GetClipType(AudioClip clip)
        {
            if (null == _getcliptype)
                return AudioType.UNKNOWN;

            var args = new object[] { clip };
            return (AudioType)_getcliptype.Invoke(null, args);
        }
        #endregion

        #region GetPlatformConversionType
        /// <summary>
        /// Gets the type of the imported audio clip for a specific platform.
        /// </summary>
        /// <param name="type">The type of the source audio file, prio import. See AudioImporter2.GetOrigType.</param>
        /// <param name="group">The build target group. See BuildPipeline2.GetBuildTargetGroup.</param>
        /// <param name="format">The audio format to get the type of. Usually AudioImporterFormat.Compressed.</param>
        /// <returns>The audio type on success, AudioType.UNKNOWN otherwise.</returns>
        public static AudioType GetPlatformConversionType(AudioType type, BuildTargetGroup group, AudioImporterFormat format)
        {
            if (null == _getPlatformConversionType)
                return AudioType.UNKNOWN;

            var args = new object[] { type, group, format };
            return (AudioType)_getPlatformConversionType.Invoke(null, args);
        }
        #endregion
#endif
    }
}
