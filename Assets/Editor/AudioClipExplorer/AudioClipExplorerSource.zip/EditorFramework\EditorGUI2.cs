﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// EditorGUI2 provides methods to draw GUI controls.
    /// </summary>
    /// <remarks>
    /// Some methods EditorGUI2 provides are actually available in UnityEditor.EditorGUI, but they are not public in there.
    /// </remarks>
    public static class EditorGUI2
    {
        #region Private Fields
        static MethodInfo _searchField;
        static MethodInfo _toolbarSearchField;
        #endregion

        #region ctor
        static EditorGUI2()
        {
            _searchField = typeof(EditorGUI).GetMethod("SearchField", BindingFlags.Static | BindingFlags.NonPublic);
            _toolbarSearchField = typeof(EditorGUI).GetMethod("ToolbarSearchField", BindingFlags.Static | BindingFlags.NonPublic, null, new[] { typeof(Rect), typeof(string[]), typeof(int).MakeByRefType(), typeof(string) }, null);

            if (null == _searchField)
                Debug.LogWarning("Could not find method 'UnityEditor.EditorGUI.SearchField'.");

            if (null == _toolbarSearchField)
                Debug.LogWarning("Could not find method 'UnityEditor.EditorGUI.ToolbarSearchField(Rect, string[], ref int, string)'.");
        }
        #endregion

        #region SearchField
        /// <summary>
        /// Draws a search field at the specified position.
        /// </summary>
        /// <param name="position">The position</param>
        /// <param name="text">The text. You basically pass the result of this method to the method itself.</param>
        /// <returns>The currnet search text.</returns>
        public static string SearchField(Rect position, string text)
        {
            if (null == _searchField)
                return text;

            var args = new object[] { position, text };
            return _searchField.Invoke(null, args) as string;
        }
        #endregion

        #region ToolbarSearchField
        /// <summary>
        /// Draws a search field in toolbar-style, with optional search modes, at the specified position.
        /// </summary>
        /// <param name="position">The position</param>
        /// <param name="text">The text. You basically pass the result of this method to the method itself.</param>
        /// <param name="searchModes">An array of string elements that represent the names of the available search modes.</param>
        /// <param name="searchMode">The index of an element in the searchModes array.</param>
        /// <returns>The currnet search text.</returns>
        public static string ToolbarSearchField(Rect position, string text, string[] searchModes, ref int searchMode)
        {
            if (null == _toolbarSearchField)
                return text;

            var args = new object[] { position, searchModes, searchMode, text };
            var result = _toolbarSearchField.Invoke(null, args) as string;
            searchMode = (int)args[2];
            return result;
        }
        #endregion

        #region Box
        /// <summary>
        /// Draws a box at the specified position.
        /// </summary>
        /// <param name="position">The position</param>
        /// <param name="content">The text, image and tooltip of the control.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        public static void Box(Rect position, GUIContent content, bool selected)
        {
            var oldcolor = GUI.color;
            GUI.color = GUIColors.TextColor(selected);
            GUI.Box(position, content, EditorStyles.whiteLabel);
            GUI.color = oldcolor;
        }
        #endregion

        #region Label
        /// <summary>
        /// Draws a label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the text is too long to fit inside the specified position, it adds '...' at the end.
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="content">The text, image and tooltip of the control.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        public static void Label(Rect position, GUIContent content, bool selected)
        {
            Label(position, content, selected, GUIColors.SelectedText, EditorStyles.whiteLabel, GUIColors.Text, EditorStyles.whiteLabel);
        }

        /// <summary>
        /// Draws a label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the text is too long to fit inside the specified position, it adds '...' at the end.
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="text">The text.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        public static void Label(Rect position, string text, bool selected)
        {
            Label(position, GUIContent2.Temp(text), selected, GUIColors.SelectedText, EditorStyles.whiteLabel, GUIColors.Text, EditorStyles.whiteLabel);
        }

        /// <summary>
        /// Draws a label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the text is too long to fit inside the specified position, it adds '...' at the end.
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="text">The text.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        /// <param name="color">The text color when the control is not selected.</param>
        public static void Label(Rect position, string text, bool selected, Color color)
        {
            Label(position, GUIContent2.Temp(text), selected, GUIColors.SelectedText, EditorStyles.whiteLabel, color, EditorStyles.whiteLabel);
        }

        /// <summary>
        /// Draws a label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the text is too long to fit inside the specified position, it adds '...' at the end.
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="content">The text, image and tooltip of the control.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        /// <param name="selectedColor">The text color when the control is selected.</param>
        /// <param name="selectedStyle">The gui style when the control is selected.</param>
        /// <param name="unselectedColor">The text color when the control is not selected.</param>
        /// <param name="unselectedStyle">The gui style when the control is not selected.</param>
        public static void Label(Rect position, GUIContent content, bool selected, Color selectedColor, GUIStyle selectedStyle, Color unselectedColor, GUIStyle unselectedStyle)
        {
            if (null == content)
                content = new GUIContent("");

            if (null == selectedStyle)
                selectedStyle = EditorStyles.whiteLabel;

            if (null == unselectedStyle)
                unselectedStyle = EditorStyles.whiteLabel;

            var oldcolor = GUI.color;
            GUI.color = selected ? selectedColor : unselectedColor;

            if (EditorStyles.label.CalcSize(content).x > position.width)
            {
                var dotrect = position;
                dotrect.x += dotrect.width - 18;
                dotrect.width = 16;

                var tooltip = string.IsNullOrEmpty(content.tooltip) ? content.text : content.text;
                position.width -= dotrect.width;
                GUI.Label(position, GUIContent2.Temp(content.text, content.image, tooltip), selected ? selectedStyle : unselectedStyle);
                GUI.Label(dotrect, GUIContent2.Temp("...", tooltip), selected ? selectedStyle : unselectedStyle);
            }
            else
                GUI.Label(position, content, selected ? selectedStyle : unselectedStyle);

            GUI.color = oldcolor;
        }
        #endregion

        #region PathLabel
        /// <summary>
        /// Draws a path label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the specified text is too long to fit inside the specified position,
        /// the text gets shortened by removing text-blocks separated by a forward-slash.
        /// Eg. "Assets/Sounds/Player/Healing/heal_00.wav" might be shortened to "Assets/Sounds/.../heal_00.wav"
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="text">The text.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        public static void PathLabel(Rect position, string text, bool selected)
        {
            PathLabel(position, text, selected, GUIColors.SelectedText, EditorStyles.whiteLabel, GUIColors.Text, EditorStyles.whiteLabel);
        }

        /// <summary>
        /// Draws a path label at the specified position.
        /// </summary>
        /// <remarks>
        /// If the specified text is too long to fit inside the specified position,
        /// the text gets shortened by removing text-blocks separated by a forward-slash.
        /// Eg. "Assets/Sounds/Player/Healing/heal_00.wav" might be shortened to "Assets/Sounds/.../heal_00.wav"
        /// </remarks>
        /// <param name="position">The position</param>
        /// <param name="text">The text.</param>
        /// <param name="selected">Indicates whether the control is selected. The text color of a selected control is different from an unselected control.</param>
        /// <param name="selectedColor">The text color when the control is selected.</param>
        /// <param name="selectedStyle">The gui style when the control is selected.</param>
        /// <param name="unselectedColor">The text color when the control is not selected.</param>
        /// <param name="unselectedStyle">The gui style when the control is not selected.</param>
        public static void PathLabel(Rect position, string text, bool selected, Color selectedColor, GUIStyle selectedStyle, Color unselectedColor, GUIStyle unselectedStyle)
        {
            // TODO: not happy with it yet, because it generates garbage
            var orgtext = text;
            var oldcolor = GUI.color;
            GUI.color = selected ? selectedColor : unselectedColor;

            //text = text.Substring("Assets/".Length);

            var trycount = 0;
        TryAgain:
            trycount++;
            if (trycount < 5 && EditorStyles.label.CalcSize(GUIContent2.Temp(text)).x > position.width)
            {
                text = text.Replace("/.../", "/");

                var lastdot = text.LastIndexOf('/');
                if (lastdot != -1)
                {
                    var index = text.LastIndexOf('/', lastdot-1);
                    if (index != -1)
                    {
                        var name = text.Substring(lastdot + 1);
                        var path = text.Substring(0, index);
                        text = path + "/.../" + name;

                        goto TryAgain;
                    }
                }

                text = ".../" + FileUtil2.GetFileName(orgtext);
                if (EditorStyles.label.CalcSize(GUIContent2.Temp(text)).x > position.width)
                {
                    var dotrect = position;
                    dotrect.x += dotrect.width - 18;
                    dotrect.width = 16;

                    position.width -= dotrect.width;
                    GUI.Label(position, GUIContent2.Temp(text, orgtext), selected ? selectedStyle : unselectedStyle);
                    GUI.Label(dotrect, GUIContent2.Temp("...", orgtext), selected ? selectedStyle : unselectedStyle);
                }
                else
                    GUI.Label(position, GUIContent2.Temp(text), selected ? selectedStyle : unselectedStyle);
            }
            else
                GUI.Label(position, GUIContent2.Temp(text, trycount > 1 ? orgtext : ""), selected ? selectedStyle : unselectedStyle);

            GUI.color = oldcolor;
        }
        #endregion

        #region ModalProgressBar
        /// <summary>
        /// Helper to display a modal progressbar.
        /// </summary>
        /// <remarks>
        /// This struct implements the IDisposable to use it inside 'using' blocks
        /// to ensure the progressbar gets closed if the program throws an exception inside the using block.
        /// </remarks>
        /// <example>
        /// using (var progressbar = new EditorGUI2.ModalProgressBar("Doing work...", true))
        /// {
        ///     var count = 100;
        ///     for (var n = 0; n < count; ++n)
        ///     {
        ///         var progress = n / (float)count;
        ///         if (progressbar.Update(string.Format("Task {0}", n), progress))
        ///             break;
        ///
        ///         System.Threading.Thread.Sleep(100);
        ///     }
        /// }
        /// </example>
        public struct ModalProgressBar : IDisposable
        {
            #region Private Fields
            static readonly string[] TextAnim = new string[] { "", ".", "..", "...", "....", "....." };
            //static readonly string[] TextAnim = new string[] { " |", " \\", " -", " /" };
            //static readonly string[] TextAnim = new string[] { " .", " o", " O", " @", " *" };
            float _starttime;
            int _frame;
            float _frametime;
            string[] _titles;
            float _updatetime;
            #endregion

            /// <summary>
            /// The progressbar title.
            /// </summary>
            public string Title;

            /// <summary>
            /// Indicates whether to display a Cancel button in the progressbar dialog.
            /// </summary>
            public bool Cancable;

            /// <summary>
            /// Indicates whether the progressbar has been canceled.
            /// </summary>
            public bool Canceled;

            /// <summary>
            /// Gets the time since the progressbar has been started.
            /// </summary>
            public float TotalElapsedTime
            {
                get
                {
                    return Time.realtimeSinceStartup - _starttime;
                }
            }

            /// <summary>
            /// Gets the time since the last progressbar update
            /// </summary>
            public float ElapsedTime
            {
                get
                {
                    return Time.realtimeSinceStartup - _updatetime;
                }
            }

            /// <summary>
            /// Initializes a new instance of the ModalProgressBar struct.
            /// </summary>
            /// <param name="title">The progressbar title.</param>
            /// <param name="cancable">Whether the progressbar should provide a Cancel button.</param>
            public ModalProgressBar(string title, bool cancable)
                : this()
            {
                Title = title;
                Cancable = cancable;
                Begin(title);

                _titles = new string[TextAnim.Length];
                for (var n = 0; n < _titles.Length; ++n)
                    _titles[n] = title + TextAnim[n % TextAnim.Length];
            }

            /// <summary>
            /// Begins a progressbar.
            /// </summary>
            /// <param name="title">The progressbar title.</param>
            /// <remarks>
            /// Calling this method is required only, when you create a ModalProgressBar using the default constructor.
            /// </remarks>
            public void Begin(string title)
            {
                _starttime = Time.realtimeSinceStartup;
                _updatetime = 0;
                Title = title;
            }

            /// <summary>
            /// Closes the progressbar.
            /// </summary>
            public void End()
            {
                if (_starttime > 0)
                    EditorUtility.ClearProgressBar();
            }

            /// <summary>
            /// Updates the progressbar with the specified text and progress.
            /// </summary>
            /// <param name="text">The text</param>
            /// <param name="progress">The progress in range 0..1</param>
            /// <returns>true when the user pressed the Cancel button, false otherwise.</returns>
            public bool Update(string text, float progress)
            {
                if (Canceled)
                    return Canceled;

                _updatetime = Time.realtimeSinceStartup;

                // animate the title, because progressbars are boring
                var title = _titles[_frame % TextAnim.Length];
                if (_updatetime - _frametime > 0.2f)
                {
                    _frametime = _updatetime;
                    _frame++;
                }

                //float elapsed = Time.realtimeSinceStartup - _starttime;
                //if (elapsed > 10)
                //{
                //    var estimation = elapsed * (1.0f / Mathf.Clamp01(progress));
                //    var remaining = estimation - elapsed;
                //
                //    var minutes = (int)remaining / 60;
                //    var seconds = (int)remaining % 60;
                //    if (minutes > 0)
                //        title = string.Format("{0} ({1}:{2:00} minutes remaining)", Title, minutes, seconds);
                //    else
                //        title = string.Format("{0} ({1} seconds remaining)", Title, seconds);
                //}

                if (Cancable)
                {
                    Canceled = EditorUtility.DisplayCancelableProgressBar(title, text, progress);
                    return Canceled;
                }

                EditorUtility.DisplayProgressBar(title, text, progress);
                return false;
            }

            /// <summary>
            /// Ends the progressbar.
            /// </summary>
            public void Dispose()
            {
                End();
            }
        }
        #endregion
    }
}
