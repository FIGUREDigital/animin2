﻿//---------------------------------------
// Copyright (c) 2015 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Reflection;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public static class EditorPrefs2
    {
        public static void SetIntArray(string key, int[] value)
        {
            SetIntArray(key, value, 0, value.Length);
        }

        static void SetIntArray(string key, int[] value, int startindex, int count)
        {
            var text = new System.Text.StringBuilder(value.Length * 8);

            var endindex = startindex + count;
            for (var n = startindex; n < endindex; ++n)
            {
                text.AppendFormat("{0}", value[n]);
                if (n+1<endindex)
                    text.Append(",");
            }

            EditorPrefs.SetString(key, text.ToString());
        }

        public static int[] GetIntArray(string key, int[] defaultvalue)
        {
            int[] result = null;
            try
            {
                if (EditorPrefs.HasKey(key))
                {
                    var values = EditorPrefs.GetString(key, "").Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                    if (values.Length > 0)
                    {
                        result = new int[values.Length];
                        for (var n = 0; n < values.Length; ++n)
                            result[n] = int.Parse(values[n]);

                        return result;
                    }
                }
            }
            catch
            {
                result = null;
            }

            if (result == null && defaultvalue != null)
            {
                result = new int[defaultvalue.Length];
                for (var n = 0; n < defaultvalue.Length; ++n)
                    result[n] = defaultvalue[n];
            }

            return result;
        }
    }
}
