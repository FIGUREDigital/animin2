﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    /// <summary>
    /// GUIColors provides helper methods and properties to get colors for certain GUI tasks.
    /// </summary>
    public static class GUIColors
    {
        #region Private Fields
        static Color _playmodetint = Color.white;
        static string _playmodetintString;
        #endregion

        #region Update
        /// <summary>
        /// Periodically called to read the current playmode tint color.
        /// </summary>
        /// <remarks>
        /// I didn't find any event that is raised when the user updates the playmode tint color,
        /// so in order that playmode tint color changes are reflected in the plugins GUI immediately,
        /// we have to read this setting periodically.
        /// </remarks>
        internal static void Update()
        {
            var text = EditorPrefs.GetString("Playmode tint", "");
            if (!string.Equals(_playmodetintString, text))
            {
                _playmodetintString = text;

                // get editor playmode tint color
                if (!string.IsNullOrEmpty(text))
                {
                    // The format is as follows: Playmode tint;1;0.3731343;0.3731343;1
                    // colorname;r;g;b;a
                    var elements = text.Split(';');
                    if (elements.Length == 5)
                    {
                        var color = new Color();
                        var success = true;
                        success &= float.TryParse(elements[1], out color.r);
                        success &= float.TryParse(elements[2], out color.g);
                        success &= float.TryParse(elements[3], out color.b);
                        success &= float.TryParse(elements[4], out color.a);

                        if (success)
                            _playmodetint = color;
                    }
                }
            }
        }
        #endregion

        #region PlaymodeTint
        /// <summary>
        /// Gets the editor playmode tint color.
        /// </summary>
        public static Color PlaymodeTint
        {
            get
            {
                return _playmodetint;
            }
        }
        #endregion

        #region TintIfPlaying
        /// <summary>
        /// Tints the specified color if the editor is in playing mode.
        /// </summary>
        /// <param name="color">The color</param>
        /// <returns>a tinted color in playing mode, the original color otherwise.</returns>
        public static Color TintIfPlaying(Color color)
        {
            if (EditorApplication.isPlayingOrWillChangePlaymode)
                color *= _playmodetint;
            return color;
        }
        #endregion

        #region TextColor
        /// <summary>
        /// Gets the text color depending whether it's selected.
        /// </summary>
        /// <param name="selected">Indicates whether the control of the text is selected.</param>
        /// <returns>the color</returns>
        public static Color TextColor(bool selected)
        {
            return selected ? SelectedText : Text;
        }
        #endregion

        #region Text
        /// <summary>
        /// Gets the text color for unselected elements.
        /// </summary>
        public static Color Text
        {
            get
            {
                Color color = EditorStyles.label.normal.textColor;

                if (EditorApplication.isPlayingOrWillChangePlaymode)
                    color *= _playmodetint;

                return color;
            }
        }
        #endregion

        #region SelectedText
        /// <summary>
        /// Gets the text color for selected elements.
        /// </summary>
        public static Color SelectedText
        {
            get
            {
                return TintIfPlaying(Color.white);
            }
        }
        #endregion

        #region ActiveSelection
        /// <summary>
        /// Gets the background color of an active selection (blue).
        /// </summary>
        public static Color ActiveSelection
        {
            get
            {
                Color color;
                if (EditorGUIUtility.isProSkin)
                    color = new Color(61 / 255.0f, 96 / 255.0f, 145 / 255.0f, 1);
                else
                    color = new Color(61 / 255.0f, 128 / 255.0f, 223 / 255.0f, 1);

                return TintIfPlaying(color);
            }
        }
        #endregion

        #region Hyperlink
        /// <summary>
        /// Gets the background color of an active selection (blue).
        /// </summary>
        public static Color Hyperlink
        {
            get
            {
                Color color = new Color(0 / 255.0f, 122 / 255.0f, 204 / 255.0f, 1);
                return color;
            }
        }
        #endregion

        #region InactiveSelection
        /// <summary>
        /// Gets the background color of an inactive selection (gray).
        /// </summary>
        public static Color InactiveSelection
        {
            get
            {
                Color color;
                if (EditorGUIUtility.isProSkin)
                    color = new Color(72 / 255.0f, 72 / 255.0f, 72 / 255.0f, 1);
                else
                    color = new Color(142 / 255.0f, 142 / 255.0f, 142 / 255.0f, 1);

                return TintIfPlaying(color);
            }
        }
        #endregion

        #region GetPrefabTypeColor
        /// <summary>
        /// Gets the text color for an object depending on its prefab type.
        /// </summary>
        /// <remarks>
        /// You should have noticed the different colors in the Unity Hierachy-View
        /// depending on the state of a prefab connection/disconnection. This method
        /// somehow tries to mimic this coloring scheme.
        /// </remarks>
        /// <param name="obj">The object.</param>
        /// <returns>The color.</returns>
        public static Color GetPrefabTypeColor(UnityEngine.Object obj)
        {
            if (null == obj)
                return EditorStyles.label.normal.textColor;

            switch (PrefabUtility.GetPrefabType(obj))
            {
                case PrefabType.Prefab:
                case PrefabType.PrefabInstance:
                case PrefabType.ModelPrefab:
                case PrefabType.ModelPrefabInstance:
                    return new Color(0, 0, 0.5f);

                case PrefabType.MissingPrefabInstance:
                case PrefabType.DisconnectedPrefabInstance:
                    return new Color(0.7f, 0.3f, 0.3f);

                default:
                    return EditorStyles.label.normal.textColor;
            }
        }
        #endregion
    }
}
