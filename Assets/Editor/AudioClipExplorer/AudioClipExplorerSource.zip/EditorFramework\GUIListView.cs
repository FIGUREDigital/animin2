﻿//---------------------------------------
// Copyright (c) 2011-2014 Peter Schraut
// http://console-dev.de
//---------------------------------------

using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

namespace EditorFramework
{
    public class GUIListViewException : System.Exception
    {
        public GUIListViewException(string message)
            : base(message)
        {
        }
    }

    public struct GUIListViewDrawItemArgs
    {
        public object Model;
        public int ModelIndex;
        public Rect ItemRect;
        public GUIListViewColumn Column;
        public bool Selected;
    }

    public struct GUIListViewDrawItemBackgroundArgs
    {
        public object Model;
        public int ModelIndex;
        public Rect Rect;
        public GUIListViewColumn Column;
        public bool Selected;
        public List<object> SelectedItems; // snapshot of all selected items during this frame

        // in/out values
        public Color Color;
        public Texture Texture;
        public bool Handled;
    }

    public struct GUIListViewIsItemPositionClickableArgs
    {
        public object Model;
        public int ModelIndex;
        public Rect ItemRect;
        public GUIListViewColumn Column;
        public Vector2 MousePosition;
    }

    public struct GUIListViewGetItemKeywordArgs
    {
        public object Model;
        public int ModelIndex;
        public GUIListViewColumn Column;
    }

    public struct GUIListViewGetItemTextArgs
    {
        public object Model;
        public int ModelIndex;
        public GUIListViewColumn Column;
    }

    public struct GUIListViewItemKeyDownArgs
    {
        public object Model;
        public int ModelIndex;

        // in/out values
        public bool Handled;
    }

    public enum GUIListViewImageDrawMode
    {
        None,
        Alphablend,
        Alpha
    }

    //public struct GUIListViewGetItemImageArgs
    //{
    //    public object Model;
    //    public int ModelIndex;
    //    public Rect ItemRect;
    //    public GUIListViewColumn Column;
    //    public bool Selected;

    //    //public Rect ImageRect;
    //    //public Rect RemainingItemRect;
    //    //public Texture Image;
    //    //public Vector2 ImageSize;
    //    //public Rect ImageTexCoords;
    //    //public ScaleMode ImageScaleMode;
    //    //public GUIListViewImageDrawMode ImageDrawMode;
    //}

    //public struct GUIListViewGetItemImageResult
    //{
    //    public Rect ImageRect;
    //    public Rect RemainingItemRect;
    //    public Texture Image;
    //    //public Vector2 ImageSize;
    //    public Rect ImageTexCoords;
    //    public ScaleMode ImageScaleMode;
    //    public GUIListViewImageDrawMode ImageDrawMode;
    //}

    public struct GUIListViewContextMenuArgs
    {
        public object Model;
        public int ModelIndex;
        public GUIListViewColumn Column;
        public bool Selected;
        public Vector2 MenuLocation;
    }

    public enum GUIListViewMode
    {
        List,
        Tile,
        Details
    }

    public enum GUIListViewSortMode
    {
        None,
        Ascending,
        Descending
    }

    public class GUIListViewColumn
    {
        #region Internal
        internal int Index;
        internal float RealWidth;
        internal Rect ColumnRect;
        internal long SortPrio = -1;
        #endregion

        public delegate int CompareDelelgate(object x, object y);

        /// <summary>
        /// The name used when serializing/deserializing the column setting
        /// </summary>
        public string SerializeName;

        /// <summary>
        /// Gets/sets the column header text.
        /// </summary>
        public string Text;

        /// <summary>
        /// Gets/sets the text displayed in the context menu popup.
        /// </summary>
        public string PopupText;

        /// <summary>
        /// Gets/sets how the column header text is aligned.
        /// </summary>
        public TextAnchor TextAlignment = TextAnchor.MiddleLeft;

        /// <summary>
        /// Gets/sets a tooltip that is displayed when the user hovers over the column header text.
        /// </summary>
        public string Tooltip;

        /// <summary>
        /// Gets or sets an image that is displayed next in the column header.
        /// </summary>
        public Texture Image;

        /// <summary>
        /// Gets or sets the column width.
        /// </summary>
        public float Width;

        /// <summary>
        /// Gets or sets the column background color.
        /// </summary>
        public Color Color;

        /// <summary>
        /// Gets or sets a value indicating how to sort items in this column.
        /// </summary>
        public GUIListViewSortMode SortMode = GUIListViewSortMode.None;

        /// <summary>
        /// Gets/sets the minimum width the column can get resized to.
        /// </summary>
        public float MinWidth = 16;

        /// <summary>
        /// Gets/sets the maximum width the column can get resized to.
        /// </summary>
        public float MaxWidth = float.PositiveInfinity;

        /// <summary>
        /// Gets/set whether the column is visible.
        /// </summary>
        public bool Visible = true;

        /// <summary>
        /// Gets/sets whether the column can be resized by the user.
        /// </summary>
        public bool IsResizable = true;

        /// <summary>
        /// Gets or sets a delegate that is called when sorting items.
        /// If no CompareFunc is specified, the column cannot be sorted.
        /// </summary>
        public CompareDelelgate CompareFunc;

        /// <summary>
        /// Gets the index of the column.
        /// </summary>
        public int DisplayIndex;

        /// <summary>
        /// Gets whether the column is the primary column, that is the first column in the list.
        /// </summary>
        public bool IsPrimaryColumn
        {
            get
            {
                return DisplayIndex == 0;
            }
        }

        public GUIListViewColumn()
        {
        }

        public GUIListViewColumn(string text, string tooltip, Texture image, float width, CompareDelelgate comparefunc)
        {
            Text = text;
            Tooltip = tooltip;
            Image = image;
            Width = width;
            CompareFunc = comparefunc;
            Color = Color.clear;
        }

        static Texture2D _sortArrayUp;
        public static Texture2D SortIcon
        {
            get
            {
                if (null == _sortArrayUp)
                {
                    _sortArrayUp = new Texture2D(8, 4, TextureFormat.ARGB32, false, true);
                    _sortArrayUp.hideFlags = HideFlags.HideAndDontSave;
                    _sortArrayUp.SetPixels32(_sortArrowUpPixelData);
                    _sortArrayUp.Apply();
                }
                return _sortArrayUp;
            }
        }

        readonly static Color32[] _sortArrowUpPixelData = new Color32[]
        {
             new Color32(74,73,74,255), new Color32(134,133,134,255), new Color32(134,133,134,255), new Color32(134,133,134,255), new Color32(161,160,161,255), new Color32(161,160,161,255),
             new Color32(161,160,161,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(74,73,74,255), new Color32(74,73,74,255), new Color32(134,133,134,255),
             new Color32(115,113,115,255), new Color32(115,113,115,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
             new Color32(74,73,74,255), new Color32(74,73,74,255), new Color32(115,113,115,255), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0),
             new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(255,255,255,0), new Color32(74,73,74,255), new Color32(255,255,255,0), new Color32(255,255,255,0),
             new Color32(255,255,255,0), new Color32(255,255,255,0),
        };
    }

    public enum GUIListViewHeaderStyle
    {
        None,
        Nonclickable,
        ClickablePopup,
        Clickable
    }

    class GUIListViewOrganizeColumnWindow : EditorWindow
    {
        class Item
        {
            public GUIListViewColumn Column;
            public bool Visible;
            public float Y;
            public float OrgY;
            public float FadeY;
            public Item OrgItemAbove;
            public Item OrgItemBelow;
        }

        private static GUIContent _tempcontent;
        private int _itemheight = 22;
        private List<Item> _items = new List<Item>();
        private Item _dragitem;

        public GUIListView ListView;

        public void SetListView(GUIListView view)
        {
            ListView = view;
            _items = new List<Item>();
            for (var n=0; n<view.Columns.Count; ++n)
            {
                var column = view.Columns[n];

                var item = new Item();
                item.Column = column;
                item.OrgY = n * _itemheight;
                item.FadeY = item.OrgY;
                item.Y = item.OrgY;
                item.Visible = column.Visible;

                _items.Add(item);
            }

            for (var n = 0; n < _items.Count; ++n)
            {
                var item = _items[n];
                item.OrgItemAbove = n > 0 ? _items[n - 1] : null;
                item.OrgItemBelow = n < _items.Count - 1 ? _items[n + 1] : null;
            }

            this.minSize = new Vector2(275, view.Columns.Count * _itemheight + 44);
            //this.wantsMouseMove = true;
        }

        void OnDestroy()
        {
            if (null != ListView)
                ListView.SavePrefs();
        }

        void DrawItem(Item item, Rect rect, bool active)
        {
            rect.x += 2; rect.width -= 4;

            // Clear the item background
            if (active)
            {
                var oldcolor = GUI.color;
                GUI.color = GUIColors.ActiveSelection;
                EditorGUI.DrawPreviewTexture(rect, EditorGUIUtility.whiteTexture);
                EditorGUIUtility.AddCursorRect(rect, MouseCursor.MoveArrow);

                var space = 4.0f;
                var r = new Rect(rect.x, 0, rect.width, space);
                if (item.OrgItemAbove != null && item.OrgItemBelow != null)
                {
                    r.y = item.OrgItemAbove.FadeY + _itemheight - space * 0.5f;
                    r.height = item.OrgItemBelow.FadeY - item.OrgItemAbove.FadeY - _itemheight + space;
                }

                if (item.OrgItemAbove != null && item.OrgItemBelow == null)
                {
                    r.y = item.OrgItemAbove.FadeY + _itemheight - space * 0.5f;
                    r.height = space;
                }

                if (item.OrgItemAbove == null && item.OrgItemBelow != null)
                {
                    r.y = item.OrgItemBelow.FadeY - space * 0.5f;
                    r.height = space;
                }

                EditorGUI.DrawPreviewTexture(r, EditorGUIUtility.whiteTexture);

                GUI.color = oldcolor;
            }
            else
                EditorGUI.HelpBox(rect, "", MessageType.None);

            // Draw the column title
            var column = item.Column;
            var text = string.IsNullOrEmpty(column.PopupText) ? column.Text : column.PopupText;
            EditorGUI2.Label(rect, TempContent(text, column.Image, ""), active);

            // Draw the visible toggle
            rect.x += rect.width - 16; rect.width = 16;
            if (GUI.Toggle(rect, item.Visible, TempContent("", null, "Show Column")) != item.Visible)
                item.Visible = !item.Visible;
        }

        void OnGUI()
        {
            if (null == ListView)
                this.Close();

            for (var n = 0; n < _items.Count; ++n)
            {
                var item = _items[n];
                if (item == _dragitem)
                    continue;

                // animation y position
                var val = item.Y - item.FadeY;
                item.FadeY += Mathf.Clamp(val * Time.deltaTime * 1000, -Mathf.Abs(val), Mathf.Abs(val));

                // Draw item
                var itemrect = new Rect(0, item.FadeY, position.width, _itemheight);
                DrawItem(item, itemrect, false);

                // Check for mouse down to start dragging
                if (Event.current.type == EventType.mouseDown && itemrect.Contains(Event.current.mousePosition) && Event.current.button == 0)
                {
                    _dragitem = item;
                    Event.current.Use();
                }
            }

            if (null != _dragitem)
            {
                var itemrect = new Rect(0, _dragitem.FadeY, position.width, _itemheight);
                DrawItem(_dragitem, itemrect, true);

                // Check for mouse drag
                if (Event.current.type == EventType.mouseDrag && Event.current.button == 0)
                {
                    _dragitem.FadeY = Event.current.mousePosition.y - _itemheight * 0.5f;
                    _dragitem.FadeY = Mathf.Clamp(_dragitem.FadeY, 0, _items.Count * _itemheight - _itemheight);
                    var index = (int)(_dragitem.FadeY * _itemheight) / (int)_itemheight;

                    _items.Sort(delegate(Item a, Item b) { return a.FadeY.CompareTo(b.FadeY); });

                    for (var n = 0; n < _items.Count; ++n)
                    {
                        var item = _items[n];
                        if (item == _dragitem)
                            continue;

                        item.Y = n * _itemheight;
                        //item.OrgY = item.FadeY;
                    }
                }

                // Check for mouse up
                if (Event.current.type == EventType.mouseUp && Event.current.button == 0)
                {
                    for (var n = 0; n < _items.Count; ++n)
                    {
                        var item = _items[n];
                        item.FadeY = n * _itemheight;
                        item.Y = n * _itemheight;
                        item.OrgY = item.FadeY;
                        item.OrgItemAbove = n > 0 ? _items[n - 1] : null;
                        item.OrgItemBelow = n < _items.Count - 1 ? _items[n + 1] : null;
                    }

                    _dragitem = null;
                    Event.current.Use();
                }
            }

            var helprect = new Rect(2, position.height - 40, position.width - 128, 36);
            EditorGUI.HelpBox(helprect, "Drag&drop items to change column order", MessageType.Info);

            // Cancel button
            var leftbuttonrect = new Rect(position.width - 122, position.height - 24, 58, 20);
            if (GUI.Button(leftbuttonrect, "Cancel"))
            {
                Close();
                return;
            }

            // OK button
            var rightbuttonrect = new Rect(position.width - 60, position.height - 24, 58, 20);
            if (GUI.Button(rightbuttonrect, "OK"))
            {
                ListView.Columns.Clear();
                for (var n = 0; n < _items.Count; ++n)
                {
                    var column = _items[n].Column;
                    column.Visible = _items[n].Visible;
                    ListView.Columns.Add(column);
                }

                ListView.Editor.Repaint();

                Close();
                return;
            }

            // Always trigger a repaint so the item animations keep blending
            Repaint();
        }

        static GUIContent TempContent(string text, Texture image, string tooltip)
        {
            if (null == _tempcontent) _tempcontent = new GUIContent();
            _tempcontent.text = text;
            _tempcontent.tooltip = tooltip;
            _tempcontent.image = image;
            return _tempcontent;
        }
    }

    public enum GUIListViewSelectMode
    {
        None,
        LeftMouseButton,
        RightMouseButton,
        Both
    }

    class GUIListViewResizeColumnContext
    {
        GUIListView _listview;
        GUIListViewColumn _column;
        float _originalWidth;
        float _currentWidth;
        Vector2 _beginningMousePosition;

        public bool IsResizing
        {
            get
            {
                return null != _column;
            }
        }

        public GUIListViewResizeColumnContext(GUIListView listview)
        {
            _listview = listview;
        }

        /// <summary>
        /// Begins resizing the specified column.
        /// </summary>
        public void Begin(GUIListViewColumn column)
        {
            _column = column;
            _originalWidth = column.Width;
            _beginningMousePosition = Event.current.mousePosition;
        }

        /// <summary>
        /// Ends resizing the column and applies the new width.
        /// </summary>
        public void End()
        {
            _column.Width = _currentWidth;
            _column = null;

            _listview.SavePrefs();
            _listview.Editor.Repaint();
        }

        /// <summary>
        /// Must be called during EventType.repaint when IsResizing returns true.
        /// </summary>
        public void Update()
        {
            _currentWidth = _originalWidth - (int)(_beginningMousePosition.x - Event.current.mousePosition.x);
            _currentWidth = Mathf.Min(_column.MaxWidth, Mathf.Max(_column.MinWidth, _currentWidth));
            _column.Width = _currentWidth;
        }

        /// <summary>
        /// Cancels the current resizing and restoring the original width again.
        /// </summary>
        public void Cancel()
        {
            _column.Width = _originalWidth;
            _column = null;
            _listview.Editor.Repaint();
        }
    }

    public enum GUIListViewBackgroundImageLayout
    {
        None,
        Tile,
        Center,
        TopLeft,
        TopRight,
        BottomLeft,
        BottomRight,
        Strech,
    }

    public abstract class GUIListView : GUIControl
    {
        struct ItemSelInfo
        {
            public float Time;
            public bool Clicked;

            public ItemSelInfo(float time, bool clicked)
                : this()
            {
                Time = time;
                Clicked = clicked;
            }
        }

        class GUIListViewModelComparer : IComparer<object>
        {
            //public GUIListViewColumn Column;
            public List<GUIListViewColumn> Columns = new List<GUIListViewColumn>();

            public GUIListViewModelComparer()
            {
            }

            public int Compare(object x, object y)
            {
                for (var n = 0; n < Columns.Count; ++n)
                {
                    var column = Columns[n];
                    if (null == column || null == column.CompareFunc)
                        continue;

                    var a = column.SortMode == GUIListViewSortMode.Ascending ? x : y;
                    var b = column.SortMode == GUIListViewSortMode.Ascending ? y : x;

                    var aisnull = null == a;
                    var bisnull = null == b;
                    if (aisnull && bisnull)
                        continue;
                    if (!aisnull && bisnull)
                        return +1;
                    if (aisnull && !bisnull)
                        return -1;

                    var result = column.CompareFunc(a, b);
                    if (result == 0)
                        continue;
                    if (result < 0)
                        return -1;
                    else
                        return +1;
                }
                return 0;
            }
        }

        Vector2 _scrollbarPos;
        Dictionary<object, ItemSelInfo> _selection = new Dictionary<object, ItemSelInfo>();
        Dictionary<object, int> _visibleItems = new Dictionary<object, int>();
        Dictionary<object, int> _newvisibiles = new Dictionary<object, int>();
        int _drawid;
        DrawContext _lastRepaintContext;
        GUIListViewResizeColumnContext _columnresize;
        string _emptyText;
        GUIStyle _emptyTextStyle;

        struct DrawContext
        {
            public Vector2 ScrollBounds;
            public Rect ClientRect;
            public Rect ListRect;
            public Rect VScrollRect;
            public Rect HScrollRect;
            public int ColumnCount;
            public Rect ItemRect;
            public int RowCount;
            public int VisibleRowCount;
            public int TotalRowCount;
            public int TopRow;
            public int TopVisibleRow;
            public int BottomRow;
            public int BottomVisibleRow;
            public float VScrollOffset;
            public float HScrollOffset;
            public int FirstItem;
            public int LastItem;
            public int FirstVisibleItem;
            public int LastVisibleItem;
            public int VisibleItemCount;
            public GUIListViewColumn Column;
            public Rect RowRect;
            public bool Selected;
            public bool HotTracking;
            public object Item;
            public int ItemIndex;
            public int TotalItemCount;
            public float HeaderHeight;
            public int ControlId;
            public bool IsMouseInside;
        }

        public Vector2 ItemSize
        {
            get;
            set;
        }

        public Vector2 ItemMargin
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether the full row is used to select items.
        /// </summary>
        public bool FullRowSelect
        {
            get;
            set;
        }

        public virtual GUIListViewMode Mode
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets the column header style.
        /// </summary>
        public GUIListViewHeaderStyle HeaderStyle
        {
            get;
            set;
        }

        public int HeaderHeight
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the collection of all column headers in the listview.
        /// </summary>
        public List<GUIListViewColumn> Columns
        {
            get;
            private set;
        }

        public GUIListViewColumn FlexibleColumn
        {
            get;
            set;
        }

        public bool HotTracking
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether vertical lines appear between the columns in the listview.
        /// </summary>
        public bool ShowColumnLines
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether multiple items can be selected.
        /// </summary>
        public bool MultiSelect
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating whether the listview can respond to user interaction.
        /// </summary>
        public bool Enabled
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating the control supports drag&drop asset operations.
        /// </summary>
        public bool DragDropEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets which column is used to perform a drag operation. Use null to use all columns for dragging.
        /// </summary>
        public GUIListViewColumn DragColumn
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets whether the list supports panning.
        /// That is, using the middle mouse button to freely move the list around in all directions.
        public bool PanningEnabled
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets whether the control accepts right mouse-clicks to change the selection.
        /// </summary>
        public bool RightClickSelect
        {
            get;
            set;
        }

        /// <summary>
        /// Gets the column that is used for sorting or null when no sorting is active.
        /// </summary>
        //public GUIListViewColumn SortColumn
        //{
        //    get
        //    {
        //        foreach (var column in Columns)
        //        {
        //            if (column.SortMode != GUIListViewSortMode.None)
        //                return column;
        //        }
        //        return null;
        //    }
        //}

        /// <summary>
        /// The path that is used to store listview settings in the unity editor prefs.
        /// Set to null when settings should not be saved loaded.
        /// </summary>
        public string EditorPrefsPath
        {
            get;
            set;
        }

        /// <summary>
        /// Gets/sets the selected items.
        /// Modifying the returned array has no impact, since it's a copy only.
        /// </summary>
        public object[] SelectedItems
        {
            get
            {
                var result = new object[_selection.Keys.Count];
                _selection.Keys.CopyTo(result, 0);
                return result;
            }
            set
            {
                _selection = new Dictionary<object, ItemSelInfo>();
                if (value != null)
                {
                    foreach (var item in value)
                        _selection.Add(item, new ItemSelInfo(Time.realtimeSinceStartup, false));
                }
                DoSelectionChange();
                Editor.Repaint();
            }
        }

        /// <summary>
        /// Gets the number of selected items.
        /// This method is faster than using SelectedItems.Length and does not allocate memory.
        /// </summary>
        public int SelectedItemsCount
        {
            get
            {
                return _selection.Count;
            }
        }

        /// <summary>
        /// Gets/sets a text that is displayed when the listview does not contain any items.
        /// </summary>
        public string EmptyText
        {
            get
            {
                return _emptyText;
            }
            set
            {
                _emptyText = value;
                Editor.Repaint();
            }
        }

        /// <summary>
        /// Gets/sets the GUI style that is used to display the EmptyText.
        /// </summary>
        public GUIStyle EmptyTextStyle
        {
            get
            {
                if (null == _emptyTextStyle)
                {
                    _emptyTextStyle = new GUIStyle(EditorStyles.boldLabel);
                    _emptyTextStyle.alignment = TextAnchor.MiddleCenter;
                    _emptyTextStyle.wordWrap = true;
                }

                return _emptyTextStyle;
            }
            set
            {
                _emptyTextStyle = value;
            }
        }

        /// <summary>
        /// Gets or sets the background image displayed in the listview.
        /// </summary>
        public Texture2D BackgroundImage
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating how to layout the background image of the listview.
        /// </summary>
        public GUIListViewBackgroundImageLayout BackgroundImageLayout
        {
            get;
            set;
        }

        /// <summary>
        /// Gets or sets a value indicating how to tint the background image of the listview.
        /// </summary>
        public Color BackgroundImageColor
        {
            get;
            set;
        }

        public GUIListViewColumn FirstVisibleColumn
        {
            get
            {
                for (var n = 0; n < Columns.Count; ++n)
                {
                    if (Columns[n].Visible)
                        return Columns[n];
                }
                return null;
            }
        }

        public Action<GUIListView, GUIListViewColumn> ColumnClick;
        public Action<GUIListView, int> ItemClick;
        public Action<GUIListView, int> ItemDoubleClick;
        public Action<GUIListView, GUIListViewContextMenuArgs> ItemContextMenu;
        public Action<GUIListView> SelectionChange;

        public GUIListView(EditorWindow editor, GUIControl parent)
            : base(editor, parent)
        {
            LayoutOptions = new[] { GUILayout.ExpandWidth(true), GUILayout.ExpandHeight(true) };
            _columnresize = new GUIListViewResizeColumnContext(this);
            ItemSize = new Vector2(128, 22);
            ItemMargin = new Vector2(1, 0);
            Mode = GUIListViewMode.Details;
            HeaderStyle = GUIListViewHeaderStyle.Nonclickable;
            HeaderHeight = 22;
            FullRowSelect = false;
            HotTracking = false;
            MultiSelect = false;
            Columns = new List<GUIListViewColumn>();
            RightClickSelect = true;
            EditorPrefsPath = "";
            ShowColumnLines = true;
            PanningEnabled = true;
            Enabled = true;
            BackgroundImageLayout = GUIListViewBackgroundImageLayout.None;
            BackgroundImageColor = new Color(1, 1, 1, 0.1f);
        }

        public void Reset()
        {
            _scrollbarPos = new Vector2(0, 0);
            _selection.Clear();
            DoSelectionChange();
            _lastRepaintContext = new DrawContext();
        }

        /// <summary>
        /// Saves GUIListView settings to Unity EditorPrefs.
        /// You need to set GUIListView.EditorPrefsPath first.
        /// </summary>
        public bool SavePrefs()
        {
            if (string.IsNullOrEmpty(EditorPrefsPath))
                return false;

            TryInitColumnIndexes();
            foreach (var column in Columns)
            {
                var basename = EditorPrefsPath + "." + (!string.IsNullOrEmpty(column.SerializeName) ? column.SerializeName : column.Text) + ".";

                EditorPrefs.SetFloat(basename + "width", column.Width);
                EditorPrefs.SetInt(basename + "index", column.Index);
                EditorPrefs.SetBool(basename + "visible", column.Visible);
                EditorPrefs.SetInt(basename + "sortmode", (int)column.SortMode);
                EditorPrefs.SetInt(basename + "sortprio", (int)column.SortPrio>>32); // >>32 because it's DateTime.Now.Ticks which is 64bit, but we dont care about the value itself. the only information we need is that the newestly added sort columns have a bigger value. so we can dismiss the lower 32bit to make it fit into an int again
            }

            OnSavePrefs();
            return true;
        }

        protected virtual void OnSavePrefs()
        {
        }

        /// <summary>
        /// Loads GUIListView settings from Unity EditorPrefs.
        /// You need to set GUIListView.EditorPrefsPath first.
        /// </summary>
        public bool LoadPrefs()
        {
            if (string.IsNullOrEmpty(EditorPrefsPath))
                return false;

            TryInitColumnIndexes();
            foreach (var column in Columns)
            {
                var basename = EditorPrefsPath + "." + (!string.IsNullOrEmpty(column.SerializeName) ? column.SerializeName : column.Text) + ".";

                column.Width = EditorPrefs.GetFloat(basename + "width", column.Width);
                column.Index = EditorPrefs.GetInt(basename + "index", column.Index);
                column.Visible = EditorPrefs.GetBool(basename + "visible", column.Visible);
                column.SortMode = (GUIListViewSortMode)EditorPrefs.GetInt(basename + "sortmode", (int)GUIListViewSortMode.None);
                column.SortPrio = EditorPrefs.GetInt(basename + "sortprio", -1);
            }

            Columns.Sort(delegate(GUIListViewColumn a, GUIListViewColumn b)
            {
                return a.Index - b.Index;
            });

            OnLoadPrefs();
            return true;
        }

        protected virtual void OnLoadPrefs()
        {
        }

        /// <summary>
        /// When the listview didn't ran its OnGUI yet, the column indexes
        /// are not initialized. Since we need inited column indexes for the
        /// SavePrefs/LoadPrefs methods to work, we make sure to initialize them.
        /// </summary>
        void TryInitColumnIndexes()
        {
            var allzero = true;
            foreach (var column in Columns)
            {
                if (column.Index != 0)
                {
                    allzero = false;
                    break;
                }
            }

            if (allzero)
            {
                for (var n = 0; n < Columns.Count; ++n)
                    Columns[n].Index = n;
            }
        }

        /// <summary>
        /// Gets whether the specified model is selected.
        /// </summary>
        public bool IsSelected(object model)
        {
            if (null == model)
                return false;

            ItemSelInfo selectiontime;
            if (_selection.TryGetValue(model, out selectiontime))
                return true;
            return false;
        }

        object GetLastSelectedItem()
        {
            float selectiontime = -1;
            object selection = null;
            foreach (var pair in _selection)
            {
                if (pair.Value.Time > selectiontime && pair.Value.Clicked)
                {
                    selection = pair.Key;
                    selectiontime = pair.Value.Time;
                }
            }
            return selection;
        }

        List<object> _selectedItemsPerFrame = new List<object>(128);
        float _lastKeyPressTime;
        string _findWord = "";

        protected override void DoGUI()
        {
            if (HotTracking && !Editor.wantsMouseMove)
                throw new GUIListViewException("In order to use GUIListView.HotTracking you must set EditorWindow.wantsMouseMove to true.");

            // cache expensive lookups
            _focusedWindow = EditorWindow.focusedWindow;

            var isenabled = Enabled;
            if (!isenabled)
                EditorGUI.BeginDisabledGroup(true);
            _drawid++;

            var context = new DrawContext();
            var eatevent = false;

            // get a snapshot of all currently selected items
            _selectedItemsPerFrame.Clear();
            foreach (var i in _selection)
                _selectedItemsPerFrame.Add(i.Key);

            // without a control id focusing doesn't work correctly
            // and sometimes GUI.GetFocusedControlName() does not return the name we just set
            context.ControlId = GUIUtility.GetControlID(FocusType.Keyboard);
            GUI.SetNextControlName(ControlName);

            if (Event.current.Equals(Event.KeyboardEvent("tab")) && GUI.GetNameOfFocusedControl() != ControlName)
            {
                Event.current.Use();

                _activeListView = this;
                if (_selection.Count == 0 && OnGetItemCount() > 0)
                {
                    SelectItem(OnGetItem(0), true);
                    DoSelectionChange();
                }
            }

            float maxrowwidth = 0;
            int visiblecolumnindex = 0;
            for (var n = 0; n < Columns.Count; ++n)
            {
                Columns[n].Index = n;
                Columns[n].RealWidth = Columns[n].Width;
                Columns[n].DisplayIndex = -1;

                if (Columns[n].Visible)
                {
                    Columns[n].DisplayIndex = visiblecolumnindex++;
                    maxrowwidth += Columns[n].RealWidth + ItemMargin.x;
                }
            }
            maxrowwidth += GUI.skin.verticalScrollbar.CalcSize(TempContent("Wg", null, null)).x;

            var headerheight = 0.0f;
            if (Mode == GUIListViewMode.Details && HeaderStyle != GUIListViewHeaderStyle.None)
                headerheight = HeaderHeight;

            context.HeaderHeight = headerheight;
            context.TotalItemCount = OnGetItemCount();
            context.ClientRect = GUILayoutUtility.GetRect(1, 1, LayoutOptions);

            context.VScrollRect = context.ClientRect;
            context.VScrollRect.width = GUI.skin.verticalScrollbar.CalcSize(TempContent("Wg", null, null)).x;
            context.VScrollRect.x = context.ClientRect.xMax - context.VScrollRect.width;

            context.ListRect = context.ClientRect;
            //context.ListRect.height -= headerheight;
            context.ListRect.width -= context.VScrollRect.width;
            
            if (maxrowwidth > context.ListRect.width)
            {
                context.HScrollRect = context.ClientRect;
                context.HScrollRect.height = GUI.skin.horizontalScrollbar.CalcSize(TempContent("Wg", null, null)).y;
                context.HScrollRect.y = context.ClientRect.yMax - context.HScrollRect.height - 1;
                context.HScrollRect.width -= context.VScrollRect.width;
                context.ScrollBounds.x = maxrowwidth;

                var hscrollvalue = GUI.HorizontalScrollbar(context.HScrollRect, _scrollbarPos.x, context.ListRect.width, 0, maxrowwidth);
                _scrollbarPos.x = hscrollvalue;
                context.HScrollOffset = -hscrollvalue;

                context.ListRect.height -= context.HScrollRect.height;
                context.VScrollRect.height -= context.HScrollRect.height;
            }
            
            context.ColumnCount = 1;
            switch (Mode)
            {
                case GUIListViewMode.List:
                case GUIListViewMode.Details:
                    context.ColumnCount = 1;
                    break;
                case GUIListViewMode.Tile:
                    context.ColumnCount = (int)Mathf.Max(1, context.ListRect.width / (ItemSize.x + ItemMargin.x));
                    break;
            }

            context.TotalRowCount = Mathf.Max(0, context.TotalItemCount / context.ColumnCount);
            context.RowCount = (int)Mathf.Ceil((context.ListRect.height + ItemSize.y + ItemMargin.y) / (ItemSize.y + ItemMargin.y));
            context.RowCount = Math.Min(context.RowCount, context.TotalRowCount);
            context.VisibleRowCount = (int)(Mathf.Ceil(context.ListRect.height - headerheight + 2) / (ItemSize.y + ItemMargin.y));
            context.VisibleRowCount = Math.Min(context.VisibleRowCount, context.TotalRowCount);

            context.TopRow = (int)(_scrollbarPos.y);
            context.TopVisibleRow = context.TopRow;
            context.BottomRow = context.TopRow + context.RowCount - 1;
            context.BottomVisibleRow = context.TopVisibleRow + context.VisibleRowCount - 1;
            context.VScrollOffset = (context.TopRow - _scrollbarPos.y) * (ItemSize.y + ItemMargin.y);

            context.FirstItem = context.TopRow * context.ColumnCount;
            context.LastItem = Mathf.Min(context.TotalItemCount - 1, context.BottomRow * context.ColumnCount + context.ColumnCount);
            context.FirstVisibleItem = context.TopVisibleRow * context.ColumnCount;
            context.LastVisibleItem = Mathf.Min(context.TotalItemCount - 1, context.BottomVisibleRow * context.ColumnCount + context.ColumnCount);
            context.VisibleItemCount = context.LastVisibleItem - context.FirstVisibleItem;
            if (context.VisibleItemCount >= 0)
                context.VisibleItemCount++;

            var showvscrollbar = context.TotalRowCount > context.VisibleRowCount;
            context.ScrollBounds.y = (showvscrollbar ? context.TotalRowCount : 0) - (showvscrollbar ? context.VisibleRowCount : 0);
            var vscrollvalue = GUI.VerticalScrollbar(context.VScrollRect, _scrollbarPos.y, showvscrollbar ? context.VisibleRowCount : 0, 0, showvscrollbar ? context.TotalRowCount : 0);
            if (_scrollbarPos.y != vscrollvalue)
            {
                SetVScrollbarPos(context, vscrollvalue);
                Editor.Repaint();
            }

            // use the context until the next repaint, because
            // only during the repaint the actual layout sizes are correct
            if (Event.current.type != EventType.repaint && (context.TotalItemCount == _lastRepaintContext.TotalItemCount))
                context = _lastRepaintContext;

            // cache if the mouse is inside the list. if it is not, we dismiss various checks
            context.IsMouseInside = Event.current.mousePosition.y >= context.ClientRect.yMin && Event.current.mousePosition.x >= context.ClientRect.xMin && Event.current.mousePosition.y <= context.ClientRect.yMax && Event.current.mousePosition.x <= context.ClientRect.xMax;

            // we need to set the keyboard control to our list in order that
            // other controls in the window that have the focus leave their
            // focus state once we click in this list.
            if (context.IsMouseInside && Event.current.type == EventType.mouseDown)
            {
                _activeListView = this;
                GUI.FocusControl(ControlName);
                GUIUtility.keyboardControl = context.ControlId;
                eatevent = true;
            }

            if (PanningEnabled)
                DoPanning(context);

            //GUI.BeginGroup(context.ListRect);

            //if (null != CustomBackgroundImage)
            //{
            //    var oldcolor = GUI.color;
            //    GUI.color = new Color(1, 1, 1, 0.2f);
            //    GUI.DrawTexture(context.ListRect, CustomBackgroundImage);
            //    GUI.color = oldcolor;
            //}

            switch (Mode)
            {
                case GUIListViewMode.Details:
                    DoDetailsView(ref context);
                    break;
                case GUIListViewMode.List:
                case GUIListViewMode.Tile:
                    DoListTileView(ref context);
                    break;
            }

            // Display the empty text if the list is empty
            if (context.TotalItemCount == 0 && !string.IsNullOrEmpty(EmptyText))
            {
                var r = context.ListRect;
                r.x += 10; r.width -= 20;
                r.y += 10; r.height -= 20;
                GUI.Label(r, EmptyText, EmptyTextStyle);
            }

            //GUI.EndGroup();

            if (Event.current.type == EventType.repaint)
            {
                //_newvisibiles.Clear();
                foreach (var pair in _visibleItems)
                {
                    var model = pair.Key;
                    var drawid = pair.Value;
                    if (drawid != _drawid)
                        OnItemHide(model);
                    else
                        _newvisibiles.Add(model, _drawid);
                }
                var swapit = _visibleItems;
                _visibleItems = _newvisibiles;
                _newvisibiles = swapit;
                _newvisibiles.Clear();
            }

            if (HotTracking && Event.current.type == EventType.mouseMove)
                Editor.Repaint();

            if (Event.current.type == EventType.repaint)
                _lastRepaintContext = context;

            if (eatevent)
                Event.current.Use();

            if (_animateScroll && Mathf.Abs(_animateScrollPos.y - _scrollbarPos.y) > 0.01f)
            {
                _scrollbarPos.y += (_animateScrollPos.y - _scrollbarPos.y) * 0.1f;
                if (Mathf.Abs(_animateScrollPos.y - _scrollbarPos.y) < 0.01f)
                    _animateScroll = false;

                Editor.Repaint();
            }

            if (!isenabled)
                EditorGUI.EndDisabledGroup();

#if DEBUG && false
            {
                var r = context.ListRect;
                r.x += r.width;
                r.width = 400;
                r.x -= r.width + 4;
                r.height = 300;
                r.y += context.HeaderHeight+4;
                Editor.BeginWindows();
                GUI.Window(context.ControlId + 1, r, DoDebugWindow, TempContent("Debug", null, null));
                Editor.EndWindows();
            }
#endif
        }

        bool _animateScroll;

#if DEBUG
        void DoDebugWindow(int id)
        {
            GUILayout.BeginVertical();
            GUILayout.Label(string.Format("IsMouseInside: {0}", _lastRepaintContext.IsMouseInside));
            GUILayout.Label(string.Format("TopRow: {0}, BottomRow: {1}", _lastRepaintContext.TopRow, _lastRepaintContext.BottomRow));
            GUILayout.Label(string.Format("TopVisRow: {0}, BottomVisRow: {1}", _lastRepaintContext.TopVisibleRow, _lastRepaintContext.BottomVisibleRow));
            GUILayout.Label(string.Format("RowCount: {0}, VisRowCount: {1}", _lastRepaintContext.RowCount, _lastRepaintContext.VisibleRowCount));
            GUILayout.Label(string.Format("VisItemCount: {0}", _lastRepaintContext.VisibleItemCount));
            GUILayout.Label(string.Format("FirstItem: {0}, LastItem: {1}", _lastRepaintContext.FirstItem, _lastRepaintContext.LastItem));
            GUILayout.Label(string.Format("FirstVisItem: {0}, LastVisItem: {1}", _lastRepaintContext.FirstVisibleItem, _lastRepaintContext.LastVisibleItem));
            GUILayout.Label(string.Format("HeaderHeight: {0}", _lastRepaintContext.HeaderHeight));
            GUILayout.Label(string.Format("HScrollRect: {0}", _lastRepaintContext.HScrollRect));
            GUILayout.Label(string.Format("VScrollRect: {0}", _lastRepaintContext.VScrollRect));
            GUILayout.Label(string.Format("TotalRows: {0}, TotalItems: {1}", _lastRepaintContext.TotalRowCount, _lastRepaintContext.TotalItemCount));
            GUILayout.Label(string.Format("IsPanning: {0}", _ispanning));
            GUILayout.EndVertical();
        }
#endif

        static GUIContent _tempcontent;
        static GUIContent TempContent(string text, Texture image, string tooltip)
        {
            if (null == _tempcontent) _tempcontent = new GUIContent();
            _tempcontent.text = text;
            _tempcontent.tooltip = tooltip;
            _tempcontent.image = image;
            return _tempcontent;
        }

        void DoBackgroundImage(DrawContext context)
        {
            if (null == BackgroundImage || Event.current.type != EventType.repaint)
                return;

            var rect = context.ListRect;
            rect.y -= context.HeaderHeight;

            var oldcolor = GUI.color;
            GUI.color = BackgroundImageColor;

            switch (BackgroundImageLayout)
            {
                case GUIListViewBackgroundImageLayout.TopLeft:
                    GUI.DrawTexture(new Rect(0, 0, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                    break;

                case GUIListViewBackgroundImageLayout.TopRight:
                    GUI.DrawTexture(new Rect(rect.width - BackgroundImage.width, 0, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                    break;

                case GUIListViewBackgroundImageLayout.BottomLeft:
                    GUI.DrawTexture(new Rect(0, rect.height - BackgroundImage.height, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                    break;

                case GUIListViewBackgroundImageLayout.BottomRight:
                    GUI.DrawTexture(new Rect(rect.width - BackgroundImage.width, rect.height - BackgroundImage.height, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                    break;

                case GUIListViewBackgroundImageLayout.Center:
                    GUI.DrawTexture(new Rect(rect.width*0.5f - BackgroundImage.width * 0.5f, rect.height*0.5f - BackgroundImage.height * 0.5f, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                    break;

                case GUIListViewBackgroundImageLayout.Strech:
                    GUI.DrawTexture(new Rect(0,0,rect.width,rect.height), BackgroundImage, ScaleMode.StretchToFill);
                    break;

                case GUIListViewBackgroundImageLayout.Tile:
                    {
                        for (var y = 0.0f; y < rect.height; y += BackgroundImage.height)
                        {
                            for (var x = 0.0f; x < rect.width; x += BackgroundImage.width)
                                GUI.DrawTexture(new Rect(x, y, BackgroundImage.width, BackgroundImage.height), BackgroundImage);
                        }
                    }
                    break;
            }

            GUI.color = oldcolor;
        }

        bool _ispanning;
        void DoPanning(DrawContext context)
        {
            if (!HasFocus)
                return;

            var ispanningbutton = Event.current.button == 2;

            // Do we switch into panning mode?
            if (!_ispanning && context.IsMouseInside && Event.current.type == EventType.mouseDown && ispanningbutton)
            {
                _animateScroll = false;
                _ispanning = true;
                EditorGUIUtility.SetWantsMouseJumping(1);
                EditorGUIUtility.AddCursorRect(context.ListRect, MouseCursor.Pan);
                Event.current.Use();
            }

            // use rawType because we want to get the mouseUp even when the mouse is outside the editor window
            if (_ispanning && Event.current.rawType == EventType.mouseUp && ispanningbutton)
            {
                _ispanning = false;
                EditorGUIUtility.SetWantsMouseJumping(0);
                Event.current.Use();
            }

            // if we're panning, switch the cursor
            if (_ispanning)
            {
                EditorGUIUtility.AddCursorRect(context.ListRect, MouseCursor.Pan);

                // if we drag the mouse, scroll the view
                if (Event.current.type == EventType.mouseDrag && ispanningbutton)
                {
                    _scrollbarPos.x -= Event.current.delta.x;
                    _scrollbarPos.y -= Event.current.delta.y * (1.0f / ItemSize.y);
                    _scrollbarPos.x = Mathf.Clamp(_scrollbarPos.x, 0, context.ScrollBounds.x);
                    _scrollbarPos.y = Mathf.Clamp(_scrollbarPos.y, 0, context.ScrollBounds.y);

                    Event.current.Use();
                }
            }
        }

        void DoSelectionChange()
        {
            OnSelectionChange();

            if (null != SelectionChange)
                SelectionChange.Invoke(this);
        }

        protected virtual void OnSelectionChange()
        {
        }

        void DoListTileView(ref DrawContext context)
        {
            GUI.BeginGroup(new Rect(context.ListRect.x, context.ListRect.y, context.ListRect.width, context.ListRect.height));

            DoBackgroundImage(context);

            var y = 0;
            var autospacex = ((context.ListRect.width - (ItemSize.x + ItemMargin.x) * context.ColumnCount) / context.ColumnCount);
            for (var index = context.FirstItem; index <= context.LastItem; )
            {
                var oldindex = index;
                for (var column = 0; column < context.ColumnCount && index <= context.LastItem && context.VisibleItemCount > 0; ++column, ++index)
                {
                    var model = OnGetItem(index);
                    var selected = IsSelected(model);
                    context.Column = null;
                    context.RowRect = new Rect(context.HScrollOffset, ItemMargin.y + context.VScrollOffset + y * (ItemSize.y + ItemMargin.y), context.ListRect.width + Mathf.Abs(context.HScrollOffset), ItemSize.y);
                    context.ItemRect = new Rect(
                        context.HScrollOffset + ItemMargin.x + column * (ItemSize.x + ItemMargin.x) + autospacex * column,
                        context.RowRect.y,
                        ItemSize.x,
                        context.RowRect.height);

                    context.Selected = selected;
                    context.HotTracking = false;
                    context.ItemIndex = index;
                    context.Item = model;

                    if (HotTracking)
                        context.HotTracking = FullRowSelect ? context.RowRect.Contains(Event.current.mousePosition) : context.ItemRect.Contains(Event.current.mousePosition);

                    DoItemBackground(context);
                    DoItem(context);
                }

                // if we're in fullrow selection mode, patch the itemrect
                // to be of the row rect and check for item input after all
                // the individual column items had a change to check for it
                if (FullRowSelect)
                {
                    context.ItemRect = context.RowRect;
                    DoHandleInput(context);
                }

                if (index == oldindex)
                    break; // no item drawn

                ++y;
            }

            DoHandleInput(context);
            DoPostHandleInput(context);
            GUI.EndGroup();
        }

        static public bool DebugColumnHeader
        {
            get;
            set;
        }
        GUIStyle _columnHeaderTextStyle;
        GUIListViewColumn _columnLMBDown;

        void DoColumnHeader(DrawContext context)
        {
            if (null == _columnHeaderTextStyle)
                _columnHeaderTextStyle = new GUIStyle(EditorStyles.label);

            if (HeaderStyle == GUIListViewHeaderStyle.None)
                return;

            var lmbup = Event.current.type == EventType.mouseUp && Event.current.button == 0;

            GUI.BeginGroup(new Rect(context.ListRect.x, context.ListRect.y, context.ListRect.width, context.HeaderHeight));

            float x = context.HScrollOffset;
            var headerrect = new Rect(x, 0, context.ListRect.width + Mathf.Abs(context.HScrollOffset), context.HeaderHeight);
            EditorGUI.HelpBox(new Rect(headerrect.x,headerrect.y-1,headerrect.width,headerrect.height+1), string.Empty, MessageType.None);

            if (null != FlexibleColumn)
            {
                float width = 0;
                for (var n = 0; n < Columns.Count; ++n)
                {
                    var column = Columns[n];
                    if (!column.Visible)
                        continue;

                    if (FlexibleColumn != column)
                        width += column.Width;
                }

                FlexibleColumn.RealWidth = Mathf.Max(FlexibleColumn.Width, context.ListRect.width - width - Columns.Count);
            }

            for (var n = 0; n < Columns.Count; ++n)
            {
                var column = Columns[n];
                if (!column.Visible)
                {
                    column.ColumnRect = new Rect();
                    continue;
                }

                // configure the style
                _columnHeaderTextStyle.alignment = column.TextAlignment;

                // draw column text
                var columnRect = new Rect(x, headerrect.y, column.RealWidth, context.HeaderHeight);
                if (Event.current.type == EventType.repaint)
                    column.ColumnRect = new Rect(columnRect.x, columnRect.y, columnRect.width, context.ListRect.height);

                if (_columnLMBDown == column && columnRect.Contains(Event.current.mousePosition))
                {
                    var selrect = columnRect;
                    selrect.x -= 2;
                    selrect.width += 2;
                    EditorGUI.HelpBox(new Rect(selrect.x,selrect.y-1,selrect.width,selrect.height+1), string.Empty, MessageType.None);
                }

                var textrect = columnRect;
                textrect.width -= 3;
                if (DebugColumnHeader)
                    GUI.Label(textrect, textrect.width.ToString(), _columnHeaderTextStyle);
                else
                {
                    var oldsize = EditorGUIUtility.GetIconSize();
                    EditorGUIUtility.SetIconSize(new Vector2(16, 16));

                    GUI.Label(textrect, TempContent(column.Text, column.Image, column.Tooltip), _columnHeaderTextStyle);

                    EditorGUIUtility.SetIconSize(oldsize);
                }

                // draw sort icons
                GUI.BeginGroup(column.ColumnRect);
                if (Event.current.type == EventType.repaint)
                {
                var iconcount = GetSortIconCount(column);
                var sortrect = new Rect(0, 0, column.ColumnRect.width, column.ColumnRect.height);
                sortrect.y += 2;
                sortrect.height = GUIListViewColumn.SortIcon.height;
                sortrect.x += sortrect.width / 2;
                sortrect.x -= iconcount * GUIListViewColumn.SortIcon.width / 2;
                sortrect.width = GUIListViewColumn.SortIcon.width;
                for (var nn = 0; nn < iconcount; ++nn)
                {
                    switch (column.SortMode)
                    {
                        case GUIListViewSortMode.Ascending:
                            GUI.DrawTextureWithTexCoords(sortrect, GUIListViewColumn.SortIcon, new Rect(0, 0, 1, 1));
                            break;
                        case GUIListViewSortMode.Descending:
                            GUI.DrawTextureWithTexCoords(sortrect, GUIListViewColumn.SortIcon, new Rect(0, 1, 1, -1));
                            break;
                    }
                    sortrect.x += sortrect.width;
                }
                }
                GUI.EndGroup();

                // draw column seperator
                if (Event.current.type == EventType.repaint)
                {
                var linerect = headerrect;
                linerect.x = columnRect.x + columnRect.width - ItemMargin.x;
                linerect.width = 1;
                var oldcolor = GUI.color;
                GUI.color = new Color(0, 0, 0, 0.1f);
                GUI.DrawTexture(linerect, EditorGUIUtility.whiteTexture);
                GUI.color = oldcolor;
                }
                x += column.RealWidth + ItemMargin.x;

                if (HeaderStyle != GUIListViewHeaderStyle.None && HeaderStyle != GUIListViewHeaderStyle.Nonclickable)
                {
                    var clickrect = headerrect; clickrect.height -= 1; clickrect.x = textrect.x; clickrect.width = textrect.width;
                    if (_columnLMBDown == column && clickrect.Contains(Event.current.mousePosition) && Event.current.type == EventType.mouseUp && Event.current.button == 0 && Event.current.clickCount == 1)
                    {
                        DoColumnClick(column);
                        _columnLMBDown = null;
                        Event.current.Use();
                        //GUIUtility.ExitGUI();
                    }

                    if (clickrect.Contains(Event.current.mousePosition) && Event.current.type == EventType.mouseDown && Event.current.button == 0 && Event.current.clickCount == 1)
                    {
                        _columnLMBDown = column;
                        Event.current.Use();
                    }
                }

                if (FlexibleColumn != column && column.IsResizable && !_columnresize.IsResizing)
                {
                    var resizerect = columnRect;
                    resizerect.y += 1;
                    resizerect.height -= 2;
                    resizerect.x += resizerect.width - 4;
                    resizerect.width = 8;
                    EditorGUIUtility.AddCursorRect(resizerect, MouseCursor.ResizeHorizontal);

                    if (resizerect.Contains(Event.current.mousePosition) && Event.current.type == EventType.mouseDown && Event.current.button == 0 && Event.current.clickCount == 1)
                    {
                        _columnresize.Begin(column);
                        Event.current.Use();
                    }
                }
            }

            if (_columnresize.IsResizing)
            {
                // if we have a column to resize, draw the resize icon no matter where inside the list the mouse is positioned
                EditorGUIUtility.AddCursorRect(new Rect(0,0,context.ListRect.width, context.ListRect.height), MouseCursor.ResizeHorizontal);

                // computing sizes only correctly works in the repaint event type
                if (Event.current.type == EventType.repaint)
                    _columnresize.Update();

                // force a repaint as long as we have a resize column. this is
                // required because we need to recalc the column width which is done during repaint only
                Editor.Repaint();

                // cancel resizing when ESC has peen pressed
                if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.Escape)
                {
                    _columnresize.Cancel();
                    Event.current.Use();
                }

                // use rawType because we also want to get the mouseUp when it occurs outside our own editor window
                if (Event.current.rawType == EventType.mouseUp && Event.current.button == 0)
                {
                    _columnresize.End();
                    Event.current.Use();
                }
            }

            // check for right-click on header and then display popup menu
            // to select which columns to display
            if (HeaderStyle == GUIListViewHeaderStyle.ClickablePopup && headerrect.Contains(Event.current.mousePosition) && Event.current.type == EventType.mouseDown && Event.current.button == 1 && Event.current.clickCount == 1)
            {
                GUIUtility.hotControl = 0;
                var menu = new GenericMenu();
                for(var n=0; n<Columns.Count; ++n)
                {
                    var column = Columns[n];
                    //if (n == 0)
                    //    menu.AddItem(new GUIContent(column.Text.Replace("/","\\"), column.Tooltip), column.Visible, null, column);
                    //else
                    var text = string.IsNullOrEmpty(column.PopupText) ? column.Text : column.PopupText;
                    menu.AddItem(new GUIContent(text.Replace("/", "\\"), column.Tooltip), column.Visible, OnColumnPopupMenu, column);
                }

                menu.AddItem(new GUIContent(string.Empty), false, null);
                menu.AddItem(new GUIContent("Organize Columns"), false, OnOrganizeColumnPopupMenu);

                menu.ShowAsContext();

                Event.current.Use();
                //GUIUtility.ExitGUI();
            }

            GUI.EndGroup();

            if (!context.IsMouseInside || lmbup)
                _columnLMBDown = null;
        }

        void OnColumnPopupMenu(object userData)
        {
            var column = (GUIListViewColumn)userData;
            column.Visible = !column.Visible;
            Editor.Repaint();
        }

        void OnOrganizeColumnPopupMenu()
        {
            var window = EditorWindow.GetWindow<GUIListViewOrganizeColumnWindow>(true, "Organize Columns", true);
            if (null == window)
                return;

            window.SetListView(this);
            window.ShowUtility();
        }

        void DoDetailsView(ref DrawContext context)
        {
            float y = 0;

            DoColumnHeader(context);

            GUI.BeginGroup(new Rect(
                context.ListRect.x,
                context.ListRect.y + context.HeaderHeight, 
                context.ListRect.width,
                context.ListRect.height - 1 - context.HeaderHeight));

            DoBackgroundImage(context);

            for (var index = context.FirstItem; index <= context.LastItem && context.VisibleItemCount > 0; ++index)
            {
                context.RowRect = new Rect(context.HScrollOffset, ItemMargin.y + context.VScrollOffset + y * (ItemSize.y + ItemMargin.y), context.ListRect.width + Mathf.Abs(context.HScrollOffset), ItemSize.y);
                context.ItemRect = context.RowRect;
                context.Item = OnGetItem(index);
                context.Selected = IsSelected(context.Item);
                context.ItemIndex = index;

                var x = ItemMargin.x;
                for (var n = 0; n < Columns.Count; ++n)
                {
                    var column = Columns[n];


                    context.Column = column;
                    context.ItemRect = new Rect(context.HScrollOffset + x, context.ItemRect.y, column.RealWidth, context.ItemRect.height);
                    context.HotTracking = false;

                    if (HotTracking)
                    {
                        if (FullRowSelect)
                            context.HotTracking = context.RowRect.Contains(Event.current.mousePosition);

                        if (!FullRowSelect && n == 0)
                            context.HotTracking = context.ItemRect.Contains(Event.current.mousePosition);
                    }

                    var backgrounddrawn = false;
                    if (FullRowSelect && column.IsPrimaryColumn)
                    {
                        DoItemBackground(context);
                        backgrounddrawn = true;
                    }

                    if (!column.Visible)
                        continue;

                    var iscolumninview = context.ItemRect.xMax >= 0 && context.ItemRect.xMin <= context.ListRect.width;
                    if (iscolumninview) // draw first column always because of the fullrowselect
                    {
                        if (!backgrounddrawn)
                            DoItemBackground(context);

                        DoItem(context);
                    }

                    x += ItemMargin.x + column.RealWidth;// +ItemMargin.x;
                }

                // if we're in fullrow selection mode, patch the itemrect
                // to be of the row rect and check for item input after all
                // the individual column items had a change to check for it
                if (FullRowSelect)
                {
                    context.ItemRect = context.RowRect;
                    DoHandleInput(context);
                }

                //if (System.Object.ReferenceEquals(context.Item, _activeItem))
                //{
                //    var oldcolor = GUI.color;
                //    GUI.color = GUIColors.ActiveSelection * 0.75f;

                //    var topline = context.RowRect; topline.height = 1;
                //    GUI.DrawTexture(topline, EditorGUIUtility.whiteTexture);
                //    var bottomline = context.RowRect; bottomline.y += bottomline.height - 1; bottomline.height = 1;
                //    GUI.DrawTexture(bottomline, EditorGUIUtility.whiteTexture);
                //    var leftline = context.RowRect; leftline.x += 1; leftline.width = 1;
                //    GUI.DrawTexture(leftline, EditorGUIUtility.whiteTexture);
                //    var rightline = context.RowRect; rightline.x += rightline.width - 1; rightline.width = 1;
                //    GUI.DrawTexture(rightline, EditorGUIUtility.whiteTexture);

                //    GUI.color = oldcolor;
                //}

                ++y;
            }

            // draw vertical lines
            if (ShowColumnLines && context.TotalItemCount > 0 && Event.current.type == EventType.repaint)
            {
                var oldcolor = GUI.color;
                GUI.color = new Color(0, 0, 0, 0.1f);
                var x = ItemMargin.x;

                for (var n = 0; n < Columns.Count; ++n)
                {
                    var column = Columns[n];
                    if (!column.Visible)
                        continue;

                    var itemrect = new Rect(context.HScrollOffset + x, context.VScrollOffset + y * (ItemSize.y + ItemMargin.y), column.RealWidth, ItemSize.y);
                    var iscolumninview = itemrect.xMax >= 0 && itemrect.xMin <= context.ListRect.width;
                    if (iscolumninview)
                    {
                        var linerect = itemrect;
                        linerect.x += linerect.width - 1 - ItemMargin.x;
                        linerect.width = 1;
                        linerect.y = 0;
                        linerect.height = context.ListRect.height;

                        GUI.DrawTexture(linerect, EditorGUIUtility.whiteTexture);
                    }

                    x += ItemMargin.x + column.RealWidth;
                }
                GUI.color = oldcolor;
            }

            GUI.EndGroup();

            DoHandleInput(context);
            DoPostHandleInput(context);
        }

        static GUIListView _activeListView;
        static EditorWindow _focusedWindow; // calling EditorWindow.focusedWindow is slow, so we cache this info

        bool HasFocus
        {
            get
            {
                if (_focusedWindow != Editor)
                    return false;

                if (_activeListView != this)
                    return false;

                return true;
            }
        }

        void DoItemBackground(DrawContext context)
        {
            if (Event.current.type != EventType.layout && Event.current.type != EventType.repaint)
                return;

            var oldcolor = GUI.color;
            //if (context.Selected || context.HotTracking)
            {
                var args = new GUIListViewDrawItemBackgroundArgs();
                args.Model = context.Item;
                args.ModelIndex = context.ItemIndex;
                args.Column = context.Column;
                args.Selected = context.Selected;
                args.Texture = EditorGUIUtility.whiteTexture;
                args.SelectedItems = _selectedItemsPerFrame;
                args.Rect = context.ItemRect;
                args.Rect.x -= ItemMargin.x+1;

                if (context.Selected)
                {
                    if (HasFocus)
                        args.Color = GUIColors.ActiveSelection;
                    else
                        args.Color = GUIColors.InactiveSelection;
                }
                else
                {
                    args.Color = Color.clear;// new Color(1, 1, 1, 0.0f);
                    if (context.Column != null)
                        args.Color = context.Column.Color;
                }

                if (FullRowSelect && (context.Column == null || (context.Column != null && context.Column.DisplayIndex == 0)))
                    args.Rect = context.RowRect;

                if (!FullRowSelect && (context.Column == null || (context.Column != null && context.Column.DisplayIndex == 0)))
                    args.Rect = context.ItemRect;

                OnDrawItemBackground(ref args);
                if (!args.Handled && Event.current.type == EventType.repaint && args.Color.a > 0)
                {
                    GUI.color = args.Color;
                    GUI.DrawTexture(args.Rect, args.Texture);
                }
            }

            GUI.color = oldcolor;
        }

        protected virtual void OnDrawItemBackground(ref GUIListViewDrawItemBackgroundArgs args)
        {
        }

        //protected virtual void OnDrawItemBackground(ref GUIListViewDrawItemBackgroundArgs args)
        //{
        //    if ((args.ModelIndex & 1) != 0)
        //    {
        //        if (Event.current.type == EventType.repaint)
        //        {
        //            if (EditorGUIUtility.isProSkin)
        //                GUI.color = new Color(0, 0, 0, 0.05f);
        //            else
        //                GUI.color = new Color(1, 1, 1, 0.05f);

        //            GUI.DrawTexture(args.Rect, EditorGUIUtility.whiteTexture, ScaleMode.ScaleAndCrop, true);
        //        }
        //    }
        //}

        void DoItem(DrawContext context)
        {
            // mark this one as visible
            if (Event.current.type == EventType.repaint)
                _visibleItems[context.Item] = _drawid;

            // draw item text
            {
                var oldcolor = GUI.contentColor;
                GUI.contentColor = Color.white;

                // Because the first click will never allow any item control
                // to do anything (we catch the first click), we force the
                // cursor to the default arrow when it's not selected.
                if (!context.Selected)
                    EditorGUIUtility.AddCursorRect(context.ItemRect, MouseCursor.Arrow);

                // Handle input before actually drawing the item,
                // because the user OnDrawItem implementation could handle
                // our default input like selecting an item
                if (!_columnresize.IsResizing)
                    DoHandleItemInput(context);


                var args = new GUIListViewDrawItemArgs();
                args.Model = context.Item;
                args.ModelIndex = context.ItemIndex;
                args.ItemRect = context.ItemRect;
                args.Column = context.Column;
                args.Selected = context.Selected;

                // add a bit a space to the left of the first column,
                // that makes the list look a bit nicer.
                if (context.Column == null || context.Column.DisplayIndex == 0)
                {
                    args.ItemRect.x += 2;
                    args.ItemRect.width -= 2;
                }

                //GUIListViewGetItemImageResult imageresult;
                //if (DoGetItemImage(args, out imageresult))
                //    args.ItemRect = imageresult.RemainingItemRect;

                OnDrawItem(args);

                GUI.contentColor = oldcolor;
            }

#if false
            // horizontal grid lines
            {
                var linerect = context.ItemRect;
                linerect.y += linerect.height - 1;
                linerect.height = 1;
                var oldcolor = GUI.color;
                GUI.color = new Color(0, 0, 0, 0.1f);
                GUI.DrawTexture(linerect, EditorGUIUtility.whiteTexture);
                GUI.color = oldcolor;
            }
#endif
        }

        protected static Rect DrawItemImageHelper(ref Rect itemrect, Texture image, Vector2 imagesize)
        {
            if (null == image)
                return new Rect();

            var imagerect = itemrect;
            imagerect.width = imagesize.x;
            imagerect.height = imagesize.y;
            imagerect.y += (itemrect.height - imagerect.height) * 0.5f; // vertically move the image into the center
            if (Event.current.type == EventType.repaint)
                GUI.DrawTexture(imagerect, image, ScaleMode.ScaleAndCrop, true);
            itemrect.x += imagerect.width + 1;
            itemrect.width -= imagerect.width + 1;

            return imagerect;
        }

        protected static Rect DrawItemImageHelper(ref Rect itemrect, GUIContent content, Vector2 imagesize)
        {
            var imagerect = itemrect;
            imagerect.width = imagesize.x;
            imagerect.height = imagesize.y;
            imagerect.y += (itemrect.height - imagerect.height) * 0.5f; // vertically move the image into the center
            GUI.Label(imagerect, content, GUIStyles.Clear);
            itemrect.x += imagerect.width + 1;
            itemrect.width -= imagerect.width + 1;

            return imagerect;
        }

        //bool DoGetItemImage(GUIListViewDrawItemArgs drawargs, out GUIListViewGetItemImageResult imageresult)
        //{
        //    GUIListViewGetItemImageArgs imageargs = new GUIListViewGetItemImageArgs();
        //    imageargs.Model = drawargs.Model;
        //    imageargs.ModelIndex = drawargs.ModelIndex;
        //    imageargs.Column = drawargs.Column;
        //    imageargs.Selected = drawargs.Selected;
        //    imageargs.ItemRect = drawargs.ItemRect;

        //    imageresult = new GUIListViewGetItemImageResult();
        //    imageresult.Image = null;
        //    //imageresult.ImageSize = new Vector2(ItemSize.y - 2, ItemSize.y - 2);
        //    imageresult.ImageTexCoords = new Rect(0, 0, 1, 1);
        //    imageresult.ImageScaleMode = ScaleMode.ScaleAndCrop;
        //    imageresult.ImageDrawMode = GUIListViewImageDrawMode.Alphablend;
        //    imageresult.ImageRect = drawargs.ItemRect;
        //    imageresult.ImageRect.y += 1;
        //    imageresult.ImageRect.width = ItemSize.y - 2;// imageresult.ImageSize.x;
        //    imageresult.ImageRect.height = ItemSize.y - 2;// imageresult.ImageSize.y;
        //    imageresult.RemainingItemRect = drawargs.ItemRect;
        //    //imageresult.RemainingItemRect.x += imageresult.ImageRect.width + 1;
        //    //imageresult.RemainingItemRect.width -= imageresult.ImageRect.width + 1;

        //    OnGetItemImage(imageargs, ref imageresult);
        //    //if (imageresult.ImageRect.height < ItemSize.y)
        //    //    imageresult.ImageRect.y += (ItemSize.y - imageresult.ImageRect.height) * 0.5f; // vertically move the image into the center

        //    if (null != imageresult.Image)
        //    {
        //        switch (imageresult.ImageDrawMode)
        //        {
        //            case GUIListViewImageDrawMode.Alphablend:
        //                GUI.DrawTexture(imageresult.ImageRect, imageresult.Image, imageresult.ImageScaleMode, true);
        //                break;
        //            case GUIListViewImageDrawMode.Alpha:
        //                EditorGUI.DrawTextureAlpha(imageresult.ImageRect, imageresult.Image, imageresult.ImageScaleMode);
        //                break;
        //            case GUIListViewImageDrawMode.None:
        //                EditorGUI.DrawPreviewTexture(imageresult.ImageRect, imageresult.Image, null, imageresult.ImageScaleMode);
        //                break;
        //        }


        //        imageresult.RemainingItemRect.x += 1;
        //        imageresult.RemainingItemRect.width -= 1;
        //        return true;
        //    }

        //    return false;
        //}

        void SetVScrollbarPos(DrawContext context, float value)
        {
            _animateScroll = false;
            _scrollbarPos.y = Mathf.Clamp(value, 0, context.ScrollBounds.y);
        }

        bool IsItemVisible(DrawContext context, int index)
        {
            if (index < context.FirstVisibleItem)
                return false;
            if (index > context.LastVisibleItem)
                return false;
            return true;
        }

        public void ScrollIntoView(int index)
        {
            _animateScrollPos.x = _scrollbarPos.x;
            _animateScroll = true;

            var context = _lastRepaintContext;
            _animateScrollPos.y = Mathf.Clamp((index - (context.VisibleItemCount + context.ColumnCount - 1) * 0.5f) / (float)context.ColumnCount, 0, context.ScrollBounds.y);
        }

        void EnsureVisible(DrawContext context, int index)
        {
            if (index < context.FirstVisibleItem)
              SetVScrollbarPos(context, (index) / (float)context.ColumnCount);

            if (index >= context.LastVisibleItem)
              SetVScrollbarPos(context, (index - context.VisibleItemCount + context.ColumnCount) / (float)context.ColumnCount);
        }

        void DoHandleInput(DrawContext context)
        {
            // since we use GUI.Group, positions start at 0,0
            var clientrect = new Rect(0, 0, context.ClientRect.width, context.ClientRect.height);
            if (clientrect.Contains(Event.current.mousePosition) && Event.current.type == EventType.scrollWheel)
            {
                SetVScrollbarPos(context, _scrollbarPos.y + Event.current.delta.y * 0.2f);
                Event.current.Use();
            }

            if (!HasFocus)
                return;

            if (EditorGUIUtility.hotControl != 0 && EditorGUIUtility.hotControl != context.ControlId)
                return; // another control is currently active

            if (GUIUtility.keyboardControl != context.ControlId)
                return;

            #region Select all
            if (Event.current.type == EventType.ValidateCommand || Event.current.type == EventType.ExecuteCommand)
            {
                if (string.Equals(Event.current.commandName, "SelectAll", StringComparison.OrdinalIgnoreCase))
                {
                    if (Event.current.type == EventType.ExecuteCommand)
                    {
                        _selection.Clear();
                        for (var n = 0; n < OnGetItemCount(); ++n)
                        {
                            _selection.Add(OnGetItem(n), new ItemSelInfo(Time.realtimeSinceStartup, false));
                        }
                        DoSelectionChange();
                    }
                    Event.current.Use();
                }
            }
            #endregion

            #region Select item one page down
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.PageDown)
            {
                var index = FindItemIndex(_activeItem);
                if (IsItemVisible(context, index + context.ColumnCount + 1))
                    index = context.LastVisibleItem;
                else
                {
                  SetVScrollbarPos(context, index / context.ColumnCount);
                  index += context.VisibleItemCount;
                  index = Mathf.Min(context.TotalItemCount - 1, index);
                }

                if (index >= 0 && index < context.TotalItemCount)
                {
                    if (Event.current.shift && MultiSelect)
                    {
                        DoHandleShiftSelection(index);
                    }
                    else
                    {
                        _selection.Clear();
                        _selection.Add(OnGetItem(index), new ItemSelInfo(Time.realtimeSinceStartup, true));
                        DoSelectionChange();
                    }

                    _activeItem = OnGetItem(index);
                }
                Event.current.Use();
            }
            #endregion

            #region Select item one page up
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.PageUp)
            {
                var index = FindItemIndex(_activeItem);
                if (IsItemVisible(context, index - context.ColumnCount - 1))
                    index = context.FirstVisibleItem;
                else
                {
                  index -= context.VisibleItemCount;
                  index = Mathf.Max(0, index);
                  SetVScrollbarPos(context, index / context.ColumnCount);
                }

                if (index >= 0 && index < context.TotalItemCount)
                {
                    if (Event.current.shift && MultiSelect)
                    {
                        DoHandleShiftSelection(index);
                    }
                    else
                    {
                        _selection.Clear();
                        _selection.Add(OnGetItem(index), new ItemSelInfo(Time.realtimeSinceStartup, true));
                        DoSelectionChange();
                    }

                    _activeItem = OnGetItem(index);
                }
                Event.current.Use();
            }
            #endregion

            #region Select very first item
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.Home)
            {
                EnsureVisible(context, 0);

                if (Event.current.shift && MultiSelect)
                {
                    if (context.TotalItemCount > 0)
                        DoHandleShiftSelection(0);
                }
                else
                {
                    _selection.Clear();
                    if (context.TotalItemCount > 0)
                    {
                        _selection.Add(OnGetItem(0), new ItemSelInfo(Time.realtimeSinceStartup, true));
                        DoSelectionChange();
                    }
                }

                if (context.TotalItemCount > 0)
                    _activeItem = OnGetItem(0);

                Event.current.Use();
            }
            #endregion

            #region Select very last item
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.End)
            {
                EnsureVisible(context, context.TotalItemCount - 1);

                if (Event.current.shift && MultiSelect)
                {
                    if (context.TotalItemCount > 0)
                        DoHandleShiftSelection(OnGetItemCount() - 1);
                }
                else
                {
                    _selection.Clear();
                    if (context.TotalItemCount > 0)
                    {
                        _selection.Add(OnGetItem(context.TotalItemCount - 1), new ItemSelInfo(Time.realtimeSinceStartup, true));
                        DoSelectionChange();
                    }
                }

                if (context.TotalItemCount > 0)
                    _activeItem = OnGetItem(OnGetItemCount() - 1);
                
                Event.current.Use();
            }
            #endregion

            #region Select previous item
            if (context.ColumnCount > 1 && Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.LeftArrow && !Event.current.control)
            {
                for (var n = 1; n < context.TotalItemCount; ++n)
                {
                    var model = OnGetItem(n);
                    if (System.Object.ReferenceEquals(model, _activeItem))
                    {
                        var index = Math.Max(0, n - 1);
                        model = OnGetItem(index);
                        if (Event.current.shift && MultiSelect)
                        {
                            DoHandleShiftSelection(index);
                        }
                        else
                        {
                            _selection.Clear();
                            _selection.Add(model, new ItemSelInfo(Time.realtimeSinceStartup, true));
                            DoSelectionChange();
                        }
                        _activeItem = model;
                        EnsureVisible(context, index);
                        break;
                    }
                }
                Event.current.Use();
            }
            #endregion

            #region Select item in upper row
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.UpArrow && !Event.current.control)
            {
                for (var n = 1; n < context.TotalItemCount; ++n)
                {
                    var model = OnGetItem(n);
                    if (System.Object.ReferenceEquals(model, _activeItem))
                    {
                        var index = Math.Max(0, n - context.ColumnCount);
                        var newmodel = OnGetItem(index);
                        if (Event.current.shift && MultiSelect)
                        {
                            DoHandleShiftSelection(index);

                        }
                        else
                        {
                            _selection.Clear();
                            _selection.Add(newmodel, new ItemSelInfo(Time.realtimeSinceStartup, true));
                            DoSelectionChange();
                        }

                        _activeItem = newmodel;
                        EnsureVisible(context, index);
                        break;
                    }
                }
                Event.current.Use();
            }
            #endregion

            #region Select next item
            if (context.ColumnCount > 1 && Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.RightArrow && !Event.current.control)
            {
                for (var n = 0; n < context.TotalItemCount - 1; ++n)
                {
                    var model = OnGetItem(n);
                    if (System.Object.ReferenceEquals(model, _activeItem))
                    {
                        var index = Math.Min(context.TotalItemCount - 1, n + 1);
                        model = OnGetItem(index);
                        if (Event.current.shift && MultiSelect)
                        {
                            DoHandleShiftSelection(n);
                        }
                        else
                        {
                            _selection.Clear();
                            _selection.Add(model, new ItemSelInfo(Time.realtimeSinceStartup, true));
                            DoSelectionChange();
                        }
                        _activeItem = model;
                        EnsureVisible(context, index);
                        break;
                    }
                }
                Event.current.Use();
            }
            #endregion

            #region Select item in lower row
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.DownArrow && !Event.current.control)
            {
                for (var n = 0; n < context.TotalItemCount - 1; ++n)
                {
                    var model = OnGetItem(n);
                    if (System.Object.ReferenceEquals(model, _activeItem))
                    {
                        var index = Math.Min(context.TotalItemCount - 1, n + context.ColumnCount);
                        var newmodel = OnGetItem(index);
                        if (Event.current.shift && MultiSelect)
                        {
                            DoHandleShiftSelection(index);
                        }
                        else
                        {
                            _selection.Clear();
                            _selection.Add(newmodel, new ItemSelInfo(Time.realtimeSinceStartup, true));
                            DoSelectionChange();
                        }

                        _activeItem = newmodel;
                        EnsureVisible(context, index);
                        break;
                    }
                }
                Event.current.Use();
            }
            #endregion

            #region Scroll list downwards
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.DownArrow && Event.current.control)
            {
                SetVScrollbarPos(context, _scrollbarPos.y + 0.5f);
                Event.current.Use();
            }
            #endregion

            #region Scroll list upwards
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.UpArrow && Event.current.control)
            {
                SetVScrollbarPos(context, _scrollbarPos.y - 0.5f);
                Event.current.Use();
            }
            #endregion

            #region Scroll list to the right
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.RightArrow && Event.current.control)
            {
                _scrollbarPos.x += 10;
                Event.current.Use();
            }
            #endregion

            #region Scroll list to the left
            if (Event.current.type == EventType.keyDown && Event.current.keyCode == KeyCode.LeftArrow && Event.current.control)
            {
                _scrollbarPos.x -= 10;
                Event.current.Use();
            }
            #endregion

            #region Jump to item that starts with the pressed character
            if (Event.current.type == EventType.keyDown && Event.current.isKey && !Event.current.control && (Event.current.character>=32))
            {
                var elapsed = Time.realtimeSinceStartup - _lastKeyPressTime;
                if (elapsed > 0.7f)
                    _findWord = "";

                _findWord = _findWord + Event.current.character;
                _lastKeyPressTime = Time.realtimeSinceStartup;
                Event.current.Use();

                var itemindex = DoFindItemByKeyword(context);
                if (itemindex != -1)
                {
                    var item = OnGetItem(itemindex);
                    _selection.Clear();
                    _selection.Add(item, new ItemSelInfo(Time.realtimeSinceStartup, true));
                    DoSelectionChange();
                    _activeItem = item;

                    ScrollIntoView(itemindex);
                }
            }
            #endregion
        }

        int DoFindItemByKeyword(DrawContext context)
        {
            var args = new GUIListViewGetItemKeywordArgs();
            args.Column = FirstVisibleColumn;

            var startindex = 0;
            if (SelectedItemsCount > 0)
                startindex = this.FindItemIndex(SelectedItems[0])+1;

            var count = OnGetItemCount();
            for (var n = startindex; n < count + startindex; ++n)
            {
                args.ModelIndex = n % count;
                args.Model = OnGetItem(args.ModelIndex);

                var findword = OnGetItemKeyword(args);
                if (findword != null && findword.StartsWith(_findWord, StringComparison.OrdinalIgnoreCase))
                    return args.ModelIndex;
            }

            return -1;
        }

        void DoPostHandleInput(DrawContext context)
        {
            #region Click on empty space in list
            {
                // create rectangle that represents the empty area
                var emptyrect = new Rect(context.ListRect.x,
                    (context.VisibleRowCount + 1) * (ItemSize.y + ItemMargin.y) + context.HeaderHeight,
                    context.ListRect.width,
                    Mathf.Max(0, context.ListRect.height - (context.VisibleRowCount + 1) * (ItemSize.y + ItemMargin.y)));

                var e = Event.current;
                var leftbuttondown = e.button == 0 && e.type == EventType.mouseDown && emptyrect.Contains(e.mousePosition);
                var rightbuttondown = e.button == 1 && e.type == EventType.mouseDown && emptyrect.Contains(e.mousePosition);
                var selectbuttondown = leftbuttondown || (RightClickSelect && rightbuttondown);

                // clear selection when user clicked on empty area in list
                // and doesn't hold ctrl or shift (mimic explorer behaviour)
                if (selectbuttondown && !e.control && !e.shift)
                {
                    Event.current.Use();
                    if (_selection.Count > 0)
                    {
                        _selection.Clear();
                        DoSelectionChange();
                    }
                }
            }
            #endregion

            #region Check for unhandled key-press
            if (Event.current.type == EventType.keyDown && Event.current.isKey && _activeItem != null)
                DoItemKeyDown();
            #endregion
        }

        object _activeItem;

        int FindItemIndex(object item)
        {
            var count = OnGetItemCount();
            for (var n = 0; n < count; ++n)
            {
                var i = OnGetItem(n);
                if (System.Object.ReferenceEquals(i, item))
                    return n;
            }
            return -1;
        }

        void SelectItem(object item, bool clicked)
        {
            if (!_selection.ContainsKey(item))
                _selection.Add(item, new ItemSelInfo(Time.realtimeSinceStartup, clicked));
        }

        void DoHandleShiftSelection(int toindex)
        {
            var isel = GetLastSelectedItem();
            var lastindex = FindItemIndex(isel);
            if (lastindex != -1)
            {
                var oldsel = _selection[isel];
                _selection.Clear();
                _selection.Add(isel, oldsel);
                var loopguard = 0;
                while (toindex != lastindex)
                {
                    var i = OnGetItem(lastindex);
                    if (i != isel)
                        SelectItem(i, false);

                    lastindex += (int)Mathf.Sign(toindex - lastindex);
                    if (++loopguard > 1000000)
                        break;
                }

                _activeItem = OnGetItem(toindex);
                SelectItem(_activeItem, false);
                DoSelectionChange();
            }
            Editor.Repaint();
        }
        Vector2 _animateScrollPos;

        void DoHandleItemInput(DrawContext context)
        {
            if (!HasFocus)
                return;

            if (!context.IsMouseInside)
                return;

            if (EditorGUIUtility.hotControl != 0 && EditorGUIUtility.hotControl != context.ControlId)
                return; // another control is currently active

            if (GUIUtility.keyboardControl != context.ControlId)
                return;

            // make sure we only process events we are interested in
            var e = Event.current;
            switch (e.type)
            {
                case EventType.mouseDown:
                case EventType.mouseUp:
                case EventType.mouseDrag:
                    break;
                case EventType.keyDown:
                    if (Event.current.keyCode != KeyCode.Menu)
                        return;
                    break;
                default:
                    return;
            }

            var rect = context.ItemRect;
            var leftbuttondown = e.button == 0 && e.type == EventType.mouseDown && rect.Contains(e.mousePosition);
            var leftbuttonup = e.button == 0 && e.type == EventType.mouseUp && rect.Contains(e.mousePosition);
            var rightbuttondown = e.button == 1 && e.type == EventType.mouseDown && rect.Contains(e.mousePosition);
            var rightbuttonup = e.button == 1 && e.type == EventType.mouseUp && rect.Contains(e.mousePosition);
            var leftbuttondrag = e.button == 0 && e.type == EventType.mouseDrag && rect.Contains(e.mousePosition);
            var selectbuttondown = leftbuttondown;
            var selectbuttonup = leftbuttonup;

            if (RightClickSelect)
            {
                selectbuttondown = leftbuttondown || rightbuttondown;
                selectbuttonup = leftbuttonup || rightbuttonup;
            }

            // Display contect menu
            var menukey = Event.current.keyCode == KeyCode.Menu && Event.current.type == EventType.keyDown && System.Object.ReferenceEquals(context.Item, _activeItem);
            if ((e.clickCount == 1 && rightbuttonup) || menukey)
            {
                _activeItem = context.Item;
                DoItemContextMenu(context, !menukey);
                e.Use();
            }

            // from here on, only mouse input gets handled. and if the mouse
            // position isn't in the items rectangle, we don't need to go any further
            // because the input is not meant to be for this item.
            if (!rect.Contains(e.mousePosition))
                return;

            // check if the position is clickable at all. for example
            // we don't want to select an item when we just click a button
            // to expand a node tree or so.
            if (leftbuttondown)
            {
                var isselectibeargs = new GUIListViewIsItemPositionClickableArgs();
                isselectibeargs.Model = context.Item;
                isselectibeargs.ModelIndex = context.ItemIndex;
                isselectibeargs.ItemRect = context.ItemRect;
                isselectibeargs.Column = context.Column;
                isselectibeargs.MousePosition = e.mousePosition;
                var isselectibe = OnIsItemPositionClickable(isselectibeargs);
                if (!isselectibe)
                    return;
            }

            // Check is drag&drop is enabled and user is starting to drag an item
            // also make sure the user is not resizing a column and accidentilly
            // moved the mouse over the list.
            if (DragDropEnabled && leftbuttondrag && (_columnLMBDown == null) && (context.ColumnCount == 0 || DragColumn == null || DragColumn.ColumnRect.Contains(Event.current.mousePosition)))
            {
                _activeItem = context.Item;
                DoBeginDrag(context.ItemIndex);
                e.Use(); // eat event when selection changed
            }

            // Check for single item click
            if (e.clickCount == 1 && selectbuttondown)
            {
                _activeItem = context.Item;
                DoItemClick(context.ItemIndex);
                Editor.Repaint();
            }

            // Check for double item click
            if (e.clickCount == 2 && selectbuttondown)
            {
                _activeItem = context.Item;
                DoItemDoubleClick(context.ItemIndex);
                Editor.Repaint();
            }

            // Ctrl + Shift selection
            if (MultiSelect && _selection.Count > 0 && e.clickCount == 1 && e.control && e.shift && selectbuttondown)
            {
                var lastindex = FindItemIndex(GetLastSelectedItem());
                if (lastindex != -1)
                {
                    var loopguard = 0;
                    while (context.ItemIndex != lastindex)
                    {
                        SelectItem(OnGetItem(lastindex), false);

                        lastindex += (int)Mathf.Sign(context.ItemIndex - lastindex);
                        if (++loopguard > 1000000)
                            break;
                    }
                    _activeItem = context.Item;
                    SelectItem(context.Item, false);
                    DoSelectionChange();
                    e.Use(); // eat event when selection changed
                }
                Editor.Repaint();
                return;
            }

            // Shift selection
            if (MultiSelect && _selection.Count > 0 && e.clickCount == 1 && !e.control && e.shift && selectbuttondown)
            {
                _activeItem = context.Item;
                DoHandleShiftSelection(context.ItemIndex);
                e.Use(); // eat event when selection changed
                Editor.Repaint();
                return;
            }

            // Item selection (multi-selection)
            if (e.clickCount == 1 && e.control && selectbuttondown)
            {
                _activeItem = context.Item;
                if (!MultiSelect)
                    _selection.Clear();

                if (context.Selected)
                    _selection.Remove(context.Item);
                else
                    _selection.Add(context.Item, new ItemSelInfo(Time.realtimeSinceStartup, true));

                DoSelectionChange();
                if (context.Selected != IsSelected(context.Item))
                    e.Use(); // eat event when selection changed

                Editor.Repaint();
                return;
            }

            // Check if user pressed the selection button but the item is not selected yet.
            // In this case it's a new item, so we need to clear the selection and just add this one.
            // We only select the new item when it isn't selected yet, because we need to keep the
            // selection intact for dragging operations.
            if (e.clickCount == 1 && !e.control && selectbuttondown && !context.Selected)
            {
                _activeItem = context.Item;
                _selection.Clear();
                _selection.Add(context.Item, new ItemSelInfo(Time.realtimeSinceStartup, true));
                DoSelectionChange();

                e.Use(); // eat event is item wasnt selected yet

                Editor.Repaint();
                return;
            }

            // Check if user released the selection button and it's a selected yet.
            // In this case just select this item.
            if (e.clickCount == 1 && !e.control && !e.shift && leftbuttonup && context.Selected)
            {
                _activeItem = context.Item;
                _selection.Clear();
                _selection.Add(context.Item, new ItemSelInfo(Time.realtimeSinceStartup, true));

                DoSelectionChange();
                if (!context.Selected)
                    e.Use(); // eat event if item wasnt selected yet
                
                Editor.Repaint();
                return;
            }
        }

        #region Sort

        /// <summary>
        /// Sorts the list by the specified column using the specified mode.
        /// </summary>
        /// <param name="column">The column</param>
        /// <param name="mode">The mode</param>
        public void Sort(GUIListViewColumn column, GUIListViewSortMode mode)
        {
            // clear sortmode in every column
            foreach (var c in Columns)
                c.SortMode = GUIListViewSortMode.None;

            // only set the specified column to the specified sortmode
            if (null != column)
            {
                column.SortMode = mode;
                column.SortPrio = DateTime.Now.Ticks;
            }

            Sort();
        }
        
        /// <summary>
        /// Sorts the list by the active sorting column and mode.
        /// </summary>
        public void Sort()
        {
            DoSortItems();
        }

        bool DoSortItems()
        {
            // get which items to sort
            var models = OnBeforeSortItems();
            if (null == models)
                return false;

            // check if any column is sorted
            var issorted = false;
            foreach (var c in Columns)
            {
                if (c.SortMode != GUIListViewSortMode.None)
                {
                    issorted = true;
                    break;
                }
            }

            // if not a single column is actually sorted yet, just use the first visible column for sorting
            var firstColumn = FirstVisibleColumn;
            if (!issorted && firstColumn != null)
            {
                firstColumn.SortMode = GUIListViewSortMode.Ascending;
                firstColumn.SortPrio = DateTime.Now.Ticks;
            }
            
            // find every column that should be used for sorting and add it to our comparer
            var comparer = new GUIListViewModelComparer();
            foreach(var c in Columns)
            {
                if (c.SortMode != GUIListViewSortMode.None)
                    comparer.Columns.Add(c);
            }

            // now sort the columns by priority in our comparer
            comparer.Columns.Sort(delegate(GUIListViewColumn a, GUIListViewColumn b)
                {
                    if (a.SortPrio < b.SortPrio)
                        return -1;
                    if (a.SortPrio > b.SortPrio)
                        return 1;
                    return 0;
                });

            // and actually sort
            if (comparer.Columns.Count > 0)
                Array.Sort(models, comparer);

            // pass sorted items back to user
            OnAfterSortItems(models);
            return true;
        }

        /// <summary>
        /// Occurs when the list gets sorted, but prior actually sorting it.
        /// </summary>
        /// <returns>The unsorted items.</returns>
        protected virtual object[] OnBeforeSortItems()
        {
            return null;
        }

        /// <summary>
        /// Occurs when sorting completed.
        /// </summary>
        /// <param name="models">The sorted items</param>
        protected virtual void OnAfterSortItems(object[] models)
        {
        }
        #endregion

        #region SaveCsv
        /// <summary>
        /// Save CSV to a file.
        /// </summary>
        /// <remarks>
        /// The method displays a file dialog asking the user to choose where to save it.
        /// </remarks>
        public void SaveCsv()
        {
            // get export path
            var path = EditorPrefs.GetString(string.Format("{0}.RecentCsvExportPath", EditorPrefsPath), System.IO.Path.Combine(EditorApplication2.ProjectPath, EditorApplication2.ProjectName + ".csv"));

            // open save file dialog, pointing to recent path
            path = EditorUtility.SaveFilePanel("Export as CSV...", FileUtil2.GetDirectoryName(path), EditorApplication2.ProjectName, "csv");
            path = path.Replace('\\', '/');
            if (string.IsNullOrEmpty(path))
                return;

            // write csv data to file
            EditorPrefs.SetString(string.Format("{0}.RecentCsvExportPath", EditorPrefsPath), path);
            var csv = ExportCsv();
            try
            {
                System.IO.File.WriteAllText(path, csv.ToString(), System.Text.Encoding.UTF8);
            }
            catch (Exception e)
            {
                var text = string.Format("Could not write file '{0}'.\n\nMake sure the file is not in use by another application.", path);
                EditorUtility.DisplayDialog("ERROR", text, "OK");
                throw e;
            }
        }
        #endregion

        #region ExportCsv
        /// <summary>
        /// Gets the current list content in CSV format (comma separated).
        /// </summary>
        /// <returns>The CSV text.</returns>
        public System.Text.StringBuilder ExportCsv()
        {
            return ExportCsv(',');
        }

        /// <summary>
        /// Gets the current list content in CSV format.
        /// </summary>
        /// <param name="separator">The separator letter.</param>
        /// <returns>The CSV text.</returns>
        public System.Text.StringBuilder ExportCsv(char separator)
        {
            var csv = new System.Text.StringBuilder(OnGetItemCount() * 256);

            // export header
            for (var n = 0; n < Columns.Count; ++n)
            {
                var column = Columns[n];
                csv.Append('\"' + column.Text + '\"');
                if (n + 1 < Columns.Count)
                    csv.Append(separator);
            }
            csv.Append('\n');

            // export models
            for (var j = 0; j < OnGetItemCount(); ++j)
            {
                var model = OnGetItem(j);
                var args = new GUIListViewGetItemTextArgs();
                args.Model = model;
                args.ModelIndex = j;

                // export each column for the current model
                for (var n = 0; n < Columns.Count; ++n)
                {
                    args.Column = Columns[n];
                    var text = OnGetItemText(args) ?? "";
                    csv.Append('\"' + text + '\"');
                    if (n + 1 < Columns.Count)
                        csv.Append(separator);
                }
                csv.Append('\n');
            }

            return csv;
        }
        #endregion

        #region OnBeginDrag
        void DoBeginDrag(int index)
        {
            UnityEngine.Object[] objects;
            string[] paths;
            OnBeginDrag(index, out objects, out paths);

            if (null != objects || null != paths)
            {
                if (null != objects)
                    DragAndDrop.objectReferences = objects;

                if (null != paths)
                    DragAndDrop.paths = paths;

                DragAndDrop.PrepareStartDrag();
                DragAndDrop.StartDrag("");
            }
            //if (null != ItemContextMenu)
            //    ItemContextMenu.Invoke(this, index);
        }

        protected virtual void OnBeginDrag(int index, out UnityEngine.Object[] objects, out string[] paths)
        {
            objects = null;
            paths = null;
        }
        #endregion

        #region GetSortIconCount
        /// <summary>
        /// Gets the number of sort icon indicators in a column header.
        /// The number of indicators in a column header represents the sorting order.
        /// </summary>
        /// <param name="column">The column</param>
        /// <returns>The number of indicators.</returns>
        int GetSortIconCount(GUIListViewColumn column)
        {
            if (column.SortMode == GUIListViewSortMode.None)
                return -1;

            int count = 1;
            foreach (var c in Columns)
            {
                if (c == column)
                    continue;
                if (c.SortPrio == -1)
                    continue;
                if (c.SortPrio < column.SortPrio)
                    count++;
            }
            return count;
        }
        #endregion

        #region DoColumnClick
        void DoColumnClick(GUIListViewColumn column)
        {
            if (null == column.CompareFunc)
                return; // no compare function, no sort possible

            GUIListViewSortMode sortmode = GUIListViewSortMode.None;
            switch (column.SortMode)
            {
                case GUIListViewSortMode.None:
                case GUIListViewSortMode.Descending:
                    sortmode = GUIListViewSortMode.Ascending;
                    break;

                case GUIListViewSortMode.Ascending:
                    sortmode = GUIListViewSortMode.Descending;
                    break;
            }

            if (Event.current.control && Event.current.shift)
            {
                column.SortPrio = -1;
                sortmode = GUIListViewSortMode.None;
            }
            else if (Event.current.control)
            {
                if (column.SortPrio == -1)
                    column.SortPrio = DateTime.Now.Ticks;
            }
            else
            {
                for (var n = 0; n < Columns.Count; ++n)
                {
                    Columns[n].SortPrio = -1;
                    if (column != Columns[n])
                        Columns[n].SortMode = GUIListViewSortMode.None;
                }

                column.SortPrio = DateTime.Now.Ticks;
            }

            column.SortMode = sortmode;
            DoSortItems();

            if (null != ColumnClick)
                ColumnClick.Invoke(this, column);
        }
        #endregion

        #region OnItemContextMenu
        void DoItemContextMenu(DrawContext context, bool fromMouse)
        {
            var args = new GUIListViewContextMenuArgs();
            args.Model = context.Item;
            args.ModelIndex = context.ItemIndex;
            args.Column = context.Column;
            args.Selected = context.Selected;
            args.MenuLocation = fromMouse ? Event.current.mousePosition : new Vector2(context.ItemRect.x, context.ItemRect.y);

            OnItemContextMenu(args);

            if (null != ItemContextMenu)
                ItemContextMenu.Invoke(this, args);
        }

        protected virtual void OnItemContextMenu(GUIListViewContextMenuArgs args)
        {
        }
        #endregion

        #region OnItemClick
        void DoItemClick(int index)
        {
            OnItemClick(index);

            if (null != ItemClick)
                ItemClick.Invoke(this, index);
        }

        protected virtual void OnItemClick(int index)
        {
        }
        #endregion

        #region OnItemKeyDown
        void DoItemKeyDown()
        {
            var args = new GUIListViewItemKeyDownArgs();

            args.Model = _activeItem;
            args.ModelIndex = FindItemIndex(_activeItem);
            OnItemKeyDown(ref args);

            if (args.Handled)
                Event.current.Use();
        }

        /// <summary>
        /// Occurs when the user presses a key and the key hasn't been handled by user code (OnItemDraw).
        /// </summary>
        protected virtual void OnItemKeyDown(ref GUIListViewItemKeyDownArgs args)
        {
        }
        #endregion

        #region OnItemDoubleClick
        void DoItemDoubleClick(int index)
        {
            OnItemDoubleClick(index);

            if (null != ItemDoubleClick)
                ItemDoubleClick.Invoke(this, index);
        }

        /// <summary>
        /// Occurs when the user double-clicks on an item.
        /// </summary>
        /// <param name="index">The item index</param>
        protected virtual void OnItemDoubleClick(int index)
        {
        }
        #endregion

        #region OnItemHide
        /// <summary>
        /// Occurs when an item gets out of view.
        /// </summary>
        /// <remarks>
        /// You can use this to release allocated resources that are not necessary when the item is out of view.
        /// </remarks>
        protected virtual void OnItemHide(object model)
        {
        }
        #endregion

        #region OnGetItemText
        /// <summary>
        /// Gets the item text for the specified args.
        /// </summary>
        protected virtual string OnGetItemText(GUIListViewGetItemTextArgs args)
        {
            return null;
        }
        #endregion

        #region OnGetItemKeyword
        /// <summary>
        /// Gets the item keyword for the specified args.
        /// </summary>
        /// <remarks>
        /// The item-keyword is used to jump to a particular item in the list
        /// when the user pressed a key. When an item begins with the keyword(sequence) the list scrolls it into view and selects it.
        /// </remarks>
        protected virtual string OnGetItemKeyword(GUIListViewGetItemKeywordArgs args)
        {
            return null;
        }
        #endregion

        #region OnGetItemCount
        /// <summary>
        /// Gets the count of items in the list.
        /// </summary>
        /// <returns>The number of items in the list.</returns>
        protected abstract int OnGetItemCount();
        #endregion

        #region OnGetItem
        /// <summary>
        /// Gets the item of the specified index.
        /// </summary>
        /// <param name="index">The item index in range 0..OnGetItemCount()-1</param>
        /// <returns>The item on success, null otherwise.</returns>
        protected abstract object OnGetItem(int index);
        #endregion

        protected abstract void OnDrawItem(GUIListViewDrawItemArgs args);

        protected virtual bool OnIsItemPositionClickable(GUIListViewIsItemPositionClickableArgs args)
        {
            return true;
        }
    }
}
